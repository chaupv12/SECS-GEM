perl $ACE_ROOT/bin/mpc.pl -ti lib:gnudll -type gnu libsecs.mpc
