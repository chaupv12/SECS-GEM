perl $ACE_ROOT/bin/mpc.pl -ti lib:gnudll -type gnu libee.mpc
perl $ACE_ROOT/bin/mpc.pl -ti lib:gnudll -type gnu libee2.mpc
