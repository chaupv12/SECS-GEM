// $Id: tclmelcli.cpp,v 1.3 2002/09/08 12:32:07 fukasawa Exp $

// ============================================================================
//
// = LIBRARY
//     tclmelcli
//
// = FILENAME
//     tclmelcli.cpp
//
// = AUTHOR(S)
//     Fukasawa Mitsuo
//
// = COPYRIGHT
//     Copyright (c) 2001-2002 by BEE Co.,Ltd.  All rights reserved.
//
//     This file is part of the tclgxml that can be used free.
//     The tclgxml and this file are covered by the GNU Lesser General Public
//     License, which should be included with libxml++ as the file COPYING.
//
// ============================================================================

#include "ace/ACE.h"
#include "ace/Log_Msg.h"

#ifdef _MSC_VER
#pragma warning(disable: 4786)  // too long identifier
#include <windows.h>
#endif

#include "tcl.h"

#define EQUALSTR(s, c)      ((*s == *c) && (strcmp(s, c) == 0))
#define TCLMELCLI_VERSION   "1.0"
/*
 * Function prototype
 */
extern "C" {
DLLEXPORT int Melcli_Init (Tcl_Interp *interp);
DLLEXPORT int Melcli_SafeInit (Tcl_Interp *interp);
}
extern int Melcli_openCmd(ClientData, Tcl_Interp *, int, Tcl_Obj *CONST []);
extern int Melcli_closeCmd(ClientData, Tcl_Interp *, int, Tcl_Obj *CONST []);
extern int Melcli_readCmd(ClientData, Tcl_Interp *, int, Tcl_Obj *CONST []);
extern int Melcli_writeCmd(ClientData, Tcl_Interp *, int, Tcl_Obj *CONST []);
extern int Melcli_xwriteCmd(ClientData, Tcl_Interp *, int, Tcl_Obj *CONST []);
extern int Melcli_getCmd(ClientData, Tcl_Interp *, int, Tcl_Obj *CONST []);
extern int Melcli_putCmd(ClientData, Tcl_Interp *, int, Tcl_Obj *CONST []);

// ACE Objects
ACE_Object_Manager ace_object_manager;

static void
Melcli_InterpDeleteProc (ClientData clientData, Tcl_Interp *interp)
{
    ;
}

// ACE Objects
// ACE_Object_Manager ace_object_manager;

/*
 *  This procedure performs application-specific initialization.
 *  Most applications, especially those that incorporate additional
 *  packages, will have their own version of this procedure.
 *
 * Results:
 *  Returns a standard Tcl completion code, and leaves an error
 *  message in interp->result if an error occurs.
 *
 * Side effects:
 *  Depends on the startup script.
 */
DLLEXPORT int
Melcli_Init (Tcl_Interp *interp)
{
#ifdef USE_TCL_STUBS
    if (Tcl_InitStubs(interp, "8.0", 0) == NULL) {
        return TCL_ERROR;
    }
#endif

    ACE_LOG_MSG->open ("Melcli");

    Tcl_CallWhenDeleted(interp, Melcli_InterpDeleteProc, 0);

    // Create additional commands.
    Tcl_CreateObjCommand(interp, "melcli::open", Melcli_openCmd,
        (ClientData)0, (Tcl_CmdDeleteProc *)0);
    Tcl_CreateObjCommand(interp,  "melcli::close", Melcli_closeCmd,
        (ClientData)0, (Tcl_CmdDeleteProc *)0);
    Tcl_CreateObjCommand(interp,  "melcli::read", Melcli_readCmd,
        (ClientData)0, (Tcl_CmdDeleteProc *)0);
    //Tcl_CreateObjCommand(interp,  "melcli::write", Melcli_writeCmd,
    //    (ClientData)0, (Tcl_CmdDeleteProc *)0);
    //Tcl_CreateObjCommand(interp,  "melcli::xwrite", Melcli_xwriteCmd,
    //    (ClientData)0, (Tcl_CmdDeleteProc *)0);
    Tcl_CreateObjCommand(interp,  "melcli::get", Melcli_getCmd,
        (ClientData)0, (Tcl_CmdDeleteProc *)0);
    //Tcl_CreateObjCommand(interp,  "melcli::put", Melcli_putCmd,
    //    (ClientData)0, (Tcl_CmdDeleteProc *)0);

    return Tcl_PkgProvide(interp, "melcli", TCLMELCLI_VERSION);
}

/*
 *  This procedure initializes commands for a safe interpreter.
 *  You would leave out of this procedure any commands you deemed unsafe.
 *
 * Results:
 *  A standard Tcl result.
 *
 * Side effects:
 *  None.
 */
DLLEXPORT int
Melcli_SafeInit (Tcl_Interp *interp)
{
#ifdef USE_TCL_STUBS
    if (Tcl_InitStubs(interp, "8.0", 0) == NULL) {
        return TCL_ERROR;
    }
#endif

    return Tcl_PkgProvide(interp, "melcli", TCLMELCLI_VERSION);
}
