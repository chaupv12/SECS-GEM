perl $ACE_ROOT/bin/mwc.pl -ti dll_exe:gnuexe -type gnu tclgem.mwc
perl $ACE_ROOT/bin/mpc.pl -ti dll_exe:gnuexe -type gnu tclgem.mpc
