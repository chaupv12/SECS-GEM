LD_LIBRARY_PATH=$LD_LIBRARY_PATH:../lib:../../ecm/lib:../../bee/lib:../../secs/lib:../../vmelsec/lib
