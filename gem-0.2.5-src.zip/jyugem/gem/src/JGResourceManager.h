// $Id: JGResourceManager.h,v 1.6 2003/02/09 16:15:13 fukasawa Exp $

//=============================================================================
/**
 *  @file    JGResourceManager.h
 *
 *  @author  Fukasawa Mitsuo
 *
 *
 *    Copyright (C) 2001-2003 BEE Co.,Ltd. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
//=============================================================================

#ifndef JGRESOURCEMANAGER_H
#define JGRESOURCEMANAGER_H

#include "JGManager.h"
#include "JGVariable.h"
#include "JGSubSystem.h"


/*
 * Reosource class
 */
class JGResourceManager: public JGManager
{
public:
    JGResourceManager();
    ~JGResourceManager();

    virtual int init(void * = 0);
    virtual BS2Message * msg_svc(JGMessageTrigger * trigger, BS2Message * msg);
    virtual int notify(const string& category, JGVariable * var,
                       void * arg = NULL);

    JGSubSystem * findSubSystem(JGid& id);
    JGSubSystemTable * subSystem() { return &m_modules; }

    static JGResourceManager * instance();

private:

//
private:
    JGSubSystemTable m_modules;        // List of subsystem
};


#endif
