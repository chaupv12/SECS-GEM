package com.app.alphainfo;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AlphaGemApp extends Activity
{
	public static native void nativeInitJniClass();
	public static native void nativeReleaseJniClass();
	//public static native void nativeInitAce();
	//public static native void nativeReleaseAce();
	
	public static native int 	nativeServerTest(String jstr_ip, int port);
	public static native int	nativeClientTest(String jstr_ip, int port);
	public static native int	nativeCloseDevice();
	
	public static native int	nativeSetThreadWork(int work);
	public static native int	nativeGetLoopStatus();
	
	public Button	button00;
	public Button	button01;
	public Button	button02;
	public Button	button03;
	
	public TextView	textview00;
	//public TextView	textview01;
	public EditText	editview00;
	
	public Thread 	thread_click00;
	public Thread 	thread_click01;
	public Thread 	thread_click02;
		//public Handler 	thread_handler;
	public static Context s_appcontext;
	
	public static String GetApkFileName() 
	{
		ApplicationInfo 		appInfo 		= null;
		PackageManager	packMgmr	= s_appcontext.getPackageManager();
		
		try 
		{
			appInfo = packMgmr.getApplicationInfo("com.app.alphainfo", 0);
		} 
		catch (NameNotFoundException e) 
		{
			e.printStackTrace();
		}
		
		return appInfo.sourceDir;	
	 }
	
	public String GetIPAddress()
	{
		NetworkInterface		netface;
		InetAddress 				inetAddress; 
		
		try 
		{
			for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) 
	        {
				netface = en.nextElement();
	            
	            for (Enumeration<InetAddress> enumIpAddr = netface.getInetAddresses(); enumIpAddr.hasMoreElements();) 
	            {
	                inetAddress = enumIpAddr.nextElement();
	                
	                if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) 
	                {
	                    return inetAddress.getHostAddress();
	                }
	            }
	        }
		 } 
		 catch (SocketException ex) 
		 {
		        ex.printStackTrace();
		 }
		    
		 return "127.0.0.1";
	}
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
    	System.loadLibrary("alphagem");

    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.main);
    	
    	s_appcontext = getApplicationContext();
    	
    	nativeInitJniClass();
    	//nativeInitAce();

    //////////////////
    	//textview00 = (TextView)findViewById(R.id.textView00);
    	textview00 = (TextView)findViewById(R.id.textView00);
    	textview00.setText(GetIPAddress());
    	editview00 = (EditText)findViewById(R.id.editText00);
    	
    	button00 = (Button)findViewById(R.id.Button00);
    	button01 = (Button)findViewById(R.id.Button01);
    	button02 = (Button)findViewById(R.id.Button02);
    	button03 = (Button)findViewById(R.id.Button03);
    	    	    	
    	getWindow().setSoftInputMode( WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    			
    	button00.setOnClickListener(new Button.OnClickListener()
        { 
            @Override
            public void onClick(View v) 
            {
            	if( nativeGetLoopStatus() <= 0 )
            	{
            		Toast.makeText(getApplicationContext(), "Passive Start", Toast.LENGTH_SHORT).show();
            		nativeSetThreadWork(1);
            		thread_click00 = new Thread(new Runnable()  
                    {  
                        @Override  
                        public void run()  
                        {  
                        	String ip_empty = "127.0.0.1"; //mean use htonl(INADDR_ANY);
                        	nativeServerTest(ip_empty, 6000);
                        	nativeSetThreadWork(0);
                        }  
                    });
            		thread_click00.start();
            	}
            }         
        });
    	    	
    	button01.setOnClickListener(new Button.OnClickListener()
        { 
            @Override
            public void onClick(View v) 
            {
            	if( nativeGetLoopStatus() <= 0 )
            	{
            		//textview00.setText("Client TCP Test");
            		Toast.makeText(getApplicationContext(), "Activate Start", Toast.LENGTH_SHORT).show();
            		thread_click01 = new Thread(new Runnable()  
                    {  
                        @Override  
                        public void run()  
                        {  
                        	String	ip_remote = editview00.getText().toString();
                        	nativeClientTest(ip_remote, 6000);
                        }  
                    });
            		thread_click01.start();
            	}
            }
        });
    	
    	button02.setOnClickListener(new Button.OnClickListener()
        { 
            @Override
            public void onClick(View v) 
            {
            	if( nativeGetLoopStatus() <= 0 )
            	{
            		//textview00.setText("Client TCP Test");
            		Toast.makeText(getApplicationContext(), "Close Device", Toast.LENGTH_SHORT).show();
            		thread_click02 = new Thread(new Runnable()  
                    {  
                        @Override  
                        public void run()  
                        {  
                        	nativeCloseDevice();
                        }  
                    });
            		thread_click02.start();
            	}
            }
        });
    	
    	button03.setOnClickListener(new Button.OnClickListener()
        { 
            @Override
            public void onClick(View v) 
            {
            	nativeCloseDevice();
            	nativeReleaseJniClass();
            	finish();
            	System.exit(0);
            }         
        });
    }
}
