#include <string>
#include <vector>
#include <map>
#include <errno.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <jni.h>
#include <android/log.h>

#include "secs/BS2Socket.h"
#include "secs/BS2Sender.h"
#include "secs/BS2Receiver.h"
#include "secs/BS2Message.h"
#include "secs/BS2Stream.h"
#include "secs/BS2BlockHeader.h"
#include "secs/BS2Device.h"
#include "secs/BS2Driver.h"
#include "secs/BS2MessageInfo.h"
#include "secs/BS2ErrorMessage.h"
#include "secs/BS2MessageDictionary.h"
#include "wxLocker.h"
#include "GemSender.h"
#include "GemReceiver.h"
#include "GemHsmsCall.h"
#include "GemDevice.h"
#include "WinLinuxVCDlg.h"
#include "interfacefuncs.h"

static	volatile int 		s_thread_work 	= 0;
static	volatile int 		s_loop_status 		= 0;
static 	JavaVM*				s_javavm 				= NULL;
static 	jclass 						s_javaclass 			= NULL;
static	CDemoVCDlg*	s_MainDlg 			= NULL;

extern "C"
{
	JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved)
	{
		jclass 		cls;
		JNIEnv* 	env = NULL;

		if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK)
		{
			__android_log_write(ANDROID_LOG_ERROR, "alphagem", "OnLoad error");
			return JNI_ERR;
		}

		s_javavm = vm; //save to use this for the rest of the app.

		return JNI_VERSION_1_6;
	}

	JNIEXPORT void JNICALL JNI_OnUnload(JavaVM* vm, void* reserved)
	{
	    JNIEnv* env = NULL;

	    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK)
		{
			__android_log_write(ANDROID_LOG_ERROR, "alphagem", "OnUnload error");
			return;
		}

	    s_javavm = NULL;
	}
}

static JNIEnv* GetJavaVmEnv()
{
	JNIEnv* env;

	if( s_javavm )
	{
		if( s_javavm->GetEnv((void **)&env, JNI_VERSION_1_6) != JNI_OK )
		{
			__android_log_write(ANDROID_LOG_ERROR, "alphainfo", "GetJavaVmEnv error");
			env = NULL;
		}
	}

	return env;
}

std::string Interface_GetApkFilename()
{
    jmethodID		mid;
    jbyteArray		jbarray;
    jstring 				objmstr;
    const char* 	objchar;
    std::string 		apkstr;
    //int               length    = sizeof( ((struct can_frame *)0)->data );
    JNIEnv*        		jvmenv    = GetJavaVmEnv();

    mid = jvmenv->GetStaticMethodID(s_javaclass, "GetApkFileName", "()Ljava/lang/String;"); //int byte bytearray return int
    //mid = jvmenv->GetMethodID(s_javaclass, "ReceiveLinDynamic", "(IB[B)V");

    if( mid )
    {
       /* jbarray = jvmenv->NewByteArray( length );
        jvmenv->SetByteArrayRegion(jbarray, 0, length, (jbyte*)data);
        ret = jvmenv->CallStaticIntMethod(s_javaclass, mid, can_id, can_dlc, jbarray);
        //jvmenv->CallVoidMethod(s_javaclass, mid, can_id, can_dlc, jbarray);
        jvmenv->DeleteLocalRef(jbarray);*/

    	objmstr 	= (jstring)jvmenv->CallStaticObjectMethod(s_javaclass, mid);
    	objchar	= jvmenv->GetStringUTFChars(objmstr, 0);
    	apkstr 	= objchar;
    	jvmenv->ReleaseStringUTFChars(objmstr, objchar);
    	jvmenv->DeleteLocalRef(objmstr);

    	return apkstr;
    }
}

void Interface_InitJniClass(JNIEnv* env, jobject obj)
{
	jclass 			cls;
	JNIEnv* 	jvmenv = GetJavaVmEnv();

	if( s_javaclass == NULL )
	{
		cls				= jvmenv->FindClass("com/app/alphainfo/AlphaGemApp");
		//cls			= jvmenv->FindClass("com/android/linbusconfig/ReceiveAPI");
		s_javaclass 	= (jclass)jvmenv->NewGlobalRef(cls);
		jvmenv->DeleteLocalRef(cls);
	}
}

void Interface_ReleaseJniClass(JNIEnv* env, jobject obj)
{
	JNIEnv* 	vmenv = GetJavaVmEnv();

	if( s_javaclass )
	{
		vmenv->DeleteGlobalRef(s_javaclass);
		s_javaclass = NULL;
	}
}

/*void Interface_InitAce(JNIEnv* env, jobject obj)
{
	ACE::init();
}

void Interface_ReleaseAce(JNIEnv* env, jobject obj)
{
	ACE::fini();
}*/

jint Interface_ServerTest(JNIEnv* env, jobject obj, jstring jstr_ip, jint port)
{
	jint 									ret				= 0;
	jsize 								len 				= env->GetStringUTFLength(jstr_ip);
	const char*				strChars 	= env->GetStringUTFChars(jstr_ip, (jboolean *)0);
	std::string 					ip_multibyte(strChars, len);
	char								ip_array[256];

	env->ReleaseStringUTFChars(jstr_ip, strChars);
	sprintf(ip_array, "%s", ip_multibyte.c_str());

	if( !s_MainDlg )
		s_MainDlg	= new CDemoVCDlg(HSMS_MODE_PASSIVE, ip_array, 6000);

	return ret;
}

jint Interface_ClientTest(JNIEnv* env, jobject obj, jstring jstr_ip, jint port)
{
	jint 					ret					= 0;
	jsize 				len 					= env->GetStringUTFLength(jstr_ip);
	const char*	strChars 	= env->GetStringUTFChars(jstr_ip, (jboolean *)0);
	std::string 		ip_multibyte(strChars, len);
	char				ip_array[256];

	env->ReleaseStringUTFChars(jstr_ip, strChars);
	sprintf(ip_array, "%s", ip_multibyte.c_str());

	if( !s_MainDlg )
			s_MainDlg	= new CDemoVCDlg(HSMS_MODE_ACTIVE, ip_array, 6000);

	return ret;
}

void Interface_CloseDevice(JNIEnv* env, jobject obj)
{
	if( s_MainDlg )
	{
		delete s_MainDlg;
		s_MainDlg = NULL;
	}
}

void Interface_SetThreadWork(JNIEnv*  env, jobject obj, jint work)
{
	s_thread_work = work;
}

int Interface_GetThreadWork()
{
	return s_thread_work;
}

void Interface_SetLoopStatus(int loop)
{
	s_loop_status = loop;
}

jint Interface_GetLoopStatus(JNIEnv*  env, jobject obj)
{
	return s_loop_status;
}
