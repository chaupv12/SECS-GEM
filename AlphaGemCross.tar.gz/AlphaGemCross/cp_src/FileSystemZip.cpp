#include <string>
#include <vector>
#include <map>
#include "zip.h"
#include "unzip.h"
#include "FileSystemZip.h"

FileSystemZip::FileSystemZip()
{
	m_zip_size				= 0;
	m_compress_buf	= NULL;
	m_unzf						= NULL;
}

FileSystemZip::~FileSystemZip()
{
	if( m_compress_buf )
	{
		delete m_compress_buf;
		m_compress_buf = NULL;
	}
	
	if (m_unzf)
		unzClose(m_unzf);
}

bool FileSystemZip::Init_ZipFile(std::string zipFileName)
{
	m_unzf = unzOpen(zipFileName.c_str());
	if (!m_unzf)
	{
		return false;
	}

	m_zipFileName = zipFileName; //save it in case we need to spawn more zip readers for streaming operations
	
	CacheIndex();

	return true; //success
}

//by stone
bool FileSystemZip::Init_ZipMemory(std::string NameInZip, unsigned char* buf, int size, int append)
{
	unzFile				zf;
	zip_fileinfo		zi;
	time_t				tm_t;
	struct tm*		filedate;
	int				opt_compress_level = Z_BEST_COMPRESSION; //use best compress

	if( m_compress_buf )
	{
		delete m_compress_buf;
		m_compress_buf = NULL;
	}

	m_compress_buf = new unsigned char[size];
	
	zf = ZipOpen_Memory(m_compress_buf, size, append);
	if (!zf)
	{
		return false;
	}

	memset(&zi,0,sizeof(zip_fileinfo));
	
	tm_t		= time(NULL);
	filedate	= localtime(&tm_t);
			
	zi.tmz_date.tm_sec  = filedate->tm_sec;
	zi.tmz_date.tm_min  = filedate->tm_min;
	zi.tmz_date.tm_hour = filedate->tm_hour;
	zi.tmz_date.tm_mday = filedate->tm_mday;
	zi.tmz_date.tm_mon  = filedate->tm_mon ;
	zi.tmz_date.tm_year = filedate->tm_year;

	zipOpenNewFileInZip(zf,
												NameInZip.c_str(),
												&zi,
												NULL,
												0,
												NULL,
												0,
												NULL,
												Z_DEFLATED,
												opt_compress_level);

	zipWriteInFileInZip(zf,buf,size);
	zipCloseFileInZip(zf);
	
	m_zip_size = zipClose(zf, NULL);
	
	//m_zipFileName = zipFileName; //save it in case we need to spawn more zip readers for streaming operations
	//CacheIndex();

	return true; //success
}

bool FileSystemZip::Init_UnzMemory(unsigned char* buf, int size)
{
	m_unzf = UnZipOpen_Memory(buf, size);
	if (!m_unzf)
	{
		return false;
	}

	CacheIndex();
	return true; //success
}

void FileSystemZip::SetRootDirectory(std::string rootDir)
{
	m_rootDir = rootDir+"/";
}

void FileSystemZip::CacheIndex()
{
	int							err;
	unsigned int	i;
	unz_global_info	gi;
	ZipCacheEntry	entry;
	char						filename_inzip[512];
	unz_file_info		file_info;
	
	err = unzGetGlobalInfo (m_unzf,&gi);

	if (err!=UNZ_OK)
	{
		return;
	}
	unzGoToFirstFile(m_unzf);
	
	for(i=0;i<gi.number_entry;i++)
	{
		err = unzGetCurrentFileInfo(m_unzf,&file_info,filename_inzip,sizeof(filename_inzip),NULL,0,NULL,0);
	
		if (err!=UNZ_OK)
		{
			break;
		}
		
		err = unzGetFilePos(m_unzf, &entry.unzfilepos);
		if (err!=UNZ_OK)
		{
			break;
		}
		m_cache[filename_inzip] = entry;

		if ((i+1)<gi.number_entry)
		{
			err = unzGoToNextFile(m_unzf);
			if (err!=UNZ_OK)
			{
				break;
			}
		}
	}
}

/*std::vector<std::string> FileSystemZip::GetContents()
{
	uLong			i;
	unz_global_info gi;
	int				err;
	char			filename_inzip[512];
	unz_file_info	file_info;
	
	std::vector<std::string> contents;

	err = unzGetGlobalInfo(m_unzf,&gi);

	if (err!=UNZ_OK)
	{
		return contents;
	}

	unzGoToFirstFile(m_unzf);

	for (i=0;i<gi.number_entry;i++)
	{
		err = unzGetCurrentFileInfo(m_unzf,&file_info,filename_inzip,sizeof(filename_inzip),NULL,0,NULL,0);
		
		if (err!=UNZ_OK)
		{
			break;
		}
		contents.push_back(std::string(filename_inzip));

		if ((i+1)<gi.number_entry)
		{
			err = unzGoToNextFile(m_unzf);
			if (err!=UNZ_OK)
			{
				break;
			}
		}
	}

	return contents;
}*/

unsigned char* FileSystemZip::Get_Z( int* pSizeOut )
{
	if( m_zip_size > 0 )
		*pSizeOut = m_zip_size;
	else
		*pSizeOut = -1;

	return m_compress_buf;
}

unsigned char* FileSystemZip::Get_Unz( std::string fileName, int* pSizeOut )
{
	int											err		= UNZ_OK;
	char										filename_inzip[512];
	unz_file_info						file_info;
	zipCacheMap::iterator	itor	= m_cache.find(m_rootDir+fileName);
	unsigned char*				pdata;

	if (itor == m_cache.end())
	{
		return NULL; //not found in this zip
	}
		
	err = unzGoToFilePos(m_unzf, &itor->second.unzfilepos);
	
	if (err!=UNZ_OK)
	{
		return NULL;
	}
		
	err = unzGetCurrentFileInfo(m_unzf,&file_info,filename_inzip,sizeof(filename_inzip),NULL,0,NULL,0);

	if (err!=UNZ_OK)
	{
		return NULL;
	}
	
	//let's allocate our own memory and pass the pointer back to them.
	pdata = new unsigned char[file_info.uncompressed_size+1]; //the extra is because I will add a null later, helps when processing
			
	if (pdata)
	{
		//memory allocated
		*pSizeOut =  file_info.uncompressed_size;
		pdata[file_info.uncompressed_size] = 0;
	}   
	else
	{
		return NULL;
	}

	err = unzOpenCurrentFile(m_unzf);

	if (err!=UNZ_OK)
	{
		return NULL;
	}

	err = unzReadCurrentFile(m_unzf, pdata, file_info.uncompressed_size);
	if (err<0)	
	{
		return NULL;
	}

	err = unzCloseCurrentFile(m_unzf);
	if (err!=UNZ_OK)
	{
		return NULL;
	}

	return pdata;
}

bool FileSystemZip::FileExists( std::string fileName )
{
	zipCacheMap::iterator itor = m_cache.find(m_rootDir+fileName);

	if (itor == m_cache.end())
	{
		return NULL; //not found in this zip
	}

	return true;
}

int FileSystemZip::GetFileSize( std::string fileName )
{
	int											err = UNZ_OK;
	char										filename_inzip[512];
	unz_file_info						file_info;
	zipCacheMap::iterator	itor = m_cache.find(m_rootDir+fileName);

	if (itor == m_cache.end())
	{
		return -1; //not found in this zip
	}
	
	err = unzGoToFilePos(m_unzf, &itor->second.unzfilepos);

	if (err!=UNZ_OK)
	{
		return -1;
	}
	
	err = unzGetCurrentFileInfo(m_unzf,&file_info,filename_inzip,sizeof(filename_inzip),NULL,0,NULL,0);

	if (err!=UNZ_OK)
	{
		return false;
	}

	return (int)file_info.uncompressed_size;
}
