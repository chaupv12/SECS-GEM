//
// Copyright 2011 Tero Saarni
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#include <string>
#include <jni.h>
#include "jniapi.h"
#include "interfacefuncs.h"

JNIEXPORT void JNICALL Java_com_app_alphainfo_AlphaGemApp_nativeInitJniClass(JNIEnv* env, jobject obj)
{
	Interface_InitJniClass(env, obj);
}

JNIEXPORT void JNICALL  Java_com_app_alphainfo_AlphaGemApp_nativeReleaseJniClass(JNIEnv* env, jobject obj)
{
	Interface_ReleaseJniClass(env, obj);
}

JNIEXPORT jint JNICALL  Java_com_app_alphainfo_AlphaGemApp_nativeServerTest(JNIEnv* env, jobject obj, jstring jstr_ip, jint port)
{
	jint ret;

	ret = Interface_ServerTest(env, obj, jstr_ip, port);

	return ret;
}

JNIEXPORT jint JNICALL  Java_com_app_alphainfo_AlphaGemApp_nativeClientTest(JNIEnv* env, jobject obj, jstring jstr_ip, jint port)
{
	jint ret;

	ret = Interface_ClientTest(env, obj, jstr_ip, port);

	return ret;
}

JNIEXPORT void JNICALL  Java_com_app_alphainfo_AlphaGemApp_nativeCloseDevice(JNIEnv* env, jobject obj)
{
	Interface_CloseDevice(env, obj);
}

JNIEXPORT void JNICALL  Java_com_app_alphainfo_AlphaGemApp_nativeSetThreadWork(JNIEnv* env, jobject obj, jint work)
{
	Interface_SetThreadWork(env, obj, work);
}

JNIEXPORT jint JNICALL  Java_com_app_alphainfo_AlphaGemApp_nativeGetLoopStatus(JNIEnv* env, jobject obj)
{
	return Interface_GetLoopStatus(env, obj);
}
