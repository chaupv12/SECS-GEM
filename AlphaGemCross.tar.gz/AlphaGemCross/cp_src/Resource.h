//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DemoVC.rc
//
#define IDCANCEL                        2
#define IDEXIT                          3
#define IDD_DEMOVC_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDI_ICON_DEFAULT                129
#define IDI_ICON_PASS                   130
#define IDI_ICON_FAIL                   131
#define IDB_PAISHU                      132
#define IDB_PAIHENG                     133
#define IDC_BUTTON_TEST                 1000
#define IDC_BUTTON_TRACE                1003
#define IDC_EDIT_TITLE                  1004
#define IDC_EDIT60                      1009
#define IDC_EDIT61                      1010
#define IDC_EDIT62                      1011
#define IDC_EDIT70                      1012
#define IDC_EDIT71                      1013
#define IDC_EDIT72                      1014
#define IDC_EDIT73                      1015
#define IDC_EDIT74                      1016
#define IDC_EDIT75                      1017
#define IDC_EDIT76                      1018
#define IDC_LIST1                       1019
#define IDC_EDIT1                       1020
#define IDC_EDIT00                      10000
#define IDC_EDIT01                      10001
#define IDC_EDIT02                      10002
#define IDC_EDIT03                      10003
#define IDC_EDIT04                      10004
#define IDC_EDIT05                      10005
#define IDC_EDIT06                      10006
#define IDC_EDIT10                      10010
#define IDC_EDIT11                      10011
#define IDC_EDIT12                      10012
#define IDC_EDIT13                      10013
#define IDC_EDIT14                      10014
#define IDC_EDIT15                      10015
#define IDC_EDIT16                      10016
#define IDC_EDIT17                      10017
#define IDC_EDIT20                      10018
#define IDC_EDIT21                      10019
#define IDC_EDIT22                      10020
#define IDC_EDIT30                      10021
#define IDC_EDIT40                      10022
#define IDC_EDIT23                      10023
#define IDC_EDIT41                      10025
#define IDC_EDIT42                      10026
#define IDC_EDIT43                      10027
#define IDC_EDIT44                      10028
#define IDC_EDIT45                      10029
#define IDC_EDIT46                      10030
#define IDC_EDIT47                      10031
#define IDC_EDIT50                      10032
#define IDC_EDIT51                      10033
#define IDC_EDIT52                      10034
#define IDC_EDIT53                      10035
#define IDC_EDIT54                      10036
#define IDC_EDIT55                      10037
#define IDC_EDIT80                      10038
#define IDC_EDIT81                      10039
#define IDC_EDIT82                      10040
#define IDC_EDIT83                      10041
#define IDC_EDIT84                      10042
#define IDC_EDIT64                      10043
#define IDC_EDIT85                      10044
#define ID_MENU                         10045
#define IDC_CHECK1                      16811
#define IDC_CHECK2                      16812
#define IDC_CHECK3                      16813
#define IDC_CHECK4                      16814
#define IDC_CHECK5                      16815
#define IDC_CHECK6                      16816
#define IDC_CHECK7                      16817
#define IDC_CHECK8                      16818
#define IDC_CHECK9                      16819
#define IDC_CHECK10                     16820
#define IDC_CHECK11                     16821
#define IDC_CHECK12                     16822
#define IDC_CHECK13                     16823
#define IDC_CHECK14                     16824
#define IDC_COMBO1                      16825
#define IDC_PORT                        16826
#define WM_TASKBAR                      30000
#define ID_TRAYICON                     30001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
