// DemoVC.cpp : Defines the class behaviors for the application.
//
#if defined(_WIN32)
#define _WIN32_WINNT 0x0500
#include <afxwin.h>
#include <afxdisp.h>
#include <mmsystem.h>
#include "Resource.h"

#include "secs/BS2Socket.h"
#include "secs/BS2Sender.h"
#include "secs/BS2Receiver.h"
#include "secs/BS2Message.h"
#include "secs/BS2Stream.h"
#include "secs/BS2BlockHeader.h"
#include "secs/BS2Device.h"
#include "secs/BS2Driver.h"
#include "secs/BS2MessageInfo.h"
#include "secs/BS2ErrorMessage.h"
#include "secs/BS2MessageDictionary.h"

#include "wxLocker.h"
#include "GemSender.h"
#include "GemReceiver.h"
#include "GemHsmsCall.h"
#include "GemDevice.h"
#include "Win32VC.h"
#include "WinLinuxVCDlg.h"

/////////////////////////////////////////////////////////////////////////////
// CDemoVCApp

BEGIN_MESSAGE_MAP(CDemoVCApp, CWinApp)
	//{{AFX_MSG_MAP(CDemoVCApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDemoVCApp construction

CDemoVCApp::CDemoVCApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CDemoVCApp object

CDemoVCApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CDemoVCApp initialization

BOOL CDemoVCApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

/*#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif*/

	CDemoVCDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
#endif
