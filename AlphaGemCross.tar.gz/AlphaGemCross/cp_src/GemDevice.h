#ifndef GEMHSMS_SECSDEVICE_H
#define GEMHSMS_SECSDEVICE_H

class GemDevice: public BS2Device
{
 public:
    GemDevice(void* parent_class);
    virtual ~GemDevice();
	virtual int open(void * = 0);
    virtual int close(int = 0);
	virtual int parse(BCHAR* data, int size);
    //virtual int put(ACE_Message_Block *mb, ACE_Time_Value *tv = 0);
    //virtual int svc(void);
    virtual int connected();
    virtual int disconnected();

	void SendHsmsMessage(int stnum, int fcnum, BS2MessageInfo* binfo);
	
//////////////
	void*				m_parent_class;
	GemHsmsCall*		m_reponse_call;

	wxCriticalSection	m_mutex_gemdevice;
};

#endif