//
// Copyright 2011 Tero Saarni
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#ifndef JNIAPI_H
#define JNIAPI_H

#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT void JNICALL  Java_com_app_alphainfo_AlphaGemApp_nativeInitJniClass(JNIEnv* jenv, jobject obj);
JNIEXPORT void JNICALL  Java_com_app_alphainfo_AlphaGemApp_nativeReleaseJniClass(JNIEnv* jenv, jobject obj);

JNIEXPORT jint JNICALL  Java_com_app_alphainfo_AlphaGemApp_nativeServerTest(JNIEnv* jenv, jobject obj, jstring str_ip, jint port);
JNIEXPORT jint JNICALL  Java_com_app_alphainfo_AlphaGemApp_nativeClientTest(JNIEnv* jenv, jobject obj, jstring str_ip, jint port);
JNIEXPORT void JNICALL  Java_com_app_alphainfo_AlphaGemApp_nativeCloseDevice(JNIEnv* jenv, jobject obj);

JNIEXPORT void JNICALL  Java_com_app_alphainfo_AlphaGemApp_nativeSetThreadWork(JNIEnv* jenv, jobject obj, jint work);
JNIEXPORT jint JNICALL  Java_com_app_alphainfo_AlphaGemApp_nativeGetLoopStatus(JNIEnv* jenv, jobject obj);

#ifdef __cplusplus
}
#endif

#endif // JNIAPI_H
