// -*- C++ -*-

//=============================================================================
/**
 *  @file    post.h
 *
 *  $Id: post.h 80826 2008-03-04 14:51:23Z wotte $
 *
 *  @author Christopher Kohlhoff <chris@kohlhoff.com>
 *
 *  This file restores the original alignment rules.
 */
//=============================================================================

// No header guard
#if defined (_MSC_VER)
# pragma pack (pop)
#elif defined (__BORLANDC__)
# pragma option pop
# pragma nopushoptwarn
# pragma nopackwarning
#endif
