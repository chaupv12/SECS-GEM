// $Id: Reactor_Impl.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ace/Reactor_Impl.h"

ACE_RCSID (ace,
           Reactor_Impl,
           "$Id: Reactor_Impl.cpp 80826 2008-03-04 14:51:23Z wotte $")

ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Reactor_Impl::~ACE_Reactor_Impl (void)
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
