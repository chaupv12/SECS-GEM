// $Id: OS_NS_sys_mman.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ace/OS_NS_sys_mman.h"

ACE_RCSID(ace, OS_NS_sys_mman, "$Id: OS_NS_sys_mman.cpp 80826 2008-03-04 14:51:23Z wotte $")

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_sys_mman.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

