// $Id: Reactor_Timer_Interface.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ace/Reactor_Timer_Interface.h"

ACE_RCSID (ace,
           Reactor_Timer_Interface,
           "$Id: Reactor_Timer_Interface.cpp 80826 2008-03-04 14:51:23Z wotte $")


ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Reactor_Timer_Interface::~ACE_Reactor_Timer_Interface()
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
