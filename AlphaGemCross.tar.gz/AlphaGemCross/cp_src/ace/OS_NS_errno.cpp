// -*- C++ -*-
// $Id: OS_NS_errno.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ace/OS_NS_errno.h"

ACE_RCSID(ace, OS_NS_errno, "$Id: OS_NS_errno.cpp 80826 2008-03-04 14:51:23Z wotte $")

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_errno.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

