// $Id: OS_Log_Msg_Attributes.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ace/OS_Log_Msg_Attributes.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_Log_Msg_Attributes.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

ACE_RCSID(ace, OS_Log_Msg_Attributes, "$Id: OS_Log_Msg_Attributes.cpp 80826 2008-03-04 14:51:23Z wotte $")
