#if defined(_WIN32)
	#define _WIN32_WINNT 0x0500
	#include <afxwin.h>
	#include "Resource.h"
#endif

#include "secs/BS2DeclAtoms.h"
#include "secs/BS2SECSReceiver.h"
#include "secs/BS2HSMSReceiver.h"
#include "secs/BS2Sender.h"
#include "secs/BS2Serial.h"
#include "secs/BS2Socket.h"
#include "secs/BS2Driver.h"
#include "secs/BS2TransactionManager.h"
#include "secs/BS2MessageInfo.h"
#include "secs/BS2ErrorMessage.h"
#include "secs/BS2Device.h"
#include "secs/BS2MessageDictionary.h"

#include "wxLocker.h"
#include "GemSender.h"
#include "GemReceiver.h"
#include "GemHsmsCall.h"
#include "GemDevice.h"
#include "WinLinuxVCDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


GemDevice::GemDevice(void* parent_class)
{
	m_parent_class	= parent_class;
	m_reponse_call	= new GemHsmsCall(this);
}

GemDevice::~GemDevice()
{
	this->close(-1);
		
	delete m_reponse_call;
}

int GemDevice::open(void *)
{
	int ret;
	
	ret = BS2Device::open();

	return ret;
}

int GemDevice::close(int exit_status)
{
	int ret;
	
	ret = BS2Device::close(exit_status);

	return ret;
}

int GemDevice::parse(BCHAR* data, int size)
{
	int						result;
	int						stnum;
	int						fcnum;
	BS2BlockHeader			header;
	BS2Message*				msgbody;
	BS2MessageInfo*			minfo;
	BS2TransactionInfo*		trinfo;
	BS2TransactionManager*	trmgr;
			
	//m_receiver->getEventInfo(minfo);
	minfo = (BS2MessageInfo*)data;

	if( minfo )
	{
		msgbody = minfo->getMessage();

		if( msgbody )
		{
			msgbody->get(&header);
			stnum = header.getStreamNum();
			fcnum = header.getFunctionNum();

			if(m_reponse_call->m_hsmsrep[stnum][fcnum+1])
			{
				this->SendHsmsMessage(stnum, fcnum+1, minfo);
			}
			else //process no function
			{
				trmgr = BS2TransactionManager::instance();

				trinfo = trmgr->buffer(&header, TRANSACTION_SEND_PRIMARY);
				if( trinfo )
					trmgr->remove(trinfo);
				
				
				trinfo = trmgr->buffer(&header, TRANSACTION_RECV_PRIMARY);
				if( trinfo )
					trmgr->remove(trinfo);
			}
		}
	}
		
	result = BS2Device::parse(data, size); //nothing to do

	return result;
}

/*int GemDevice::put(ACE_Message_Block* mb, ACE_Time_Value* tv)
{
	int ret;
	
	ret = BS2Device::put(mb, tv);

	return ret;
}*/

int GemDevice::connected()
{
	int ret;
	
	ret = BS2Device::connected();

	return ret;
}

int GemDevice::disconnected()
{
	int ret;
	
	ret = BS2Device::disconnected();

	return ret;
}

/*int GemDevice::svc(void)
{
	int ret;
	
	ret = BS2Device::svc();

	return ret;
}*/

void GemDevice::SendHsmsMessage(int	stnum, int fcnum, BS2MessageInfo* binfo)
{
	wxCriticalLocker lock(m_mutex_gemdevice);

	(m_reponse_call->*(m_reponse_call->m_hsmsrep[stnum][fcnum]))(binfo);
}
