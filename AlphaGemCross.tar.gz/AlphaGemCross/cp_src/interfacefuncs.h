//  ***************************************************************
//  AndroidUtils - Creation date: 09/12/2010
//  -------------------------------------------------------------
//  Robinson Technologies - Check license.txt for license info.
//
//  ***************************************************************
//  Programmer(s):  Seth A. Robinson (seth@rtsoft.com)
//  ***************************************************************

#ifndef INTERFACEFUNCS_H__
#define INTERFACEFUNCS_H__

#ifdef __cplusplus
extern "C" {
#endif

extern std::string Interface_GetApkFilename();

extern void Interface_InitJniClass(JNIEnv* env, jobject obj);
extern void Interface_ReleaseJniClass(JNIEnv* env, jobject obj);

//extern void Interface_InitAce(JNIEnv* env, jobject obj);
//extern void Interface_ReleaseAce(JNIEnv* env, jobject obj);

extern jint Interface_ServerTest(JNIEnv* env, jobject obj, jstring jstr_ip, jint port);
extern jint Interface_ClientTest(JNIEnv* env, jobject obj, jstring jstr_ip, jint port);
extern void Interface_CloseDevice(JNIEnv* env, jobject obj);

extern void Interface_SetThreadWork(JNIEnv* env, jobject obj, jint work);
extern int Interface_GetThreadWork();
extern void Interface_SetLoopStatus(int loop);
extern jint Interface_GetLoopStatus(JNIEnv* env, jobject obj);

#ifdef __cplusplus
}
#endif

#endif // AndroidUtils_h__
