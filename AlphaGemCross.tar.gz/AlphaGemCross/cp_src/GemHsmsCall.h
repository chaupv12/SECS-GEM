#ifndef GEMHSMS_HSMSCALL_H
#define GEMHSMS_HSMSCALL_H


class GemHsmsCall
{
 public:
	typedef void (GemHsmsCall::*HsmsReponse)(BS2MessageInfo*);

    GemHsmsCall(void* parent_class);
    ~GemHsmsCall();
	
	void	InitCall();
	
	void	Hsms_Send(BS2Message* msg_body);
	void	HSMS_S1F0(BS2MessageInfo* info);
	void	HSMS_S1F1(BS2MessageInfo* info);
	void	HSMS_S1F2(BS2MessageInfo* info);
	void	HSMS_S1F4(BS2MessageInfo* info);
	void 	HSMS_S1F18(BS2MessageInfo* info);
	void	SendS9F7FormatError(BS2MessageInfo* info, string errStr);

	void*		m_parent_class;
	HsmsReponse	m_hsmsrep[21][50];
};

#endif
