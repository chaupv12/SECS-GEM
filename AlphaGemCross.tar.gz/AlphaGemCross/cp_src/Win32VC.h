// DemoVC.h : main header file for the DemoVC application
//

#if !defined(AFX_DEMOVC_H__83BA4DD1_AD41_44C4_B927_0E110752C387__INCLUDED_)
#define AFX_DEMOVC_H__83BA4DD1_AD41_44C4_B927_0E110752C387__INCLUDED_

/////////////////////////////////////////////////////////////////////////////
// CDemoVCApp:
// See DemoVC.cpp for the implementation of this class
//
#if defined(_WIN32)
class CDemoVCApp : public CWinApp
{
public:
	CDemoVCApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDemoVCApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDemoVCApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEMOVC_H__83BA4DD1_AD41_44C4_B927_0E110752C387__INCLUDED_)
