// code which calls the actual example functions in turn

#ifndef _EXAMPLE_H
#define _EXAMPLE_H

#include "example_funcs.h"

// prints asterisks between each example
void PrintSeparator(ostream &o);

// prints a header with title for a particular example
void PrintHeader(ostream &o, const string &title);

// function which calls the actual example functions in turn
void CallAllExamples();

#endif
