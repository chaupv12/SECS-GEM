// example showing the use of an indexed view in the dynamic case

#ifndef _DYNAMICINDEXEDVIEWEXAMPLE_H
#define _DYNAMICINDEXEDVIEWEXAMPLE_H

#include "example_core.h"

// Dynamic IndexedDBView example
void DynamicIndexedViewExample();

#endif
