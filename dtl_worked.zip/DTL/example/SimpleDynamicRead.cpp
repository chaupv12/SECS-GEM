// example of reading from a dynamic view ... when you don't know the
// columns or their types

#include "SimpleDynamicRead.h"

// Read the contents of a table and print the resulting rows
void SimpleDynamicRead() {

	// Our query will be "SELECT * FROM DB_EXAMPLE"
	DynamicDBView<> view("DB_EXAMPLE", "*");

	// NOTE: We need to construct r from the view itself since we
	// don't know what fields the table will contain.
	// We therefore make a call to the DataObj() function to have the
	// table return us a template row with the correct number of fields
	// and field types.
	// We use this construction since we can't be guaranteed that the table
	// is non-empty & we want to still display column names in this case.
	variant_row s(view.DataObj());

	// Print out the column names
	vector<string> colNames = s.GetNames();
	for (vector<string>::iterator name_it = colNames.begin(); name_it != colNames.end(); ++name_it)
		cout << (*name_it) << " ";
	cout << endl;

	// Print out all rows and columns from our query
	DynamicDBView<>::select_iterator print_it = view.begin();
	for (print_it = view.begin(); print_it != view.end(); ++print_it)
	{
		 variant_row r = *print_it;
		 for (size_t i = 0; i < r.size(); ++i)
		 	cout << r[i] << " ";
		 cout << endl;
	}
}
