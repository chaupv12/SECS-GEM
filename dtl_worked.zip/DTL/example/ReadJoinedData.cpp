// example for reading data from joined tables

#include "ReadJoinedData.h"

// Read JoinExample objects from the database using a query that
// joins the DB_EXAMPLE and DB_SAMPLE tables
vector<JoinExample> ReadJoinedData()
{
 vector<JoinExample> results;

 // construct view
 // note here that we use a custom parameter class for JoinExample
 // rather than DefaultParamObj<JoinExample>

 DBView<JoinExample, JoinParamObj> view("DB_EXAMPLE,  DB_SAMPLE", 
    BCAJoinExample(), "WHERE (INT_VALUE = (?) AND STRING_VALUE = (?)) AND "
    "(SAMPLE_INT = (?) OR SAMPLE_STR = (?)) "
    "ORDER BY SAMPLE_LONG",
    BPAJoinParamObj());

 // loop through query results and add them to our vector
 DBView<JoinExample, JoinParamObj>::select_iterator read_it  = view.begin();

 // assign paramteter values as represented by the (?) placeholders
 // in the where clause for our view
 read_it.Params().intValue = 3;
 read_it.Params().strValue = "Join Example";
 read_it.Params().sampleInt = 1;
 read_it.Params().sampleStr = "Joined Tables";

 for ( ; read_it != view.end(); ++read_it)
 { 
  results.push_back(*read_it);
 }

 return results;
}

