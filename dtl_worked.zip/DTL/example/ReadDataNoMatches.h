/***************************************************************************
                          ReadDataNoMatches.h  -  description
                             -------------------
    begin                : Wed Mar 7 2001
    copyright            : (C) 2001 by 
    email                : 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
// example function for reading from a view that returns no records

#ifndef _READDATANOMATCHES_H
#define _READDATANOMATCHES_H

#include "example_core.h"

// should return an empty vector of Example objects as we're feeding the view
// a query that should return no matches
vector<Example> ReadDataNoMatches();

#endif
