#include "example_core.h"


// Set parameters function for Example ... used by IndexedDBView<Example> to set dynamic query parameters
// Dynamic query parameters are indicated by (?) in our query string for the IndexedDBView
void SetParamsExample(ParamObjExample &params)
{
	// set parameter values
	params.lowIntValue = 2;
	params.highIntValue = 8;
	params.strValue = "Example";
	
	TIMESTAMP_STRUCT paramDate = {2000, 1, 1, 0, 0, 0, 0};
	params.dateValue = paramDate;
}

// this function is used to reset the Example table in the database
void ResetTables(DBConnection &conn)
{
	DBStmt("DELETE FROM DB_EXAMPLE", conn).Execute();
	DBStmt("INSERT INTO DB_EXAMPLE SELECT * FROM DB_EXAMPLE_BACKUP", conn).Execute();
}

// test out TableDiff() using old and new views
void TestTableDiff()
{
  // first for DBView's
  DBView<Example> new_table("DB_EXAMPLE");
  DBView<Example> old_table("DB_EXAMPLE_BACKUP");
  TableDiff(cout, old_table, new_table);

  cout << "--- should be same for IndexedDBViews --- " << endl;

  // now do the same thing for an IndexedDBView
  IndexedDBView<DBView<Example> > new_idx_table(new_table, "PrimaryIndex; STRING_VALUE");
  IndexedDBView<DBView<Example> > old_idx_table(old_table, "PrimaryIndex; STRING_VALUE");
  TableDiff(cout, old_idx_table, new_idx_table);

}
