// example illustrating the use of an IndexedDBView for Example objects

#ifndef _INDEXEDVIEWEXAMPLE_H
#define _INDEXEDVIEWEXAMPLE_H

#include "example_core.h"

// Example of using an IndexDBView to read, insert and update records in a container / database
void IndexedViewExample();

#endif
