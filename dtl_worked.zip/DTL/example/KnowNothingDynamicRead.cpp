// this example gives a real feeling for the power of dynamic indexed views
// when you know nothing at all about the columns, not even the number or the names
#include "KnowNothingDynamicRead.h"

// show the power of a dynamic indexed view ... know nothing about columns
// until runtime at all ...
void KnowNothingDynamicRead()
{
   DynamicDBView<> dynamic_view("DB_EXAMPLE", "*");

   DynamicIndexedDBView< DynamicDBView<> >  
	 indexed_view(dynamic_view);

   // find stuff to index off of
   variant_row vr(indexed_view.DataObj());

   // print out column names
   vector<string> colNames = vr.GetNames();

   cout << "Field Names of this know nothing indexed view:" << endl;
   copy(colNames.begin(), colNames.end(), ostream_iterator<string>(cout,", "));
   cout << endl;

   // a vector to store the data objects so we can find() them later
   vector<variant_row> use_to_find;

   // output the data from the objects in the indexed_view via the primary key
   for (DynamicIndexedDBView<DynamicDBView<> >::indexed_iterator idx_it = 
			indexed_view.begin(); idx_it != indexed_view.end(); ++idx_it)
   {
	   vr = *idx_it;

	   for (vector<string>::iterator col_it = colNames.begin(); 
			col_it != colNames.end(); ++col_it)
	   {
		   cout << vr[*col_it] << " ";
       }

	   use_to_find.push_back(vr); // store the object as found

	   cout << endl;
   }

   // now find each of the items again in the view to illustrate find()
   // should get the same table as above (maybe in a different order)
   cout << "Doing a find() on each element recorded" << endl;
   for (vector<variant_row>::iterator find_it = use_to_find.begin(); find_it != use_to_find.end(); ++find_it)
   {
	   vr = *find_it;

	   DynamicIndexedDBView<DynamicDBView<> >::indexed_iterator idx_it =
			indexed_view.find(vr);

	   cout << (idx_it != indexed_view.end() ? "Found: " : "Not found: ");

	   for (vector<string>::iterator col_it = colNames.begin(); 
			col_it != colNames.end(); ++col_it)
	   {
		   cout << vr[*col_it] << " ";
       }

	   cout << endl;
   }

}
