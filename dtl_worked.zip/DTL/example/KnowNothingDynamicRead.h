// this example gives a real feeling for the power of dynamic indexed views
// when you know nothing at all about the columns, not even the number or the names
#ifndef _KNOWNOTHINGDYNAMICREAD_H
#define _KNOWNOTHINGDYNAMICREAD_H

#include "example_core.h"

// show the power of a dynamic indexed view ... know nothing about columns
// until runtime at all ...
void KnowNothingDynamicRead();

#endif
