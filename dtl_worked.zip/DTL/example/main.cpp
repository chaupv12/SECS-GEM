#include "Example.h"


int main(int argc, char **argv)
{
    CallAllExamples();

	return 0;
}
