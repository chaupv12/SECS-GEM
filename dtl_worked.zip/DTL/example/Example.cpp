#include "Example.h"

const string DSN_str = "UID=example;PWD=example;DSN=example;";
const TIMESTAMP_STRUCT now = {2000, 12, 15, 0, 0, 0, 0};

// prints out asterisks between each example function
void PrintSeparator(ostream &o)
{
   o << endl;
   o << "********************************" << endl;
   o << endl;
}

// prints a header with title for a particular example
void PrintHeader(ostream &o, const string &title)
{
   o << "!!!!!!!!!!!!!!!!!!!!! Begin Example " << title << " !!!!!!!!!!!!!!!!!!!! ";
   o << endl;
}

// function which calls all example functions in turn
void CallAllExamples()
{
   try
   {
		
   DBConnection::GetDefaultConnection().Connect(DSN_str);

   // to auto commit, just uncomment the following line
   // DBConnection::GetDefaultConnection().SetAutoCommit(true);

   ResetTables();

   PrintHeader(cout, "ReadData()");

   // read initial data from table
   cout << "Initial Examples read from database:" << endl;
   vector<Example> examples = ReadData();
   copy(examples.begin(), examples.end(), ostream_iterator<Example>(cout, "\n"));

   PrintSeparator(cout);

   // now insert Example objects into the database

   PrintHeader(cout, "WriteData()");

   cout << "Trying to insert the following Example objects into DB" << endl;

   vector<Example> ins;
   
   ins.push_back(Example(555, "Arthur", 1.1, 1, now));
   ins.push_back(Example(311, "", 3.99, 91, now)); // should fail on InsValidate()
   ins.push_back(Example(666, "Langham", 2.2, 2, now));
   ins.push_back(Example(222, "Positron", -34.77, 29, now)); // should fail (ditto)
   ins.push_back(Example(777, "Lala", 3.3, 3, now));
   ins.push_back(Example(911, "The Club", 102.32, 67, now)); // should fail (ditto)

   copy(ins.begin(), ins.end(), ostream_iterator<Example>(cout, "\n"));

   cout << "Only three items should succeed on insert!  The rest represent 'bad' "
      "data we are using to test the InsValidate function!" << endl;

   WriteData(ins);

   vector<Example> updated_examples = ReadData();

   cout << "Example objects inserted into DB according to TableDiff():" << endl;
   TableDiff(cout, examples, updated_examples);

   PrintSeparator(cout);

   // see if table diff results are the same with using the view of the original
   // table versus that of the current one
   PrintHeader(cout, "TestTableDiff()");

   cout << "TableDiff() results should match ... we get:" << endl;
   
   TestTableDiff();

   PrintSeparator(cout);

   // Read a joined view
   
   ResetTables();
   
   PrintHeader(cout, "ReadJoinedData()");

   vector<JoinExample> join_examples = ReadJoinedData();

   cout << "Read these JoinExamples from the DB:" << endl;
   copy(join_examples.begin(), join_examples.end(),
	    ostream_iterator<JoinExample>(cout, "\n"));

   PrintSeparator(cout);

   // now call an example which uses an indexed view with Examples
   ResetTables();

   PrintHeader(cout, "IndexedViewExample()");
   
   vector<Example> old_examples = ReadData();

   IndexedViewExample();

   vector<Example> after_idx_examples = ReadData();

   cout << "Changes resulting from call to indexed view example:" << endl;
   
   TableDiff(cout, old_examples, after_idx_examples);

   PrintSeparator(cout);

   // read some objects from a dynamic view

   ResetTables();

   PrintHeader(cout, "SimpleDynamicRead()");

   cout << "Reading objects from a dynamic view:" << endl;

   SimpleDynamicRead();
   
   PrintSeparator(cout);

   // use a indexed view for the dynamic case
   // as we are working with DB_EXAMPLE, TableDiff() can still
   // crunch on Example objects
   ResetTables();
 
   PrintHeader(cout, "DynamicIndexedViewExample()");

   vector<Example> old_data = ReadData();
 
   DynamicIndexedViewExample();

   cout << "Changes after operating on dynamic indexed view:" << endl;
   
   vector<Example> new_data = ReadData();

   TableDiff(cout, old_data, new_data);

   PrintSeparator(cout);

   // print out stuff from a dynamic indexed view where we know nothing
   ResetTables();
   PrintHeader(cout, "KnowNothingDynamicRead()");

   KnowNothingDynamicRead();

   PrintSeparator(cout);

   PrintHeader(cout, "ReadDataNoMatches()");

   // read data from table
   cout << "Should read no Examples from database ... " << endl;
   
   vector<Example> examples_empty = ReadDataNoMatches();
   
   if (examples_empty.empty())
   {
	   cout << "Confirmed ... no Examples read from database!" << endl;
   }
   else
   {
	   cout << "Examples read from database:" << endl;
	   copy(examples_empty.begin(), examples_empty.end(), 
		   ostream_iterator<Example>(cout, "\n"));
   }

   PrintSeparator(cout);
   
   ResetTables();

   PrintHeader(cout, "RangeInsertExample()");

   // must release this connection so that other connections may be made
   // without being locked out
   DBConnection::GetDefaultConnection().Release();

   // test range insert transactions using a view
   // transaction will fail, so should not change DB
   RangeInsertExample();

   PrintSeparator(cout);

	 // need to reset just in-case above example does not rollback properly
   DBConnection::GetDefaultConnection().Connect();
	 ResetTables();
   DBConnection::GetDefaultConnection().Release();


   PrintHeader(cout, "RangeIndexInsertExample()");

   // test range insert transactions using an indexed view
   // transaction will fail, so should not change DB
   RangeIndexInsertExample();

   PrintSeparator(cout);

	 // need to reset just in-case above example does not rollback properly
   DBConnection::GetDefaultConnection().Connect();
	 ResetTables();
   DBConnection::GetDefaultConnection().Release();


   PrintHeader(cout, "RangeIndexUpdateExample()");

   // test range update transactions using an indexed view
   // transaction will fail, so should not change DB
   RangeIndexUpdateExample();

   PrintSeparator(cout);

   DBConnection::GetDefaultConnection().Connect();
   ResetTables();
   }

   catch (RootException &ex)
   {
	cout << "Exception thrown" << endl;
	cout << ex << endl;
   }
}
