#include "ReadData.h"

// example code for reading from a view

// Read the contents of the DB_EXAMPLE table and return a vector of the
// resulting rows
vector<Example> ReadData()
{
 vector<Example> results;
 DBView<Example> view("DB_EXAMPLE");

 DBView<Example>::select_iterator read_it = view.begin();
 for ( ; read_it != view.end(); ++read_it)
 {
  results.push_back(*read_it);
 }

 return results;
}


