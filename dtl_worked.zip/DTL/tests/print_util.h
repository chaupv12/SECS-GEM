// handy utilities for tests ... making output easier to delimit
// Initial: 12/27/2000 - grabbed from example project

#ifndef _PRINT_UTIL_H
#define _PRINT_UTIL_H

#include <iostream>
#include <string>

using namespace std;

// prints out asterisks between each example function
void PrintSeparator(ostream &o);

// prints a header with title for a particular example
void PrintHeader(ostream &o, const string &title);

// Table difference function.
// Takes two containers and prints out the differences (via set difference) between the containers.
// container 1 = "original" values, container 2 = "new" values
template<class Container> void TableDiff(ostream &o, const Container &cont1, const Container &cont2)
{
   typedef typename Container::value_type value_type;

   // copy container data into sets as set_symmetric_difference needs a sorted list to do its work
   multiset<value_type> set1;
   multiset<value_type> set2;

   // Slight workaround here, M$ compiler 6.0 STL library can only work with pointers not iterators
   // Therefore, cannot do this at set construction time as recommended by the standard
   copy(cont1.begin(), cont1.end(), inserter(set1, set1.begin()));
   copy(cont2.begin(), cont2.end(), inserter(set2, set2.begin()));

   // Show set1 - set2 = deleted / changed items
   o << "deleted / changed items:" << endl;
   set_difference(set1.begin(), set1.end(), set2.begin(), set2.end(),
				  ostream_iterator<value_type>(o, "\n"));
  
    // Show set2 - set1 = inserted / changed items
   o << "inserted / changed items:" << endl;
   set_difference(set2.begin(), set2.end(), set1.begin(), set1.end(),
				  ostream_iterator<value_type>(o, "\n"));

#if 0
   // Show all differences as single set
   set_symmetric_difference(set1.begin(), set1.end(), set2.begin(), set2.end(),
				  ostream_iterator<value_type>(o, "\n"));
#endif
}

#endif
