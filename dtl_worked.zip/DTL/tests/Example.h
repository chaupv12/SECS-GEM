// Example client code for a single table
// Initial: 9/5/2000 - MG
// Edited: 12/20/2000 - MG - added namespace support

#ifndef _EXAMPLE_H
#define _EXAMPLE_H

#include "dtl.h"
using namespace dtl;

#include "print_util.h"

// single table example data class ... note the class declaration is now free of any of these // DB abstractions

// assume the corresponding data for this class is in the DB_EXAMPLE table in
// the database 

class Example
{
  public:							// tablename.columnname:
	int exampleInt;	    			// DB_EXAMPLE.INT_VALUE
	string exampleStr;				// DB_EXAMPLE.STRING_VALUE
	double exampleDouble;			// DB_EXAMPLE.DOUBLE_VALUE
	long exampleLong;				// DB_EXAMPLE.EXAMPLE_LONG
	TIMESTAMP_STRUCT exampleDate;	// DB_EXAMPLE.EXAMPLE_DATE

	Example() : exampleInt(0), exampleStr(""), exampleDouble(0.0), exampleLong(0)
	{ 
		TIMESTAMP_STRUCT exDate = {2000, 6, 6, 13, 13, 0, 0};
		exampleDate = exDate;
	}

	Example(int exInt, const string &exStr, double exDouble, long exLong,
		const TIMESTAMP_STRUCT &exDate) :
	   exampleInt(exInt), exampleStr(exStr), exampleDouble(exDouble), exampleLong(exLong),
	   exampleDate(exDate)
	{ }

	friend bool operator==(const Example &ex1, const Example &ex2)
	{
	  return (ex1.exampleInt == ex2.exampleInt) &&
			 (ex1.exampleStr == ex2.exampleStr) &&
			 (ex1.exampleDouble == ex2.exampleDouble) &&
			 (ex1.exampleLong == ex2.exampleLong) &&
			 (ex1.exampleDate == ex2.exampleDate);
	}

	friend bool operator<(const Example &ex1, const Example &ex2)
	{	
		if (ex1.exampleInt < ex2.exampleInt)
		  return true;
		if (ex1.exampleInt > ex2.exampleInt)
		  return false;

		if (ex1.exampleStr < ex2.exampleStr)
		  return true;
		if (ex1.exampleStr > ex2.exampleStr)
		  return false;

		if (ex1.exampleDouble < ex2.exampleDouble)
		  return true;
		if (ex1.exampleDouble > ex2.exampleDouble)
		  return false;

		if (ex1.exampleLong < ex2.exampleLong)
		  return true;
		if (ex1.exampleLong > ex2.exampleLong)
		  return false;

		return (ex1.exampleDate < ex2.exampleDate);
	}

	friend ostream& operator<<(ostream &o, const Example &ex)
	{
		o << "Example(" << ex.exampleInt << ", \"" << ex.exampleStr << "\", ";
		o << ex.exampleDouble << ", " << ex.exampleLong << ", ";
		o << ex.exampleDate << ")";
		return o;

	}
};


// specialization of DefaultParamObj for Example
// even though we're modifying the behavior of the default parameter object for
// Example, users can still create any number of parameter object classes for a single
// data class

// need to specialize within namespace
BEGIN_DTL_NAMESPACE
template<> class DefaultParamObj<Example>
{
    public:
       int lowIntValue;
	   int highIntValue;
	   string strValue;
	   TIMESTAMP_STRUCT dateValue;
};

// BCA for Example ... needed to store bindings between
// view  records and members in JoinExample objects
// as a reference is passed in for each rowbuf member, the member's address
// will be stored in the BoundColumn object for the corresponding DB column

// due to compiler bug (?), must explicitly qualify with dtl::
template<> class DefaultBCA<Example>
{
public:
	void operator()(BoundIOs &boundIOs, Example &rowbuf)
    {
	  boundIOs["INT_VALUE"] 	 == rowbuf.exampleInt;
	  boundIOs["STRING_VALUE"]   == rowbuf.exampleStr;
	  boundIOs["DOUBLE_VALUE"]   == rowbuf.exampleDouble;
	  boundIOs["EXAMPLE_LONG"]   == rowbuf.exampleLong;
	  boundIOs["EXAMPLE_DATE"]   == rowbuf.exampleDate;
	}
};


// void DelBCAExample(BoundIOs &boundIOs, Example &rowbuf);

// specialization of DefaultInsValidate for Example
// can have any number of InsValidate functions for a single data class just as with
// ParamObj's ... business rule constraint we wish to enforce for all Examples
// bool DefaultInsValidate(Example &rowbuf);

// default behavior with instantiated DefaultSelValidate<Example> is the behavior we
// want here ... so no extra code needed here
// (in this example, assume data is always guaranteed to be valid after use of
// DefaultInsValidate<Example> or other InsValidate function
// unless some columns are null)

// BPA for Example using DefaultParamObj<Example> as the param. obj.
// we're binding
// initialize parameter values here

// due to compiler bug (?), must explicitly qualify with dtl::
template<> class DefaultBPA<DefaultParamObj<Example> >
{
public:
	void operator()(BoundIOs &boundIOs, DefaultParamObj<Example> &paramObj)
	{
	  boundIOs[0] == paramObj.lowIntValue;
	  boundIOs[1] == paramObj.highIntValue;
	  boundIOs[2] == paramObj.strValue;
	  boundIOs[3] == paramObj.dateValue;
	}
};

END_DTL_NAMESPACE

// BCA for Example ... needed to store bindings between
// view  records and members in JoinExample objects
// as a reference is passed in for each rowbuf member, the member's address
// will be stored in the BoundColumn object for the corresponding DB column
// void BCAExample(BoundIOs &boundIOs, Example &rowbuf);

class BCAExampleObj
{
public:
	void operator()(BoundIOs &boundIOs, Example &rowbuf)
    {
	   boundIOs["INT_VALUE"] 	   == rowbuf.exampleInt;
	   boundIOs["STRING_VALUE"]    == rowbuf.exampleStr;
	   boundIOs["DOUBLE_VALUE"]    == rowbuf.exampleDouble;
	   boundIOs["EXAMPLE_LONG"]   == rowbuf.exampleLong;
	   boundIOs["EXAMPLE_DATE"]   == rowbuf.exampleDate;
	}
};


class BPAExampleObj
{
public:
	void operator()(BoundIOs &boundIOs, DefaultParamObj<Example> &paramObj)
	{
	  boundIOs[0] == paramObj.lowIntValue;
	  boundIOs[1] == paramObj.highIntValue;
	  boundIOs[2] == paramObj.strValue;
	  boundIOs[3] == paramObj.dateValue;
	}

};


class DelBCAExampleObj
{
public:
	void operator()(BoundIOs &boundIOs, Example &rowbuf)
	{
      boundIOs["STRING_VALUE"]   == rowbuf.exampleStr;
	  boundIOs["EXAMPLE_DATE"]   == rowbuf.exampleDate;
	}
	
};

class DelBPAExampleObj
{
public:
	void operator()(BoundIOs &boundIOs, DefaultParamObj<Example> &paramObj)
	{
	  boundIOs[0] == paramObj.strValue;
	  boundIOs[1] == paramObj.lowIntValue;
	}
};

// set parameters function for Example ... used by IndexedDBView<Example>
void SetParamsExample(DefaultParamObj<Example> &params);

// read some Example objects from the database and return a vector of
// the results
vector<Example> SimpleRead();
vector<Example> ReadData();

// print out Example objects directly from a DBView
void PrintExamplesFromView();

// typedef DBView<Example, DefaultParamObj<Example>, BCAEx, BPAEx> BasicView;
// typedef IndexedDBView<Example, DefaultParamObj<Example>, BCAEx, BPAEx> BasicIdxView;

// write some Example objects to the database
void WriteData(const vector<Example> &examples);

// update Example object (with new values)  meeting a query in the database
void UpdateData();

// delete some Examples from the database meeting the query
void DeleteData();

// read Examples from indexed view to make sure data gets in IndexedDBView's
// internal list<DataObj> properly
vector<Example> ReadDataFromIndexedView();

// read Examples from indexed view that have the given Example object as (primary) key
// with a single key known as IndexString
vector<Example> ReadFilteredDataPK(Example &key);

// read Example objects using the index IndexString by name
vector<Example> ReadFilteredDataByName(Example &key);

// read Example objects using the index IndexString by name, but using the
// datafield rather than the object to guide the search
vector<Example> ReadDataIdxByStrUseDF(const string &strVal);

// read Example objects using the string as a datafield value for the PK
// using IndexString as PK
vector<Example> ReadDataIdxByStrUseDFAndPK(const string &strVal);

// read Example objects using the passed in
// uses a two field key
vector<Example> ReadTwoFieldKeyByName(Example &key);

// read Example objects using the PK
// uses atwo field key
vector<Example> ReadTwoFieldKeyPK(Example &key);

// read Example objects using the string and date values as fields in a key
vector<Example> ReadTwoFieldKeyByNameDF(const string &strVal, const TIMESTAMP_STRUCT &dateVal);

// same as above, but as PK
vector<Example> ReadTwoFieldKeyDFAndPK(const string &strVal, const TIMESTAMP_STRUCT &dateVal);

// test the insertion of Example objects into IndexedDBView using *unbound* mode
void TestUnboundInsert();

// test the erasing of Example objects from the IndexedDBView using *unbound* mode
void TestUnboundErase();

// test the insertion of Example objects into IndexedDBView using *bound* mode
void TestBoundInsert();

// test the erasing of Example objects from the IndexedDBView using *unbound* mode
// using all fields
void TestBoundEraseUAF();

// test the erasing of Example objects from the IndexedDBView using *bound* mode
// using only the PK fields
void TestBoundErasePK();

void TestBoundUpdate();

void IndexedViewExample();

void TestDynamicView();
void SimpleDynamicRead();
void SimpleDynamicWrite();

// dynamic IndexedDBView example
void DynamicIndexedViewExample();

void test_variant(void);

// CountedPtr derived test
class DerivedExample : public Example
{

};

void TestCountedPtr();

void TestIOStates();

// used in for_each() example code
inline void print_example_fn(const Example &example)
{
	cout << example << endl;
}

class print_example : public unary_function<const Example &, void>
{
public:
	void operator()(const Example &example) const
	{
		cout << example << endl;
	}
};

// example showing use of for_each() on a DBView
void for_each_example();

// test out cb_ptr_fun() code some more
inline void BCAExample(BoundIOs &boundIOs, Example &rowbuf)
{
	   boundIOs["INT_VALUE"] 	   == rowbuf.exampleInt;
	   boundIOs["STRING_VALUE"]    == rowbuf.exampleStr;
	   boundIOs["DOUBLE_VALUE"]    == rowbuf.exampleDouble;
	   boundIOs["EXAMPLE_LONG"]   == rowbuf.exampleLong;
	   boundIOs["EXAMPLE_DATE"]   == rowbuf.exampleDate;
}

inline bool InsValExample(Example &example)
{
	return true;
}

inline bool SelValExample(BoundIOs &boundIOs, Example &example)
{
	DefaultSelValidate<Example> sel_val;
	return sel_val(boundIOs, example);
}

inline dtl_ios_base::MeansOfRecovery 
	AlwaysThrowsExample(RootException &ex, dtl_ios_base &base,
		Example &example, DefaultParamObj<Example> &params)
{
	return dtl_ios_base::THROW_EXCEPTION;
}

// used for binder test
inline Example AddToExampleString(Example example, string toAdd)
{
	Example result(example);
	result.exampleStr += toAdd;

	return result;
}

void TestCBPtrFun();

// one more algorithm check
void TestIndexedInsertViaAlgorithm();

#endif
