// handy utilities for tests ... making output easier to delimit
// Initial: 12/27/2000 - grabbed from example project

#include "print_util.h"

// prints out asterisks between each example function
void PrintSeparator(ostream &o)
{
   o << endl;
   o << "********************************" << endl;
   o << endl;
}

// prints a header with title for a particular example
void PrintHeader(ostream &o, const string &title)
{
   o << "!!!!!!!!!!!!!!!!!!!!! Begin Example " << title << " !!!!!!!!!!!!!!!!!!!! ";
   o << endl;
}
