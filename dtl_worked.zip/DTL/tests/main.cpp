// main code to drive test of DB Astractions
// Initial: 9/5/2000 - MG
// Reviewed: 11/12/2000 - CJ
// Edited: 12/20/2000 - MG - added namespace support

#include "dtl.h"
using namespace dtl;

const string DSN_str = "UID=example;PWD=example;DSN=example;";

#define EXAMPLE
//#define JOIN_EXAMPLE

// ************* Uncomment if you wish to run Example.cpp ***********************
#ifdef EXAMPLE

#include "Example.h"
#include "TestExceptions.h"

const TIMESTAMP_STRUCT today = {1999, 9, 29, 0, 0, 0, 0};
const TIMESTAMP_STRUCT y2k = {2000, 1, 1, 0, 0, 0, 0};

int main(int argc, char **argv)
{
try
  {
	test_variant();

	DBConnection::GetDefaultConnection().Connect(DSN_str);
	
	// to auto commit, just uncomment the following line
	// DBConnection::GetDefaultConnection().SetAutoCommit(true);

	DBStmt("DELETE FROM DB_EXAMPLE").Execute();
	DBStmt("INSERT INTO DB_EXAMPLE SELECT * FROM DB_EXAMPLE_BACKUP").Execute();
	
	// try printing out contents of initial view
	PrintExamplesFromView();

	SimpleDynamicRead();
	TestDynamicView(); 

	// dynamic IndexedDBView example
    DynamicIndexedViewExample();

	// get initial contents of Example table
	vector<Example> result_vec = ReadData();
	vector<Example> full_result_vec = SimpleRead();

	IndexedViewExample();

	// reads based on use of keys ... should give us the same results
	// as ReadData() though the data may be in a different order
    vector<Example> list_data = ReadDataFromIndexedView();

	// construct Example object to use for testing indexing
	Example index_test(3, "Example", 0, 0, y2k);

	// these first four tests should all yield the same results
	// (though maybe in various orders)
	vector<Example> data_by_name = ReadFilteredDataByName(index_test);
 	vector<Example> data_by_PK = ReadFilteredDataPK(index_test);
    vector<Example> data_by_DF = ReadDataIdxByStrUseDF("Example");
	vector<Example> data_by_DF_PK = ReadDataIdxByStrUseDFAndPK("Example");

	TestUnboundInsert();

	TestUnboundErase();

	TestBoundInsert();

	// TestBoundErasePK();

	TestBoundUpdate();

	// tests for two fields ... both using strValue and dateValue
	vector<Example> data_2_fields_by_name =
									ReadTwoFieldKeyByName(index_test);
	vector<Example> data_2_fields_by_PK =
									ReadTwoFieldKeyPK(index_test);
	vector<Example> data_2_fields_DF = ReadTwoFieldKeyByNameDF("Example", y2k);
	vector<Example> data_2_fields_DF_PK = ReadTwoFieldKeyDFAndPK("Example", y2k);

	vector<Example> ex_obj_vec;

	// construct some Example objects here to write
	ex_obj_vec.push_back(Example(5, "Example", 54.32, 45, today));
	ex_obj_vec.push_back(Example(34, "New Record", 333.333, 99, today));
	ex_obj_vec.push_back(Example(1111, "Ascension", 234.33, 12, today));

	// insert
	WriteData(ex_obj_vec);

    result_vec = ReadData();

	// update
	UpdateData();

	result_vec = ReadData();

	// delete
	DeleteData();

	result_vec = ReadData();

	SimpleDynamicWrite();

	TestIOStates();

	TestExceptions();

	for_each_example();

	TestCBPtrFun();

	TestIndexedInsertViaAlgorithm();
  }

  catch (RootException &ex)
  {
	cout << "Exception thrown" << endl;
	cout << ex << endl;
  }

  return 0;
}

#endif // ************************ End of Example Test ****************************

// ************** Uncomment if you wish to run JoinExample.cpp **********************
#ifdef JOIN_EXAMPLE

#include "JoinExample.h"

int main(int argc, char **argv)
{
  try
  {
	DBConnection::GetDefaultConnection().Connect(DSN_str);
	DBStmt("DELETE FROM DB_EXAMPLE").Execute();
	DBStmt("INSERT INTO DB_EXAMPLE SELECT * FROM DB_EXAMPLE_BACKUP").Execute();

	// get contents of joined Example and JoinExample tables
	vector<JoinExample> result_vec = ReadJoinedData();

	JoinExample index_test(0, "", 0.0, 2222, 0.0);
	vector<JoinExample> list_data = ReadJoinedDataFromIndexedView();
 	vector<JoinExample> data_by_PK = ReadJoinedFilteredDataPK(index_test);

  }

  catch (RootException &ex)
  {
	cout << "Exception thrown" << endl;
	cout << ex << endl;
  }

  return 0;
}
#endif // ***************** End JoinExample Test ************************
