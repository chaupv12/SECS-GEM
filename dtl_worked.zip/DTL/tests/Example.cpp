// Example client code for a single table
// Initial: 9/5/2000 - MG
// Reviewed: 11/12/2000 - CJ
// Edited: 12/20/2000 - MG - added namespace support

#include "Example.h"
using namespace dtl;


// set parameters function for Example ... used by IndexedDBView<Example>
void SetParamsExample(DefaultParamObj<Example> &params)
{
	// set parameter values
	params.lowIntValue = 2;
	params.highIntValue = 8;
	params.strValue = "Example";
	
	TIMESTAMP_STRUCT paramDate = {2000, 1, 1, 0, 0, 0, 0};
	params.dateValue = paramDate;
}

// read the contents of a single table and return a vector the resulting rows
vector<Example> SimpleRead() {
	vector<Example> results;
	DBView<Example> view("DB_EXAMPLE");

	back_insert_iterator<vector<Example> > i(results);
	copy(view.begin(), view.end(), i);
	return results;
}

// Read the contents of a table and print the resulting rows
void SimpleDynamicRead() {

	// Our query will be "SELECT * FROM DB_EXAMPLE"
	DynamicDBView<> view("DB_EXAMPLE", "*");

	// NOTE: We need to construct r from the view itself since we
	// don't know what fields the table will contain.
	// We therefore make a call to the DataObj() function to have the
	// table return us a template row with the correct number of fields
	// and field types.
	// We use this construction since we can't be guaranteed that the table
	// is non-empty & we want to still display column names in this case.
	variant_row s(view.DataObj());

	// Print out the column names
	vector<string> colNames = s.GetNames();
	for (vector<string>::iterator name_it = colNames.begin(); name_it != colNames.end(); name_it++)
	{
		cout << (*name_it) << " ";
	}
	cout << endl;

	// Print out all rows and columns from our query
	DynamicDBView<>::select_iterator print_it;
	for (print_it = view.begin(); print_it != view.end(); print_it++)
	{
		variant_row r = *print_it;
#if 0
		for (size_t i = 0; i < r.size(); i++)
		{
			cout << r[i] << " ";
		}
#endif
		cout << r << endl;
	}
}

// Insert two rows into a table with unknown fields
void SimpleDynamicWrite() {
	TIMESTAMP_STRUCT paramDate = {2012, 12, 23, 0, 0, 0, 0}; 
	// Mayan DOOMSDAY! End of the Mayan 5126 year long calendar cycle starting from May 1, 3094 B.C.
	// Date is 13.13.13.0.0.0.0  4 Ahaw, 3 K'ank'in
	
	DynamicDBView<> view("DB_EXAMPLE", "*");

	DynamicDBView<>::insert_iterator write_it;
	write_it = view;

	// NOTE: We need to construct r from the view itself since we
	// don't know what fields the table will contain.
	// We therefore make a call to the DataObj() function to have the
	// table return us a template row with the correct number of fields
	// and field types.
	variant_row r(view.DataObj());

	// Prepare the number of the beast!
	// Set all fields to the value 6,
	// except for the last column which is a date and cannot
	// currently accept numeric values

  size_t i = 0;

	for (i = 0; i < r.size()-1; i++)
	{
		 r[i] = 6;
	}
	r[i] = paramDate;  // set the Doomsdate

	// insert the number
	*write_it = r;
	write_it++;

	// Prepare the number of angels who stand before
	// the throne of God!
	// Set all fields to the value 7,
	// except for the last column which is a date and cannot
	// currently accept numeric values
	for (i = 0; i < r.size()-1; i++)
	{
		 r[i] = 7;
	}
	r[i] = paramDate;

	// insert the number
	*write_it = r;
	write_it++;
}


// read some Example objects from the database and return a vector of
// the results
vector<Example> ReadData()
{
	vector<Example> results;

	// construct view
	// DBView<Example> is actually DBView<Example, 
    // DefaultParamObj<Example> > thanks to the default argument to the DBView
	// template

	DBView<Example>
		view("DB_EXAMPLE", BCAExampleObj(),
		"WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE < (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

	// loop through query results and add them to our vector
	// in this loop, read_it.GetLastCount() records read from DB

	DBView<Example>::select_iterator read_it = view.begin();

	// set parameter values for the WHERE clause in our SQL query
	read_it.Params().lowIntValue = 2;
	read_it.Params().highIntValue = 8;
	read_it.Params().strValue = "Example";
	
	TIMESTAMP_STRUCT paramDate = {2000, 1, 1, 0, 0, 0, 0};
	read_it.Params().dateValue = paramDate;

	for ( ; read_it != view.end();  read_it++)
	{
		// note that the read_iterator::GetLastCount()  is incremented in operator++()
		// remember that the record is fetched and thus the count incremented
		// before operator*() is applied to the read_iterator

		cout << "Reading element #" << read_it.GetLastCount() << endl;
		results.push_back(*read_it);

		cout << "read_it->exampleInt = " << read_it->exampleInt << endl;
		cout << "read_it->exampleStr = " << read_it->exampleStr << endl;
		
	}
	
	return results;
}

// print out Example objects directly from a DBView
void PrintExamplesFromView()
{
    DBView<Example> view("DB_EXAMPLE");
	copy(view.begin(), view.end(), ostream_iterator<Example>(cout, "\n"));
}

// write some Example objects to the database
void WriteData(const vector<Example> &examples)
{
	// construct view ... note: no BPA as there is no postfix clause
	DBView<Example> view("DB_EXAMPLE",
		BCAExampleObj());

	// loop through vector and write Example objects  to DB
	// write_it.GetLastCount() records written in loop

	DBView<Example>::insert_iterator write_it = view;

	// note initialization of query parameters done in BPA for BoundParams
	// and in operator*() for BoundCols
	for (vector<Example>::const_iterator ex_it = examples.begin(); ex_it != examples.end(); ex_it++, write_it++)
	{
		*write_it = *ex_it;
		
	    // note that write_iterator::GetLastCount() is the # of records actually written 
	    // so far ... which is not registered until after operator++()
	    // hence the need to add 1 to the result of write_it.GetLastCount()
	    cout << "Writing element #" << write_it.GetLastCount() + 1<< endl;
	}


}

// update Example object (with new values)  meeting a query in the database
void UpdateData()
{	
	// construct view
	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE = (?)", BPAExampleObj());
		
	// build an updater for the view
	DBView<Example>::update_iterator 
		exampleUpdater;
	
	exampleUpdater = view;

	// set data fields we want to update to their desired values
	// exampleStr to "Updated" and sampleLong to 0
	Example updateMe;

	updateMe.exampleStr = "Updated";
	updateMe.exampleLong = 25;

	TIMESTAMP_STRUCT today = {2000, 9, 29, 0, 0, 0, 0};

	updateMe = Example(2121, "Dereferenced", 99.99, 25, today);

	*exampleUpdater = updateMe;
    
	// now set the parameters indicating which rows we want the update applied
	exampleUpdater.Params().lowIntValue = 5;
	exampleUpdater.Params().highIntValue = 13;
	exampleUpdater.Params().strValue = "Find Me";

	TIMESTAMP_STRUCT paramDate = {1999, 11, 11, 0, 0, 0, 0};
	exampleUpdater.Params().dateValue = paramDate;

	// execute the update
	exampleUpdater++;

	cout << exampleUpdater.GetLastCount() << " rows updated!" << endl;

	// now can perform other updates using the same updater object
	// make sure to put in your new values for both the data and parameter values
	// for the update
	// set data fields we want to update to their desired values
	// exampleStr to "Second Update" and exampleLong to 66
	TIMESTAMP_STRUCT tomorrow = {2000, 9, 30, 0, 0, 0, 0};
	updateMe = Example(2222, "Second Update", 0.11111, 66, tomorrow);
	updateMe.exampleLong = 66;

	*exampleUpdater = updateMe;

	// now set the parameters indicating which rows we want the update applied
	exampleUpdater.Params().lowIntValue = 21;
	exampleUpdater.Params().highIntValue = 30;
	exampleUpdater.Params().strValue = "To find";

	TIMESTAMP_STRUCT otherParamDate = {2001, 10, 31, 0, 0, 0, 0};
    exampleUpdater.Params().dateValue = otherParamDate;

	// execute the update
	exampleUpdater++;

	cout << exampleUpdater.GetLastCount() << " rows updated!" << endl;
}
 
// delete some Examples from the database
void DeleteData()
{
	// construct view
	DBView<Example>
		view("DB_EXAMPLE", 
		DelBCAExampleObj(), "OR STRING_VALUE = (?) OR INT_VALUE = (?)", DelBPAExampleObj());
		
	// build a deleter for the view
	DBView<Example>::delete_iterator exampleDeleter;
	
	exampleDeleter = view;

	// now set the parameters indicating which rows we want to delete
	TIMESTAMP_STRUCT y2k = {2000, 1, 1, 0, 0, 0, 0};
	
	*exampleDeleter = Example(0, "Example", 0.0, 0, y2k);

	exampleDeleter.Params().strValue = "Find Me";
	exampleDeleter.Params().lowIntValue = 18;
	// execute the delete
	exampleDeleter++;

	cout << exampleDeleter.GetLastCount() << " rows deleted!" << endl;

	// now can perform other deletes using the same deleter object
	// make sure to put in your new values for the parameters
	// for the delete
	
	// now set the parameters indicating which rows we want to delete

	TIMESTAMP_STRUCT today = {1999, 9, 29, 0, 0, 0, 0};
	*exampleDeleter = Example(3, "operator->() works", 0.0, 0, today);

	// execute the delete
	exampleDeleter++;

	cout << exampleDeleter.GetLastCount() << " rows deleted!" << endl;
}

// Dynamic IndexedDBView example
void DynamicIndexedViewExample()
{
	DynamicDBView<> dynamic_view("DB_EXAMPLE", "INT_VALUE, STRING_VALUE, DOUBLE_VALUE, EXAMPLE_LONG, EXAMPLE_DATE");
	
	DynamicIndexedDBView< DynamicDBView<> > indexed_view(dynamic_view, 
		"IndexString; STRING_VALUE;"
		"Unique IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE", BOUND, USE_ALL_FIELDS);

	// Find the item where the STRING_VALUE matches the string "Foozle"
	DynamicIndexedDBView< DynamicDBView<> >::indexed_iterator idxview_it = indexed_view.find(string("Foozle"));;
	

	// Update the item with the key of "Foozle", to read "Fizzle" instead
	if (idxview_it != indexed_view.end()) {
		variant_row replacement;
		replacement = *idxview_it;
		replacement["STRING_VALUE"] = string("Fizzle");
		replacement["DOUBLE_VALUE"] = string("44.5");
		cout << "Replacing: " << endl;
		cout << *idxview_it << endl;
		cout << "with: " << endl;
		cout << replacement << endl;
		indexed_view.replace(idxview_it, replacement);
	}

	// Now find a second set of items using the alternate index, IndexLongDate
	// The STL convention for equal_range is that the return value consists of a pair:  
	// 1. an iterator referring to the beginning of the list of found items
	// and 2. an iterator pointing to the end of the list of found items 
	// We will remove all DataObj's in this range
	const TIMESTAMP_STRUCT date_criteria = {2000, 1, 1, 0, 0, 0, 0};
	long long_criteria = 33;
	DynamicIndexedDBView< DynamicDBView<> >::indexed_pair 
		pr = indexed_view.equal_range_AK("IndexLongDate", long_criteria, date_criteria);

	idxview_it = pr.first;

	cout << "*** Size before erase calls: " << indexed_view.size() << " ***"
		<< endl;
	
	// Remove all DataObj that matched the criteria in our equal_range_AK lookup
	while (idxview_it != pr.second)
	{
		// as iterator is invalidated upon an erase(), use a temporary iterator
		// to point to DataObj to erase
		// increment idxview_it before we erase so it will still be valid
		// when we erase the DataObj
		DynamicIndexedDBView< DynamicDBView<> >::indexed_iterator deleteMe = idxview_it;

		idxview_it++;

		indexed_view.erase(deleteMe);

	}

	cout << "*** Size after erase calls: " << indexed_view.size() << " ***"
		<< endl;

	// Finally, insert a new item into the container
	pair<DynamicIndexedDBView< DynamicDBView<> >::iterator, bool> ins_pr;
	variant_row r(indexed_view.DataObj());
	r["INT_VALUE"] = 459;
	r["STRING_VALUE"] = string("Unique String #1");
	r["DOUBLE_VALUE"] = 3.5;
	r["EXAMPLE_LONG"] = 1;
	r["EXAMPLE_DATE"] = date_criteria;
	ins_pr = indexed_view.insert(r);
	cout << "insertion succeded = " << (ins_pr.second == true ? "true": "false") << endl;

}

// Example of using an IndexDBView to read, insert and update records
void IndexedViewExample()
{
   	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) OR "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

    IndexedDBView<DBView<Example> >
		indexed_view(view,
		"IndexString; STRING_VALUE; Unique IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE",
		BOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));
   	

	// Find the item where the STRING_VALUE matches the string "Foozle"
	IndexedDBView<DBView<Example> >::indexed_iterator idxview_it = indexed_view.find(string("Foozle"));;
	

	// Update the item with the key of "Foozle", to read "Fizzle" instead
	if (idxview_it != indexed_view.end()) {
		Example replacement;
		replacement = *idxview_it;
		replacement.exampleStr = "Fizzle";
		indexed_view.replace(idxview_it, replacement);
	}

	// Now find a second set of items using the alternate index, IndexLongDate
	// The STL convention for equal_range is that the return value consists of a pair:  
	// 1. an iterator referring to the beginning of the list of found items
	// and 2. an iterator pointing to the end of the list of found items 
	// We will remove all DataObj's in this range
	const TIMESTAMP_STRUCT date_criteria = {2000, 1, 1, 0, 0, 0, 0};
	long long_criteria = 33;
	IndexedDBView<DBView<Example> >::indexed_pair 
		pr = indexed_view.equal_range_AK("IndexLongDate", long_criteria, date_criteria);

	idxview_it = pr.first;

	cout << "*** Size before erase calls: " << indexed_view.size() << " ***"
		<< endl;
	
	// Remove all DataObj that matched the criteria in our equal_range_AK lookup
	while (idxview_it != pr.second)
	{
		// as iterator is invalidated upon an erase(), use a temporary iterator
		// to point to DataObj to erase
		// increment idxview_it before we erase so it will still be valid
		// when we erase the DataObj
		IndexedDBView<DBView<Example> >::indexed_iterator deleteMe = idxview_it;

		idxview_it++;

		indexed_view.erase(deleteMe);

	}

	cout << "*** Size after erase calls: " << indexed_view.size() << " ***"
		<< endl;


	// Finally, insert a new item into the container
	pair<IndexedDBView<DBView<Example> >::iterator, bool> ins_pr;
	ins_pr = indexed_view.insert(Example(459, "Unique String #1", 3.4, 1, date_criteria));
	cout << "insertion succeded = " << (ins_pr.second == true ? "true": "false") << endl;
}

// read Examples from indexed view to make sure data gets in IndexedDBView's
// internal list<DataObj> properly
vector<Example> ReadDataFromIndexedView()
{
	//BCAExampleObj
	//DefaultBCA<Example>, BCAExample
	DBView<Example>
		view("DB_EXAMPLE", 
		DefaultBCA<Example>() , "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

	// here, we are not too concerned about the indices themselves
	// we're just testing to see if the DataObj's are stored properly in the
	// indexed view's internal list
    IndexedDBView<DBView<Example> >
		indexed_view(view,
		"IndexString; STRING_VALUE; IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE",
		UNBOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));
   	
	vector<Example> results_from_indexed_view;

	// populate results vector with the data from the indexed view
	for (IndexedDBView<DBView<Example> >::iterator 
			data_it = indexed_view.begin(); data_it != indexed_view.end(); data_it++)
	{
		results_from_indexed_view.push_back(*data_it);
	}

	cout << "*** IndexedDBView says size is: " << indexed_view.size() << " ***" << endl;
	cout << "*** Results say size is: " << results_from_indexed_view.size() << " ***" << endl; 

	// test instantiation of comparison operators
	cout << "indexed_view == indexed_view " << (indexed_view == indexed_view) << endl;
	cout << "indexed_view != indexed_view " << (indexed_view != indexed_view) << endl;
	cout << "indexed_view <  indexed_view " << (indexed_view <  indexed_view) << endl;
	cout << "indexed_view >  indexed_view " << (indexed_view >  indexed_view) << endl;
	cout << "indexed_view <= indexed_view " << (indexed_view <= indexed_view) << endl;
	cout << "indexed_view >= indexed_view " << (indexed_view >= indexed_view) << endl;

	return results_from_indexed_view;
}

// read Examples from indexed view that have the given DataObj as (primary) key
vector<Example> ReadFilteredDataPK(Example &key)
{
   	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG");

	// here, we are not too concerned about the indices themselves
	// we're just testing to see if the DataObj's are stored properly in the
	// indexed view's internal list
    IndexedDBView<DBView<Example> >
		indexed_view(view,
		"IndexString; STRING_VALUE; IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE",
		UNBOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));
   	
	vector<Example> filtered_results;

	// the return value consists of a pair: 1. an iterator referring to the found items
	// and 2. an iterator pointing to the end of the list of found items 
	IndexedDBView<DBView<Example> >::indexed_pair pr =
			indexed_view.equal_range(key);

	IndexedDBView<DBView<Example> >::indexed_iterator idx_data_it =
		pr.first;

	IndexedDBView<DBView<Example> >::indexed_iterator end_it = pr.second;

	IndexedDBView<DBView<Example> >::indexed_iterator find_it = indexed_view.find(key);

	if (idx_data_it == find_it)
		cout << "Iterator integrity satisfied!" << endl;

	// need to be able to iterate through found results
	for ( ; idx_data_it != end_it; idx_data_it++)
	{
		// first * dereferences the iterator, returning a DataObj *
		// second * dereferences the DataObj *, yielding a DataObj
		Example &idx_data = *idx_data_it;
		filtered_results.push_back(idx_data);
	}

	cout << filtered_results.size() << " results found!" << endl;
	return filtered_results;

}

// read Example objects using the index IndexString by name
vector<Example> ReadFilteredDataByName(Example &key)
{
   	DBView<Example> view("DB_EXAMPLE", 
		DefaultBCA<Example>(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

	// here, we are not too concerned about the indices themselves
	// we're just testing to see if the DataObj's are stored properly in the
	// indexed view's internal list

    IndexedDBView<DBView<Example> >
		swap_test(view,
		"IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE; IndexString; STRING_VALUE",
		UNBOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));
	IndexedDBView<DBView<Example> >
		indexed_view;

	indexed_view.swap(swap_test);

   	
	vector<Example> filtered_results;

	// the return value consists of a pair: 1. an iterator referring to the found items
	// and 2. an iterator pointing to the end of the list of found items 
	IndexedDBView<DBView<Example> >::indexed_pair pr =
			indexed_view.equal_range_AK("IndexString", key);

	IndexedDBView<DBView<Example> >::indexed_iterator 
		idx_data_it = pr.first;

	IndexedDBView<DBView<Example> >::indexed_iterator 
		end_it = pr.second;

	IndexedDBView<DBView<Example> >::indexed_iterator 
		find_it = indexed_view.find_AK("IndexString", key);

	if (idx_data_it == find_it)
		cout << "Iterator integrity satisfied!" << endl;

	// need to be able to iterate through found results
	for ( ; idx_data_it != end_it; idx_data_it++)
	{
		// first * dereferences the iterator, returning a DataObj *
		// second * dereferences the DataObj *, yielding a DataObj
		Example &idx_data = *idx_data_it;
		filtered_results.push_back(idx_data);
	}

	cout << "Swap test!" << endl;
	indexed_view.swap(swap_test);

	pr = swap_test.equal_range_AK("IndexString", key);

	idx_data_it = pr.first;
	end_it = pr.second;
	find_it = swap_test.find_AK("IndexString", key);
	
	if (idx_data_it == find_it)
		cout << "Iterator integrity satisfied!" << endl;

	vector<Example> swap_results;

	// need to be able to iterate through found results
	for ( ; idx_data_it != end_it; idx_data_it++)
	{
		// first * dereferences the iterator, returning a DataObj *
		// second * dereferences the DataObj *, yielding a DataObj
		Example &idx_data = *idx_data_it;
		swap_results.push_back(idx_data);
	}

	if (filtered_results == swap_results)
		cout << "Swap test successful!!!!" << endl;

	cout << filtered_results.size() << " results found!" << endl;
	return filtered_results;

}

// read Example objects using the index IndexString by name, but using the
// datafield rather than the object
vector<Example> ReadDataIdxByStrUseDF(const string &strVal)
{
   	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG");

	// here, we are not too concerned about the indices themselves
	// we're just testing to see if the DataObj's are stored properly in the
	// indexed view's internal list
    IndexedDBView<DBView<Example> > 
		indexed_view(view,
		"IndexString; STRING_VALUE; IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE",
		UNBOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));
   	
	vector<Example> filtered_results;

	// the return value consists of a pair: 1. an iterator referring to the found items
	// and 2. an iterator pointing to the end of the list of found items 
	IndexedDBView<DBView<Example> >::indexed_pair 
		pr = indexed_view.equal_range_AK("IndexString", strVal);

	IndexedDBView<DBView<Example> >::indexed_iterator
		idx_data_it = pr.first;

	IndexedDBView<DBView<Example> >::indexed_iterator 
		end_it = pr.second;

	IndexedDBView<DBView<Example> >::indexed_iterator 
		find_it = indexed_view.find_AK("IndexString", strVal);

	if (idx_data_it == find_it)
		cout << "Iterator integrity satisfied!" << endl;

	// need to be able to iterate through found results
	for ( ; idx_data_it != end_it; idx_data_it++)
	{
		// first * dereferences the iterator, returning a DataObj *
		// second * dereferences the DataObj *, yielding a DataObj
		Example &idx_data = *idx_data_it;
		filtered_results.push_back(idx_data);
	}

	cout << filtered_results.size() << " results found!" << endl;
	return filtered_results;
}

// read Example objects using the string as a datafield value for the PK
// using IndexString as PK
vector<Example> ReadDataIdxByStrUseDFAndPK(const string &strVal)
{
   	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

	// here, we are not too concerned about the indices themselves
	// we're just testing to see if the DataObj's are stored properly in the
	// indexed view's internal list
    IndexedDBView<DBView<Example> >
		indexed_view(view,
		"IndexString; STRING_VALUE; IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE",
		UNBOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));
   	
	vector<Example> filtered_results;

	// the return value consists of a pair: 1. an iterator referring to the found items
	// and 2. an iterator pointing to the end of the list of found items 
	IndexedDBView<DBView<Example> >::indexed_pair 
		pr = indexed_view.equal_range(strVal);

	IndexedDBView<DBView<Example> >::indexed_iterator
		idx_data_it = pr.first;

	IndexedDBView<DBView<Example> >::indexed_iterator 
		end_it = pr.second;

	IndexedDBView<DBView<Example> >::indexed_iterator 
		find_it = indexed_view.find(strVal);

	if (idx_data_it == find_it)
		cout << "Iterator integrity satisfied!" << endl;

	// need to be able to iterate through found results
	for ( ; idx_data_it != end_it; idx_data_it++)
	{
		// first * dereferences the iterator, returning a DataObj *
		// second * dereferences the DataObj *, yielding a DataObj
		Example &idx_data = *idx_data_it;
		filtered_results.push_back(idx_data);
	}

	cout << filtered_results.size() << " results found!" << endl;
	return filtered_results;

}

// read Example objects using the string and date values as fields in a key
vector<Example> ReadTwoFieldKeyByNameDF(const string &strVal, const TIMESTAMP_STRUCT &dateVal)
{
   	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

	// here, we are not too concerned about the indices themselves
	// we're just testing to see if the DataObj's are stored properly in the
	// indexed view's internal list
    IndexedDBView<DBView<Example> > 
		indexed_view(view,
		"IndexString; STRING_VALUE; IndexTwoFields; STRING_VALUE, EXAMPLE_DATE",
		UNBOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));
   	
	vector<Example> filtered_results;

	// the return value consists of a pair: 1. an iterator referring to the found items
	// and 2. an iterator pointing to the end of the list of found items 
	IndexedDBView<DBView<Example> >::indexed_pair 
		pr = indexed_view.equal_range_AK("IndexTwoFields", strVal, dateVal);

	IndexedDBView<DBView<Example> >::indexed_iterator 
		idx_data_it = pr.first;

	IndexedDBView<DBView<Example> >::indexed_iterator
		end_it = pr.second;

	IndexedDBView<DBView<Example> >::indexed_iterator
		find_it = indexed_view.find_AK("IndexTwoFields", strVal, dateVal);

	if (idx_data_it == find_it)
		cout << "Iterator integrity satisfied!" << endl;

	// need to be able to iterate through found results
	for ( ; idx_data_it != end_it; idx_data_it++)
	{
		// first * dereferences the iterator, returning a DataObj *
		// second * dereferences the DataObj *, yielding a DataObj
		Example &idx_data = *idx_data_it;
		filtered_results.push_back(idx_data);
	}

	cout << filtered_results.size() << " results found!" << endl;
	return filtered_results;
}

// read Example objects using the passed in
// uses a two field key
vector<Example> ReadTwoFieldKeyByName(Example &key)
{
   	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

	// set up indexed view with two field index
    IndexedDBView<DBView<Example> > 
		indexed_view(view,
		"IndexTwoFields; STRING_VALUE, EXAMPLE_DATE; IndexLong; EXAMPLE_LONG",
		UNBOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));
   	
	vector<Example> filtered_results;

	// the return value consists of a pair: 1. an iterator referring to the found items
	// and 2. an iterator pointing to the end of the list of found items 
	IndexedDBView<DBView<Example> >::indexed_pair
		pr = indexed_view.equal_range_AK("IndexTwoFields", key);

	IndexedDBView<DBView<Example> >::indexed_iterator
		idx_data_it = pr.first;

	IndexedDBView<DBView<Example> >::indexed_iterator
		end_it = pr.second;

	IndexedDBView<DBView<Example> >::indexed_iterator
		find_it = indexed_view.find_AK("IndexTwoFields", key);

	if (idx_data_it == find_it)
		cout << "Iterator integrity satisfied!" << endl;

	// need to be able to iterate through found results
	for ( ; idx_data_it != end_it; idx_data_it++)
	{
		// first * dereferences the iterator, returning a DataObj *
		// second * dereferences the DataObj *, yielding a DataObj
		Example &idx_data = *idx_data_it;
		filtered_results.push_back(idx_data);
	}

	cout << filtered_results.size() << " results found!" << endl;
	return filtered_results;
}

// read Example objects using the PK
// uses a two field key
vector<Example> ReadTwoFieldKeyPK(Example &key)
{
   	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

	// set up indexed view with two field index
    IndexedDBView<DBView<Example> >
		indexed_view(view,
		"IndexTwoFields; STRING_VALUE, EXAMPLE_DATE; IndexLong; EXAMPLE_LONG",
		UNBOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));
   	
	vector<Example> filtered_results;

	// the return value consists of a pair: 1. an iterator referring to the found items
	// and 2. an iterator pointing to the end of the list of found items 
	IndexedDBView<DBView<Example> >::indexed_pair
		pr = indexed_view.equal_range(key);

	IndexedDBView<DBView<Example> >::indexed_iterator
		idx_data_it = pr.first;

	IndexedDBView<DBView<Example> >::indexed_iterator
		end_it = pr.second;

	IndexedDBView<DBView<Example> >::indexed_iterator
		find_it = indexed_view.find(key);

	if (idx_data_it == find_it)
		cout << "Iterator integrity satisfied!" << endl;

	// need to be able to iterate through found results
	for ( ; idx_data_it != end_it; idx_data_it++)
	{
		// first * dereferences the iterator, returning a DataObj *
		// second * dereferences the DataObj *, yielding a DataObj
		Example &idx_data = *idx_data_it;
		filtered_results.push_back(idx_data);
	}

	cout << filtered_results.size() << " results found!" << endl;
	return filtered_results;
}

// same as above, but as PK
vector<Example> ReadTwoFieldKeyDFAndPK(const string &strVal, const TIMESTAMP_STRUCT &dateVal)
{
   	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

	// here, we are not too concerned about the indices themselves
	// we're just testing to see if the DataObj's are stored properly in the
	// indexed view's internal list
    IndexedDBView<DBView<Example> >
		indexed_view(view,
		"IndexTwoFields; STRING_VALUE, EXAMPLE_DATE; IndexLong; EXAMPLE_LONG",
		UNBOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));
   	
	vector<Example> filtered_results;

	// the return value consists of a pair: 1. an iterator referring to the found items
	// and 2. an iterator pointing to the end of the list of found items 
	IndexedDBView<DBView<Example> >::indexed_pair
		pr = indexed_view.equal_range(strVal, dateVal);

	IndexedDBView<DBView<Example> >::indexed_iterator
		idx_data_it = pr.first;

	IndexedDBView<DBView<Example> >::indexed_iterator 
		end_it = pr.second;

	IndexedDBView<DBView<Example> >::indexed_iterator
		find_it = indexed_view.find(strVal, dateVal);

	if (idx_data_it == find_it)
		cout << "Iterator integrity satisfied!" << endl;

	// need to be able to iterate through found results
	for ( ; idx_data_it != end_it; idx_data_it++)
	{
		// first * dereferences the iterator, returning a DataObj *
		// second * dereferences the DataObj *, yielding a DataObj
		Example &idx_data = *idx_data_it;
		filtered_results.push_back(idx_data);
	}

	cout << filtered_results.size() << " results found!" << endl;
	return filtered_results;
}

// test the insertion of Example objects into IndexedDBView using *unbound* mode
void TestUnboundInsert()
{
   	DBView<Example> view("DB_EXAMPLE", 
		DefaultBCA<Example>(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

	// here, we are not too concerned about the indices themselves
	// we're just testing to see if the DataObj's are stored properly in the
	// indexed view's internal list

    IndexedDBView<DBView<Example> >
		indexed_view(view,
		"Unique IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE; IndexString; STRING_VALUE;",
		UNBOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));

	
	// insert some Example objects into the indexed view
	cout << "*** Size before inserts: " << indexed_view.size() << " ***" << endl;

	const TIMESTAMP_STRUCT date1 = {1993, 2, 28, 0, 0, 0, 0};
	const TIMESTAMP_STRUCT date2 = {1995, 7, 31, 0, 0, 0, 0};
	const TIMESTAMP_STRUCT date3 = {1998, 11, 30, 0, 0, 0, 0};

	pair<IndexedDBView<DBView<Example> >::iterator, bool> ins_pr;
	
	ins_pr = indexed_view.insert(Example(459, "Unique String #1", 3.4, 1, date1));
	cout << "insertion result = " << ins_pr.second << endl;

	ins_pr = indexed_view.insert(Example(444, "Unique String #2", 23.45, 11, date2));
	cout << "insertion result = " << ins_pr.second << endl;
	
	ins_pr = indexed_view.insert(Example(411, "Unique String #3", 98.76, 11, date2));
	cout << "insertion result = " << ins_pr.second << endl;
	
	ins_pr = indexed_view.insert(Example(1323, "Example", 2.22, 11, date1));
	cout << "insertion result = " << ins_pr.second << endl;

	cout << "*** Size after inserts: " << indexed_view.size() << " ***" << endl;

	// clear and refetch to prove we're in unbound mode
	indexed_view.clear();

	cout << "*** Size after refetching: " << indexed_view.size() << " ***" << endl;
}


void TestUnboundErase()
{
   	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

    IndexedDBView<DBView<Example> >
		indexed_view(view,
		"IndexString; STRING_VALUE; IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE",
		UNBOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));
   	
	cout << "*** Size before erase calls: " << indexed_view.size() << " ***"
		<< endl;

	// the return value consists of a pair: 1. an iterator referring to the found items
	// and 2. an iterator pointing to the end of the list of found items 
	// we'll remove the DataObj's in this range
	IndexedDBView<DBView<Example> >::indexed_pair 
		pr = indexed_view.equal_range(string("Example"));

	IndexedDBView<DBView<Example> >::indexed_iterator idxview_it = pr.first;
	
	// remove the DataObj's in the range
	while (idxview_it != pr.second)
	{
		// as iterator is invalidated upon an erase(), use a temporary iterator
		// to point to DataObj to erase
		// increment idxview_it before we erase so it will still be valid

		// when we erase the DataObj
		IndexedDBView<DBView<Example> >::indexed_iterator deleteMe = idxview_it;

		idxview_it++;

		indexed_view.erase(deleteMe);

	}

	cout << "*** Size after erase calls: " << indexed_view.size() << " ***"
		<< endl;

	// clear and refetch to prove we're in unbound mode
	indexed_view.clear();

	cout << "*** Size after refetching: " << indexed_view.size() << " ***" << endl;
}

// test the insertion of Example objects into IndexedDBView using *bound* mode
void TestBoundInsert()
{
   	DBView<Example> view("DB_EXAMPLE", 
		DefaultBCA<Example>(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

	// here, we are not too concerned about the indices themselves
	// we're just testing to see if the DataObj's are stored properly in the
	// indexed view's internal list

    IndexedDBView<DBView<Example> >
		indexed_view(view,
		"Unique IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE; IndexString; STRING_VALUE;",
		BOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));

	
	// insert some Example objects into the indexed view
	cout << "*** Size before inserts: " << indexed_view.size() << " ***" << endl;

	const TIMESTAMP_STRUCT date1 = {1993, 2, 28, 0, 0, 0, 0};
	const TIMESTAMP_STRUCT date2 = {1995, 7, 31, 0, 0, 0, 0};
	const TIMESTAMP_STRUCT date3 = {1998, 11, 30, 0, 0, 0, 0};

	pair<IndexedDBView<DBView<Example> >::iterator, bool> ins_pr;
	
	ins_pr = indexed_view.insert(Example(459, "Unique String #1", 3.4, 1, date1));
	cout << "insertion result = " << ins_pr.second << endl;

	ins_pr = indexed_view.insert(Example(444, "Unique String #2", 23.45, 4554, date2));
	cout << "insertion result = " << ins_pr.second << endl;
	
	ins_pr = indexed_view.insert(Example(411, "Unique String #3", 98.76, 888, date2));
	cout << "insertion result = " << ins_pr.second << endl;
	
	ins_pr = indexed_view.insert(Example(1323, "Example", 2.22, 1116, date1));
	cout << "insertion result = " << ins_pr.second << endl;

	cout << "*** Size after inserts: " << indexed_view.size() << " ***" << endl;

	// clear and refetch to prove we're in bound mode
	indexed_view.clear();

	cout << "*** Size after refetching: " << indexed_view.size() << " ***" << endl;
}

// test the erasing of Example objects from the IndexedDBView using *bound* mode
// using all fields
void TestBoundEraseUAF()
{
   	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

    IndexedDBView<DBView<Example> >
		indexed_view(view,
		"IndexString; STRING_VALUE; IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE",
		BOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));
   	
	cout << "*** Size before erase calls: " << indexed_view.size() << " ***"
		<< endl;

	// the return value consists of a pair: 1. an iterator referring to the found items
	// and 2. an iterator pointing to the end of the list of found items 
	// we'll remove the DataObj's in this range
	IndexedDBView<DBView<Example> >::indexed_pair 
		pr = indexed_view.equal_range(string("Example"));

	IndexedDBView<DBView<Example> >::indexed_iterator idxview_it = pr.first;
	
	// remove the DataObj's in the range
	while (idxview_it != pr.second)
	{
		// as iterator is invalidated upon an erase(), use a temporary iterator
		// to point to DataObj to erase
		// increment idxview_it before we erase so it will still be valid
		// when we erase the DataObj
		IndexedDBView<DBView<Example> >::indexed_iterator deleteMe = idxview_it;

		idxview_it++;

		indexed_view.erase(deleteMe);

	}

	cout << "*** Size after erase calls: " << indexed_view.size() << " ***"
		<< endl;

	// clear and refetch to prove we're in bound mode
	indexed_view.clear();

	cout << "*** Size after refetching: " << indexed_view.size() << " ***" << endl;
}

// test the erasing of Example objects from the IndexedDBView using *bound* mode
// using only the PK fields
void TestBoundErasePK()
{
   	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

    IndexedDBView<DBView<Example> >
		indexed_view(view,
		"IndexString; STRING_VALUE; IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE",
		BOUND, USE_PK_FIELDS_ONLY, cb_ptr_fun(SetParamsExample));
   	
	cout << "*** Size before erase calls: " << indexed_view.size() << " ***"
		<< endl;

	// the return value consists of a pair: 1. an iterator referring to the found items
	// and 2. an iterator pointing to the end of the list of found items 
	// we'll remove the DataObj's in this range
	IndexedDBView<DBView<Example> >::indexed_pair 
		pr = indexed_view.equal_range(string("Example"));

	IndexedDBView<DBView<Example> >::indexed_iterator idxview_it = pr.first;
	
	// remove the DataObj's in the range
	while (idxview_it != pr.second)
	{
		// as iterator is invalidated upon an erase(), use a temporary iterator
		// to point to DataObj to erase
		// increment idxview_it before we erase so it will still be valid
		// when we erase the DataObj
		IndexedDBView<DBView<Example> >::indexed_iterator deleteMe = idxview_it;

		idxview_it++;

		indexed_view.erase(deleteMe);

	}

	cout << "*** Size after erase calls: " << indexed_view.size() << " ***"
		<< endl;

	// clear and refetch to prove we're in bound mode
	indexed_view.clear();

	cout << "*** Size after refetching: " << indexed_view.size() << " ***" << endl;
}

void TestBoundUpdate()
{
   	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) OR "
		"STRING_VALUE = (?) OR EXAMPLE_DATE <= (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

    IndexedDBView<DBView<Example> >
		indexed_view(view,
		"IndexString; STRING_VALUE; Unique IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE",
		BOUND, USE_ALL_FIELDS, cb_ptr_fun(SetParamsExample));
   	
	for (IndexedDBView<DBView<Example> >::iterator
		    print_it = indexed_view.begin(); print_it != indexed_view.end(); print_it++)
	{
			cout << print_it->exampleStr << ", ";
	}
	cout << endl;

	// the return value consists of a pair: 1. an iterator referring to the found items
	// and 2. an iterator pointing to the end of the list of found items 
	// we'll remove the DataObj's in this range
	IndexedDBView<DBView<Example> >::indexed_pair 
		pr = indexed_view.equal_range(string("Foozle"));

	IndexedDBView<DBView<Example> >::indexed_iterator idxview_it = pr.first;
	
	// as iterator is invalidated upon an erase(), use a temporary iterator
	// to point to DataObj to erase
	// increment idxview_it before we erase so it will still be valid
	// when we replace the DataObj
	IndexedDBView<DBView<Example> >::indexed_iterator replaceMe = idxview_it;

	Example replacement;

	replacement = *idxview_it;
	replacement.exampleStr = "Duped";
	indexed_view.replace(idxview_it, replacement);
	replacement.exampleStr = "Fizzle";
	replacement.exampleLong = 48;
	indexed_view.replace(idxview_it, replacement);
}

#if 1
void TestDynamicView()
{
  	DynamicDBView<> dynamic_view("DB_EXAMPLE", "*");
	
	DynamicIndexedDBView< DynamicDBView<> > indexed_view(dynamic_view, 
		"IndexString; STRING_VALUE;", UNBOUND, USE_ALL_FIELDS);
	
  DynamicIndexedDBView< DynamicDBView<> >::iterator
		    print_it = indexed_view.begin();

	for (print_it = indexed_view.begin(); print_it != indexed_view.end(); print_it++)
	{
		variant_row r = *print_it;
		variant_field vf = r["STRING_VALUE"];

    #ifdef __GNUC__     // gcc bug
		string str = vf.get_string();
		#else
		string str = (string) vf;
		#endif

		variant_t v = (variant_t) vf;

    #ifdef __GNUC__     // gcc bug
		string s = v.get_string();
		#else
		string s = (string)(v);
    #endif

		cout << r["INT_VALUE"] << ", ";
		cout << r["STRING_VALUE"] << ", ";
    cout << r["DOUBLE_VALUE"] << ", ";
    cout << r["EXAMPLE_LONG"] << ", ";
		cout << r["EXAMPLE_DATE"];

		cout << endl;
	}
	cout << endl;

	print_it = indexed_view.begin();

	vector<string> colNames = (*print_it).GetNames();


	for (vector<string>::iterator name_it = colNames.begin(); name_it != colNames.end(); name_it++)
	{
		cout << (*name_it) << " ";
	}
	cout << endl;

	for (print_it = indexed_view.begin(); print_it != indexed_view.end(); print_it++)
	{
		variant_row r = *print_it;
		for (size_t i = 0; i < r.size(); i++)
		{
			cout << r[i] << " ";
		}
		cout << endl;
	}
}
#endif 

#if 1
void test_variant(void) {

	TIMESTAMP_STRUCT date2, test_date = {1999, 9, 29, 0, 0, 0, 0};

	vector<TypeTranslation> types;
	vector<string> names;
	int i;
	string s;
	variant_t v;
	//char test[] = "hello";
	//variant_t c(test);
	char *test2 = (char *) malloc(10);
	sprintf(test2, "bye");
	variant_t e(test2);
	variant_t f(test_date);
	variant_t a(1L), b(2), d(4.5);
	TypeTranslation vt0=TypeTranslation(typeid(int).name(), C_INT, SQL_INTEGER, SQL_C_SLONG, TypeTranslation::TYPE_PRIMITIVE, sizeof(int)), 
		vt1=TypeTranslation(typeid(string).name(), C_STRING, SQL_VARCHAR, SQL_C_CHAR, TypeTranslation::TYPE_COMPLEX, sizeof(string));

	types.push_back(vt0);
	names.push_back("int");

	types.push_back(vt1);
	names.push_back("string");

	variant_row r, r_original(types, names);
	variant_field vf;
	
//	s = (string)c;
	test2[0] = 'r';

  #ifdef __GNUC__     // gcc bug
	s = e.get_string();
	#else
  s = (string) e;
  #endif
	
	date2 = (TIMESTAMP_STRUCT)f;
	i = (int)d;

	r = r_original;


	vf = r["int"];
	
	i = (int)vf;
	i+= 5;
	vf = i;
	
	r["int"] = (int)r["int"] + 5;
	vf = r["int"];
	i = (int)vf;
	
  #ifdef __GNUC__     // gcc bug
	string str = vf.get_string();
	#else
	s = (string) r["int"];
  #endif
	// r["int"] = date2;
	// s = (string) r["int"];


};

void TestCountedPtr()
{
   CountedPtr<DerivedExample> der = new DerivedExample;

   CountedPtr<Example> base = der;
}

void TestIOStates()
{
	cout << "goodbit == goodbit? " 
		<< (dtl_ios_base::goodbit == dtl_ios_base::goodbit) << endl;
}

#if 0
// used in for_each() example code
void print_example(Example example)
{
	cout << example << endl;
}
#endif

// example showing use of for_each() on a DBView
void for_each_example()
{
   PrintHeader(cout, "for_each_example()");

   cout << "Printing examples using for_each()" << endl;
   
   DBView<Example> view("DB_EXAMPLE");

   for_each(view.begin(), view.end(), print_example());

   PrintSeparator(cout);
}

// test out cb_ptr_fun() some more
void TestCBPtrFun()
{
   PrintHeader(cout, "TestCBPtrFun()");

   // first test out DTL specific things a little
   cout << "First here are some DTL specific tests" << endl;
   cout << "----" << endl;

   DBView<Example> view("DB_EXAMPLE", cb_ptr_fun(BCAExample), "",
	   DefaultBPA<DefaultParamObj<Example> >(), cb_ptr_fun_w_ret(SelValExample),
	   cb_ptr_fun_w_ret(InsValExample));

   view.set_io_handler(cb_ptr_fun_w_ret(AlwaysThrowsExample));

   cout << "Printing examples ..." << endl;

   copy(view.begin(), view.end(), ostream_iterator<Example>(cout, "\n"));

   // now for some STL algorithms with the use of cb_ptr_fun()

   cout << "Now for some STL algorithms with use of cb_ptr_fun()" << endl;

   cout << "First a simple for_each() ..." << endl;

   for_each(view.begin(), view.end(), cb_ptr_fun(print_example_fn));   

   cout << "Now let's try something using a binder ..." << endl;

   cout << "Printing examples with a string tacked on ..." << endl;

   vector<Example> examples;

   transform(view.begin(), view.end(), back_inserter(examples),
	   bind2nd(cb_ptr_fun_w_ret(AddToExampleString), " Tack me on!")); 

   copy(examples.begin(), examples.end(), ostream_iterator<Example>(cout, "\n"));

   PrintSeparator(cout);

}

void TestIndexedInsertViaAlgorithm()
{
   PrintHeader(cout, "TestIndexedInsertViaAlgorithm()");

   vector<Example> read_DB_before, read_DB_after;

   DBView<Example> view("DB_EXAMPLE");

   IndexedDBView<DBView<Example> > indexed_view(view,
	   "IndexLongDate; EXAMPLE_LONG, EXAMPLE_DATE; IndexString; STRING_VALUE;",
		BOUND);

   copy(view.begin(), view.end(), back_inserter(read_DB_before)); 

   cout << "Examples before insert:" << endl;
   copy(read_DB_before.begin(), read_DB_before.end(),
	   ostream_iterator<Example>(cout, "\n"));

   // now make our examples
   vector<Example> examples_to_insert;

   const TIMESTAMP_STRUCT now = {2001, 3, 12, 0, 0, 0, 0};

   examples_to_insert.push_back(Example(2468, "Who do we appreciate?", 13.5, 1357, now));
   examples_to_insert.push_back(Example(7218, "No one in particular", 72.18, 2192, now));
   examples_to_insert.push_back(Example(0, "Void", 0, 0, now));

   copy(examples_to_insert.begin(), examples_to_insert.end(), 
	   inserter(indexed_view, indexed_view.begin()));

   // real test here will be to grab the Examples from the underlying view
   // TableDiff() should give us the newly inserted objects
   copy(view.begin(), view.end(), back_inserter(read_DB_after));

   cout << "Examples after insert:" << endl;
   copy(read_DB_after.begin(), read_DB_after.end(),
	   ostream_iterator<Example>(cout, "\n"));

   TableDiff(cout, read_DB_before, read_DB_after);

   PrintSeparator(cout);
}

#endif

