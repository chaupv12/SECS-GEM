// code in which we intentionally cause DTL to trip and throw exceptions
// in order to make sure they work
// Initial: 12/27/2000 - MG

#include "TestExceptions.h"

// master function to test different exception cases
void TestExceptions()
{
   // test cases
   TestBadBCASelect();
   TestBadBPASelect();
   TestBadSelValidate();
   TestBadBCAInsert();
   TestBadInsValidate();
   TestBadBCAUpdate();
   TestBadUpdateValidate();
   TestBadBCADelete();
   TestBadBPADelete();
}

// test out a bad BCA on a select
void TestBadBCASelect()
{
    PrintHeader(cout, "TestBadBCASelect()");

	vector<Example> results;

	// construct view
	// DBView<Example> is actually DBView<Example, 
    // DefaultParamObj<Example> > thanks to the default argument to the DBView
	// template

	// use our bad BCA which references a nonexistent column name in DB_EXAMPLE
	DBView<Example>
		view("DB_EXAMPLE", BadBCAExampleObj(),
		"WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE < (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj());

	// loop through query results and add them to our vector
	// in this loop, read_it.GetLastCount() records read from DB

	DBView<Example>::select_iterator read_it = view.begin();

	// set parameter values for the WHERE clause in our SQL query
	read_it.Params().lowIntValue = 2;
	read_it.Params().highIntValue = 8;
	read_it.Params().strValue = "Example";
	
	TIMESTAMP_STRUCT paramDate = {2000, 1, 1, 0, 0, 0, 0};
	read_it.Params().dateValue = paramDate;

	for ( ; read_it != view.end();  )
	{
        try
		{
		  // note that the read_iterator::GetLastCount()  is incremented in operator++()
		  // remember that the record is fetched and thus the count incremented
		  // before operator*() is applied to the read_iterator

		  cout << "Reading element #" << read_it.GetLastCount() << endl;
		  cout << "read_it->exampleInt = " << read_it->exampleInt << endl;
		  cout << "read_it->exampleStr = " << read_it->exampleStr << endl;
		  results.push_back(*read_it);

		  read_it++;
		}
		catch (RootException &ex)
		{
          cout << "Caught Exception!!!!" << endl;
		  cout << ex.what() << endl;
		}
	}

	LoggingHandler<Example> handler = 
		read_it.get_io_handler((LoggingHandler<Example> *) NULL);

	typedef LoggingHandler<Example>::LoggedTriple LoggedTriple;

	vector<LoggedTriple> errors = handler.GetLog();

	for (vector<LoggedTriple>::iterator log_it = errors.begin(); log_it != errors.end();
			log_it++)
	{
		LoggedTriple error = *log_it;

		cout << "Error msg = " << error.errmsg << endl;
		cout << "Example = " << error.dataObj << endl;
	}

	PrintSeparator(cout);
}

// test out a bad BPA on a select
void TestBadBPASelect()
{
    PrintHeader(cout, "TestBadBPASelect()");

	vector<Example> results;

	// construct view
	// DBView<Example> is actually DBView<Example, 
    // DefaultParamObj<Example> > thanks to the default argument to the DBView
	// template

	// use our bad BCA which references a nonexistent column name in DB_EXAMPLE
	DBView<Example>
		view("DB_EXAMPLE", BCAExampleObj(),
		"WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE < (?) ORDER BY EXAMPLE_LONG",
		BadBPAExampleObj());

	// loop through query results and add them to our vector
	// in this loop, read_it.GetLastCount() records read from DB

	DBView<Example>::select_iterator read_it = view.begin();

	// set parameter values for the WHERE clause in our SQL query
	read_it.Params().lowIntValue = 2;
	read_it.Params().highIntValue = 8;
	read_it.Params().strValue = "Example";
	
	TIMESTAMP_STRUCT paramDate = {2000, 1, 1, 0, 0, 0, 0};
	read_it.Params().dateValue = paramDate;

	for ( ; read_it != view.end();  )
	{
        try
		{
		  // note that the read_iterator::GetLastCount()  is incremented in operator++()
		  // remember that the record is fetched and thus the count incremented
		  // before operator*() is applied to the read_iterator

		  cout << "Reading element #" << read_it.GetLastCount() << endl;

		  // results.push_back(*read_it);
		  cout << "read_it->exampleInt = " << read_it->exampleInt << endl;
		  cout << "read_it->exampleStr = " << read_it->exampleStr << endl;
		  results.push_back(*read_it);

		  read_it++;
		}
		catch (RootException &ex)
		{
          cout << "Caught Exception!!!!" << endl;
		  cout << ex.what() << endl;
		}
	}

	LoggingHandler<Example> handler = 
		read_it.get_io_handler((LoggingHandler<Example> *) NULL);

	typedef LoggingHandler<Example>::LoggedTriple LoggedTriple;

	vector<LoggedTriple> errors = handler.GetLog();

	for (vector<LoggedTriple>::iterator log_it = errors.begin(); log_it != errors.end();
			log_it++)
	{
		LoggedTriple error = *log_it;

		cout << "Error msg = " << error.errmsg << endl;
		cout << "Example = " << error.dataObj << endl;
	}

	PrintSeparator(cout);
}

// test of failed SelValidate() when reading data
void TestBadSelValidate()
{
    PrintHeader(cout, "TestBadSelValidate()");

	vector<Example> results;


	// construct view
	// DBView<Example> is actually DBView<Example, 
    // DefaultParamObj<Example> > thanks to the default argument to the DBView
	// template

	// use our bad BCA which references a nonexistent column name in DB_EXAMPLE
	DBView<Example>
		view("DB_EXAMPLE", BCAExampleObj(),
		"WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE < (?) ORDER BY EXAMPLE_LONG",
		BPAExampleObj(), BadSelValidate());

	// loop through query results and add them to our vector
	// in this loop, read_it.GetLastCount() records read from DB

	DBView<Example>::select_iterator read_it = view.begin();

	// set parameter values for the WHERE clause in our SQL query
	read_it.Params().lowIntValue = 2;
	read_it.Params().highIntValue = 8;
	read_it.Params().strValue = "Example";
	
	TIMESTAMP_STRUCT paramDate = {2000, 1, 1, 0, 0, 0, 0};
	read_it.Params().dateValue = paramDate;

	for ( ; read_it != view.end(); read_it++)
	{
        try
		{
		  // note that the read_iterator::GetLastCount()  is incremented in operator++()
		  // remember that the record is fetched and thus the count incremented
		  // before operator*() is applied to the read_iterator

		  cout << "Reading element #" << read_it.GetLastCount() << endl;
		  
		  cout << "read_it->exampleInt = " << read_it->exampleInt << endl;
		  cout << "read_it->exampleStr = " << read_it->exampleStr << endl;
		  
		  results.push_back(*read_it);
		}
		catch (RootException &ex)
		{
          cout << "Caught Exception!!!!" << endl;
		  cout << ex.what() << endl;
		}
	}

	LoggingHandler<Example> handler = 
		read_it.get_io_handler((LoggingHandler<Example> *) NULL);

	typedef LoggingHandler<Example>::LoggedTriple LoggedTriple;

	vector<LoggedTriple> errors = handler.GetLog();

	for (vector<LoggedTriple>::iterator log_it = errors.begin(); log_it != errors.end();
			log_it++)
	{
		LoggedTriple error = *log_it;

		cout << "Error msg = " << error.errmsg << endl;
		cout << "Example = " << error.dataObj << endl;
	}

	PrintSeparator(cout);
}

void TestBadBCAInsert()
{
	PrintHeader(cout, "TestBadBCAInsert()");

	const TIMESTAMP_STRUCT indep = {1999, 7, 4, 0, 0, 0, 0};
    const TIMESTAMP_STRUCT y2k = {2000, 1, 1, 0, 0, 0, 0};
	const TIMESTAMP_STRUCT xmas = {2000, 12, 25, 0, 0, 0, 0};

	vector<Example> examples;

	examples.push_back(Example(7, "Seven", 7.777, 77, indep));
	examples.push_back(Example(6, "Six", 6.666, 66, y2k));
	examples.push_back(Example(5, "Five", 5.555, 55, xmas));

	// construct view ... note: no BPA as there is no postfix clause
	DBView<Example>
			view("DB_EXAMPLE", BadBCAExampleObj());

	// loop through vector and write Example objects  to DB
	// write_it.GetLastCount() records written in loop

	DBView<Example>::insert_iterator write_it = view;

	// note initialization of query parameters done in BPA for BoundParams
	// and in operator*() for BoundCols
	for (vector<Example>::const_iterator ex_it = examples.begin(); ex_it != examples.end(); ex_it++)
	{
		try
		{
		  *write_it = *ex_it;
		
	      // note that write_iterator::GetLastCount() is the # of records actually written 
	      // so far ... which is not registered until after operator++()
	      // hence the need to add 1 to the result of write_it.GetLastCount()
	      cout << "Writing element #" << write_it.GetLastCount() + 1 << endl;

		  write_it++;
		}
		catch (RootException &ex)
		{
		  cout << "Exception caught!" << endl;
		  cout << ex.what() << endl;
		}
	}

	LoggingHandler<Example> handler = 
		write_it.get_io_handler((LoggingHandler<Example> *) NULL);

	typedef LoggingHandler<Example>::LoggedTriple LoggedTriple;

	vector<LoggedTriple> errors = handler.GetLog();

	for (vector<LoggedTriple>::iterator log_it = errors.begin(); log_it != errors.end();
			log_it++)
	{
		LoggedTriple error = *log_it;

		cout << "Error msg = " << error.errmsg << endl;
		cout << "Example = " << error.dataObj << endl;
	}

	PrintSeparator(cout);
}

void TestBadInsValidate()
{
	PrintHeader(cout, "TestBadInsValidate()");

	const TIMESTAMP_STRUCT indep = {1999, 7, 4, 0, 0, 0, 0};
    const TIMESTAMP_STRUCT y2k = {2000, 1, 1, 0, 0, 0, 0};
	const TIMESTAMP_STRUCT xmas = {2000, 12, 25, 0, 0, 0, 0};

	vector<Example> examples;

	examples.push_back(Example(7, "Seven", 7.777, 77, indep));
	examples.push_back(Example(6, "Six", 6.666, 66, y2k));
	examples.push_back(Example(5, "Five", 5.555, 55, xmas));

	// construct view ... note: no BPA as there is no postfix clause
	DBView<Example> view("DB_EXAMPLE", DefaultBCA<Example>(), 
		    "", DefaultBPA<DefaultParamObj<Example> >(), 
			DefaultSelValidate<Example>(), BadInsValidate());

	// loop through vector and write Example objects  to DB
	// write_it.GetLastCount() records written in loop

	DBView<Example>::insert_iterator write_it = view;

	// note initialization of query parameters done in BPA for BoundParams
	// and in operator*() for BoundCols
	for (vector<Example>::const_iterator ex_it = examples.begin(); ex_it != examples.end(); ex_it++, write_it++)
	{
		try
		{
		  *write_it = *ex_it;
		  
	      // note that write_iterator::GetLastCount() is the # of records actually written 
	      // so far ... which is not registered until after operator++()
	      // hence the need to add 1 to the result of write_it.GetLastCount()
	      
		  cout << "Writing element #" << write_it.GetLastCount() + 1 << endl;
		}
		catch (RootException &ex)
		{
		  cout << "Exception caught!" << endl;
		  cout << ex.what() << endl;
		}
	}

	LoggingHandler<Example> handler = 
		write_it.get_io_handler((LoggingHandler<Example> *) NULL);

	typedef LoggingHandler<Example>::LoggedTriple LoggedTriple;

	vector<LoggedTriple> errors = handler.GetLog();

	for (vector<LoggedTriple>::iterator log_it = errors.begin(); log_it != errors.end();
			log_it++)
	{
		LoggedTriple error = *log_it;

		cout << "Error msg = " << error.errmsg << endl;
		cout << "Example = " << error.dataObj << endl;
	}

	PrintSeparator(cout);
}

void TestBadBCAUpdate()
{
	// construct view
	DBView<Example> view("DB_EXAMPLE", 
		BadBCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE = (?)", BPAExampleObj());
		
	// build an updater for the view
	DBView<Example>::update_iterator 
		exampleUpdater;
	
	exampleUpdater = view;

	// set data fields we want to update to their desired values
	// exampleStr to "Updated" and sampleLong to 0
	Example updateMe;

	try
	{
		updateMe.exampleStr = "Updated";
	    updateMe.exampleLong = 25;

	    TIMESTAMP_STRUCT today = {2000, 9, 29, 0, 0, 0, 0};

	    updateMe = Example(2121, "Dereferenced", 99.99, 25, today);

		*exampleUpdater = updateMe;
    
		// now set the parameters indicating which rows we want the update applied
		exampleUpdater.Params().lowIntValue = 5;
		exampleUpdater.Params().highIntValue = 13;
		exampleUpdater.Params().strValue = "Find Me";

		TIMESTAMP_STRUCT paramDate = {1999, 11, 11, 0, 0, 0, 0};
		exampleUpdater.Params().dateValue = paramDate;

		// execute the update
		exampleUpdater++;

		cout << exampleUpdater.GetLastCount() << " rows updated!" << endl;
	}
	catch (RootException &ex)
	{
		cout << "Exception caught!" << endl;
		cout << ex.what() << endl;
	}

	try
	{
		// now can perform other updates using the same updater object
		// make sure to put in your new values for both the data and parameter values
		// for the update
		// set data fields we want to update to their desired values
		// exampleStr to "Second Update" and exampleLong to 66
		TIMESTAMP_STRUCT tomorrow = {2000, 9, 30, 0, 0, 0, 0};
		updateMe = Example(2222, "Second Update", 0.11111, 66, tomorrow);
		updateMe.exampleLong = 66;

		*exampleUpdater = updateMe;

		// now set the parameters indicating which rows we want the update applied
		exampleUpdater.Params().lowIntValue = 21;
		exampleUpdater.Params().highIntValue = 30;
		exampleUpdater.Params().strValue = "To find";

		TIMESTAMP_STRUCT otherParamDate = {2001, 10, 31, 0, 0, 0, 0};
		exampleUpdater.Params().dateValue = otherParamDate;

		// execute the update
		exampleUpdater++;

		cout << exampleUpdater.GetLastCount() << " rows updated!" << endl;
	}
	catch (RootException &ex)
	{
		cout << "Exception caught!" << endl;
		cout << ex.what() << endl;
	}

	LoggingHandler<Example> handler = 
		exampleUpdater.get_io_handler((LoggingHandler<Example> *) NULL);

	typedef LoggingHandler<Example>::LoggedTriple LoggedTriple;

	vector<LoggedTriple> errors = handler.GetLog();

	for (vector<LoggedTriple>::iterator log_it = errors.begin(); log_it != errors.end();
			log_it++)
	{
		LoggedTriple error = *log_it;

		cout << "Error msg = " << error.errmsg << endl;
		cout << "Example = " << error.dataObj << endl;
	}

	PrintSeparator(cout);
}

void TestBadUpdateValidate()
{
	PrintHeader(cout, "TestBadUpdateValidate()");

	// construct view
	DBView<Example> view("DB_EXAMPLE", 
		BCAExampleObj(), "WHERE INT_VALUE BETWEEN (?) AND (?) AND "
		"STRING_VALUE = (?) OR EXAMPLE_DATE = (?)", BPAExampleObj(), 
		DefaultSelValidate<Example>(), BadInsValidate());
		
	// build an updater for the view
	DBView<Example>::update_iterator 
		exampleUpdater;
	
	exampleUpdater = view;

	// set data fields we want to update to their desired values

	Example updateMe;

	TIMESTAMP_STRUCT today = {2000, 9, 29, 0, 0, 0, 0};

	// should be rejected ... operator++() will do nothing
	updateMe = Example(7, "Rejected", 99.99, 25, today);

	try
	{
	  *exampleUpdater = updateMe;
    }
	catch (RootException &ex)
	{
	  cout << "Exception caught!" << endl;
	  cout << ex.what() << endl;
	}

	// now set the parameters indicating which rows we want the update applied
	exampleUpdater.Params().lowIntValue = 5;
	exampleUpdater.Params().highIntValue = 33;
	exampleUpdater.Params().strValue = "Example";

	TIMESTAMP_STRUCT paramDate = {1999, 11, 11, 0, 0, 0, 0};
	exampleUpdater.Params().dateValue = paramDate;

	// execute the update
	exampleUpdater++;

	cout << exampleUpdater.GetLastCount() << " rows updated!" << endl;

	// now can perform other updates using the same updater object
	// make sure to put in your new values for both the data and parameter values
	// for the update
	// set data fields we want to update to their desired values
	// exampleStr to "Second Update" and exampleLong to 66
	TIMESTAMP_STRUCT tomorrow = {2000, 9, 30, 0, 0, 0, 0};
	updateMe = Example(2222, "Accepted", 0.11111, 66, tomorrow);

	try
	{
		*exampleUpdater = updateMe;
    }
	catch (RootException &ex)
	{
	  cout << "Exception caught!" << endl;
	  cout << ex.what() << endl;
	}

	// now set the parameters indicating which rows we want the update applied
	exampleUpdater.Params().lowIntValue = 31;
	exampleUpdater.Params().highIntValue = 34;
	exampleUpdater.Params().strValue = "Example";

	TIMESTAMP_STRUCT otherParamDate = {1995, 7, 31, 0, 0, 0, 0};
    exampleUpdater.Params().dateValue = otherParamDate;

	// execute the update
	exampleUpdater++;

	cout << exampleUpdater.GetLastCount() << " rows updated!" << endl;

	LoggingHandler<Example> handler = 
		exampleUpdater.get_io_handler((LoggingHandler<Example> *) NULL);

	typedef LoggingHandler<Example>::LoggedTriple LoggedTriple;

	vector<LoggedTriple> errors = handler.GetLog();

	for (vector<LoggedTriple>::iterator log_it = errors.begin(); log_it != errors.end();
			log_it++)
	{
		LoggedTriple error = *log_it;

		cout << "Error msg = " << error.errmsg << endl;
		cout << "Example = " << error.dataObj << endl;
	}

	PrintSeparator(cout);
}

void TestBadBCADelete()
{

	PrintHeader(cout, "TestBadBCADelete()");

	// construct view
	DBView<Example>
		view("DB_EXAMPLE", 
		BadDelBCAExampleObj(), "OR STRING_VALUE = (?) OR INT_VALUE = (?)", 
		DelBPAExampleObj());

	view.set_io_handler(AlwaysThrowsHandler<Example>());

	// build a deleter for the view
	DBView<Example>::delete_iterator exampleDeleter;
	
	try
	{
		exampleDeleter = view;

	    // now set the parameters indicating which rows we want to delete

	    TIMESTAMP_STRUCT y2k = {2000, 1, 1, 0, 0, 0, 0};
	
	    *exampleDeleter = Example(0, "Example", 0.0, 0, y2k);

	    exampleDeleter.Params().strValue = "Find Me";
	    exampleDeleter.Params().lowIntValue = 18;
	    // execute the delete
	    exampleDeleter++;

	    cout << exampleDeleter.GetLastCount() << " rows deleted!" << endl;
	}
	catch (RootException &ex)
	{
		cout << "Exception caught!" << endl;
		cout << ex.what() << endl;
	}

	try
	{
	// now can perform other deletes using the same deleter object
	// make sure to put in your new values for the parameters
	// for the delete
	
	// now set the parameters indicating which rows we want to delete

	TIMESTAMP_STRUCT today = {1999, 9, 29, 0, 0, 0, 0};
	*exampleDeleter = Example(3, "operator->() works", 0.0, 0, today);

	// execute the delete
	exampleDeleter++;

	cout << exampleDeleter.GetLastCount() << " rows deleted!" << endl;
	}

	catch (RootException &ex)
	{
		cout << "Exception caught!" << endl;
		cout << ex.what() << endl;
	}

	PrintSeparator(cout);
}

void TestBadBPADelete()
{

	PrintHeader(cout, "TestBadBPADelete()");

	// construct view
	DBView<Example>
		view("DB_EXAMPLE", 
		DelBCAExampleObj(), "OR STRING_VALUE = (?) OR INT_VALUE = (?)", 
		BadDelBPAExampleObj());

	// view.set_io_handler(AlwaysThrowsHandler<Example>());

	// build a deleter for the view
	DBView<Example>::delete_iterator exampleDeleter;

	try
	{
		exampleDeleter = view;

	    // now set the parameters indicating which rows we want to delete
	    TIMESTAMP_STRUCT y2k = {2000, 1, 1, 0, 0, 0, 0};
	
	    *exampleDeleter = Example(0, "Example", 0.0, 0, y2k);

	    exampleDeleter.Params().strValue = "Find Me";
	    exampleDeleter.Params().lowIntValue = 18;
	    // execute the delete
	    exampleDeleter++;

	    cout << exampleDeleter.GetLastCount() << " rows deleted!" << endl;
	}
	catch (RootException &ex)
	{
		cout << "Exception caught!" << endl;
		cout << ex.what() << endl;
	}

	try
	{
	// now can perform other deletes using the same deleter object
	// make sure to put in your new values for the parameters
	// for the delete
	
	// now set the parameters indicating which rows we want to delete

	TIMESTAMP_STRUCT today = {1999, 9, 29, 0, 0, 0, 0};
	*exampleDeleter = Example(3, "operator->() works", 0.0, 0, today);

	// execute the delete
	exampleDeleter++;

	cout << exampleDeleter.GetLastCount() << " rows deleted!" << endl;
	}

	catch (RootException &ex)
	{
		cout << "Exception caught!" << endl;
		cout << ex.what() << endl;
	}

	LoggingHandler<Example> handler = 
		exampleDeleter.get_io_handler((LoggingHandler<Example> *) NULL);

	typedef LoggingHandler<Example>::LoggedTriple LoggedTriple;

	vector<LoggedTriple> errors = handler.GetLog();

	for (vector<LoggedTriple>::iterator log_it = errors.begin(); log_it != errors.end();
			log_it++)
	{
		LoggedTriple error = *log_it;

		cout << "Error msg = " << error.errmsg << endl;
		cout << "Example = " << error.dataObj << endl;
	}

	PrintSeparator(cout);
}
