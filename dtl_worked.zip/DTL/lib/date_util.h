/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// provides comparison operators for dates
// Initial: 10/9/2000 - MG
// Reviewed: 11/12/2000 - CJ
// Edited: 12/19/2000 - MG - added namespaces
// Expanded: 2/20/2001 - Added date math library

#ifndef _DATE_UTIL_H
#define _DATE_UTIL_H

#include "std_inc.h"
#include "RootException.h"


BEGIN_DTL_NAMESPACE

// "macro" indicating success on return from an ODBC function
inline bool RC_SUCCESS(RETCODE rc)
{
	return (rc == SQL_SUCCESS || rc == SQL_SUCCESS_WITH_INFO);
}

int TSCmp(const TIMESTAMP_STRUCT &ts1, const TIMESTAMP_STRUCT &ts2);

bool operator<(const TIMESTAMP_STRUCT &ts1, const TIMESTAMP_STRUCT &ts2);

bool operator==(const TIMESTAMP_STRUCT &ts1, const TIMESTAMP_STRUCT &ts2);

bool operator!=(const TIMESTAMP_STRUCT &ts1, const TIMESTAMP_STRUCT &ts2);

bool operator>(const TIMESTAMP_STRUCT &ts1, const TIMESTAMP_STRUCT &ts2);

bool operator>=(const TIMESTAMP_STRUCT &ts1, const TIMESTAMP_STRUCT &ts2);

bool operator<=(const TIMESTAMP_STRUCT &ts1, const TIMESTAMP_STRUCT &ts2);

ostream &operator<<(ostream &o, const TIMESTAMP_STRUCT &ts);


typedef unsigned long jtime_t;
typedef TIMESTAMP_STRUCT timestamp_t;


/* Structure to hold time information */
/* Dates must lie in the range January 1, 1970, to Jan 1, 4000. */
typedef struct tag_jtime_tm {
  int   sec;		// Seconds after the minute (0, 61)
  int   min;		// minutes after the hour (0, 59)
  int   hour;	// hours since midnight (0, 23)
  int   day;	// day of the month
  int   mon;		// month number (1, 12)
  int   year;	// year number (AD)
} jtime_tm;



RETCODE Timestamp2Jtime(const timestamp_t *tst, jtime_t *jtime );
RETCODE Jtime2Timestamp(jtime_t jtime, timestamp_t *tst);
RETCODE jultime(const jtime_tm *time, jtime_t *jtime);
jtime_t DefaultValuationDt(void);
void SetDefaultValuationDt(jtime_t ValuationDt);
jtime_t Now(void);
jtime_t Today(void);
RETCODE julday(int day, int month, int year, jtime_t *jtime);
RETCODE unjultime(jtime_t jtime, jtime_tm *time);
RETCODE unjulday(jtime_t jtime, int *dd, int *mm, int *iyyy);
RETCODE addtime(jtime_t oldtime, jtime_tm add, jtime_t *newtime);
jtime_t addmonths(jtime_t oldtime, int months);


jtime_t addsecs(jtime_t oldtime, int secs);
char *jul2str(jtime_t juldate);
RETCODE str2jultm(char *szDt, jtime_t *jtime);
char *jul2strtm(jtime_t jtime);
void jul2SQLtm(jtime_t jultime, char *szSQLtm);
double diffdays(jtime_t date1, jtime_t date2);
double diffhours(jtime_t date1, jtime_t date2);
double diffsecs(jtime_t date1, jtime_t date2);
jtime_t eomonth(jtime_t oldtime);
jtime_t eoweek(jtime_t oldtime);
jtime_t eoday(jtime_t oldtime);
jtime_t beginmonth(jtime_t oldtime);
jtime_t beginweek(jtime_t oldtime);
jtime_t beginday(jtime_t oldtime);
int month_days(int year, int month) ;
int year(jtime_t oldtime);
int month(jtime_t oldtime);
int monthweek(jtime_t now);
jtime_t maxtime(jtime_t a, jtime_t b);
jtime_t mintime(jtime_t a, jtime_t b);
RETCODE convert_from_timezone(jtime_t oldtime, const char *szZone, 
							  jtime_t *newtime);
RETCODE get_timezone_offset(const char *szZone, int *piOffset);
char *GetLocalTimezone(void);
RETCODE XL2jtime(double xltime, jtime_t *jtime);
RETCODE jtime2XL(jtime_t jtime, double *xltime);

void date_unit_test(void) ;

#define SECONDS_PER_DAY 86400
#define SECONDS_PER_HOUR 3600
#define SECONDS_PER_HALFHOUR 1800

/* The next set of constants is used for debugging in order to trap
   date over or underflow errors. These bounds are calculated in a
   rather rough manner, but the idea behind them is to set off
   warning bells for "large" or "small" dates.  These should
   not be used in any calculations since they are only approximate.
*/
#define MIN_YEAR 1970
#define MAX_YEAR 4000

/* MAX_JTIME and MIN_JTIME may be used by outside routines
   in order to define endpoints for acceptable dates.  These
   constants are often useful for searching algorithms etc.
*/
#define MAX_JTIME (jtime_t) (((MAX_YEAR - MIN_YEAR) * 365.25 * SECONDS_PER_DAY))
#define MIN_JTIME 0


/*------------------------------------------------------------------------*/
// Given two times, return the later (max) of these two times
/*------------------------------------------------------------------------*/
inline jtime_t maxtime(jtime_t a, jtime_t b) {
	return max(a, b);
}

/*------------------------------------------------------------------------*/
// Given two times, return the earlier (min) of these two times
/*------------------------------------------------------------------------*/
inline jtime_t mintime(jtime_t a, jtime_t b) {
	return min(a, b);
}

/*------------------------------------------------------------------------*/
// This routine takes the time stored in oldtime and adds to it the
// specified number of days to obtain
// a new time which is returned
/*------------------------------------------------------------------------*/
inline jtime_t adddays(jtime_t oldtime, int days) {

	return oldtime + SECONDS_PER_DAY * days;
}

/*------------------------------------------------------------------------*/
// This routine takes the time stored in oldtime and adds to it the
// specified number of days to obtain
// a new time which is returned
/*------------------------------------------------------------------------*/
inline jtime_t addhours(jtime_t oldtime, int hours) {

	return oldtime + SECONDS_PER_HOUR * hours;
}

/*------------------------------------------------------------------------*/
// Given a particular day return the time corresponding to
// the end of that day
/*------------------------------------------------------------------------*/
inline jtime_t eoday(jtime_t oldtime) {
	jtime_t newtime;
	
	newtime = (int)(oldtime / SECONDS_PER_DAY);
	newtime *= SECONDS_PER_DAY;
	newtime += SECONDS_PER_DAY - 1;

	return newtime;
}



/*------------------------------------------------------------------------*/
// Given a particular day return the time corresponding to
// the beginning of that day
/*------------------------------------------------------------------------*/
inline jtime_t beginday(jtime_t oldtime) {
	jtime_t newtime;
	
	newtime = (int)(oldtime / SECONDS_PER_DAY);
	newtime *= SECONDS_PER_DAY;
		
	return newtime;
}


/*------------------------------------------------------------------------*/
// Given a particular date return the weekday corresponding
// to that date. 0 = Sunday, 1 = Monday etc.
/*------------------------------------------------------------------------*/
inline int weekday(jtime_t oldtime) {

	return (oldtime/SECONDS_PER_DAY + 4) % 7;
}

/*------------------------------------------------------------------------*/
// SameDay: Tests to see if two times refer to the same day
// Returns TRUE if both times are on the same day, false otherwise
/*------------------------------------------------------------------------*/
inline short SameDay(jtime_t jultime1, jtime_t jultime2) {
	return (jultime1 / SECONDS_PER_DAY) == (jultime2 / SECONDS_PER_DAY);
}

/*------------------------------------------------------------------------*/
// Class to form lightweight wrapper around jtime_t
// Note the cast operators below which allow the class to be passed in to
// the jtime_t math functions above
/*------------------------------------------------------------------------*/
class jtime_c {
private:
	jtime_t jtime;
public:
	jtime_c(const jtime_t &t) : jtime(t) {}

	jtime_c(const timestamp_t &ts) {
		RETCODE rc;
		rc = Timestamp2Jtime(&ts, &jtime );
		if (!RC_SUCCESS(rc))
			throw RootException("jtime_c::jtime_c(timestamp t&)", "Invalid time passed to constructor");
	}

	jtime_c() : jtime (MIN_JTIME) {	}

	operator jtime_t() const {
		return jtime;
	}

	operator timestamp_t() const {
		timestamp_t tst;
		RETCODE rc;
		rc = Jtime2Timestamp(jtime, &tst);
		if (!RC_SUCCESS(rc))
			throw RootException("jtime_c::operator timestamp_t()", "Invalid time held by class.");

		return tst;
	}

	jtime_c &operator=(const jtime_c &other)
	{ 
	   jtime = other.jtime;
	   return *this;
	}

	jtime_c &operator=(const jtime_t &t)
	{ 
	   jtime = t;
	   return *this;
	}

	jtime_c &operator=(const timestamp_t &ts) {
		RETCODE rc;
		rc = Timestamp2Jtime(&ts, &jtime );
		if (!RC_SUCCESS(rc))
			throw RootException("jtime_c::jtime_c(timestamp t&)", "Invalid time passed to constructor");

	    return *this;
	}

	friend bool operator<(const jtime_c &lhs, const jtime_c &rhs);
	friend bool operator==(const jtime_c &lhs, const jtime_c &rhs);
	friend bool operator!=(const jtime_c &lhs, const jtime_c &rhs);
	friend bool operator>(const jtime_c &lhs, const jtime_c &rhs);
	friend bool operator>=(const jtime_c &lhs, const jtime_c &rhs);
	friend bool operator<=(const jtime_c &lhs, const jtime_c &rhs);


	friend ostream &operator<<(ostream &o, const jtime_c &ts);
};

inline bool operator<(const jtime_c &lhs, const jtime_c &rhs) {return lhs.jtime < rhs.jtime;};
inline bool operator==(const jtime_c &lhs, const jtime_c &rhs) {return lhs.jtime == rhs.jtime;};
inline bool operator!=(const jtime_c &lhs, const jtime_c &rhs) {return lhs.jtime != rhs.jtime;};
inline bool operator>(const jtime_c &lhs, const jtime_c &rhs) {return lhs.jtime > rhs.jtime;};
inline bool operator>=(const jtime_c &lhs, const jtime_c &rhs) {return lhs.jtime >= rhs.jtime;};
inline bool operator<=(const jtime_c &lhs, const jtime_c &rhs) {return lhs.jtime <= rhs.jtime;};


inline ostream &operator<<(ostream &o, const jtime_c &ts) 
{
	o << jul2strtm(ts.jtime);
	return o;
};


END_DTL_NAMESPACE

#endif
