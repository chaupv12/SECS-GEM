/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// this module contains the basic bind operators for binding DB columns
// and SQL parameters to memory structures
// Initial: 9/6/2000 - MG
// Reviewed: 11/12/2000 - CJ
// Edited: 11/14/2000 - MG - inherited ETIException from RootException
// Edited: 12/19/2000 - MG - added namespaces

#ifndef _BIND_BASICS_H
#define _BIND_BASICS_H

#include "std_inc.h"
#include "DB_Base.h"

BEGIN_DTL_NAMESPACE

// what kind of type do we have
// enum TypeComplexity { TYPE_PRIMITIVE, TYPE_COMPLEX, TYPE_INVALID };

class ETIException : public RootException
{
public:

   ETIException(const string &meth, const string &msg) : 
	  RootException(meth, msg, "ETIException") { }

   // RootException::what() sufficient for our needs
};

// contains translations from SQL to C types
// short, unsigned short, int, unsigned int, long, unsigned long
//					double, float, struct TIMESTAMP_STRUCT, char *, string

enum {C_UNKNOWN=0, C_SHORT='n', C_USHORT='N', C_INT='i', C_UINT='I', C_LONG='l', 
C_ULONG='L', C_DOUBLE='d', C_FLOAT='f',
C_TIMESTAMP='t', C_CHAR_STAR='C'-'A'+1, C_STRING='s', C_JTIME_C = 'j'};

class TypeTranslation
{
public:
   // what kind of type do we have
   enum TypeComplexity { TYPE_PRIMITIVE, TYPE_COMPLEX, TYPE_INVALID };

   string typeNm;
   char   typeId;
   SDWORD sqlType;
   SDWORD cType;
   TypeComplexity complexity;  // is the type primitive or complex
   size_t size;

   TypeTranslation() : typeNm(""), typeId(0), sqlType(0), cType(0), complexity(TYPE_INVALID), size(0) { }

   TypeTranslation(const string &nm, char id, SDWORD sql, SDWORD c,
				   TypeComplexity comp, size_t s) : typeNm(nm), typeId(id), sqlType(sql), cType(c),
				   complexity(comp), size(s) { }

   // exception-safe swap()
   void swap(TypeTranslation &other)
   {
	  typeNm.swap(other.typeNm);
	  std::swap(typeId, other.typeId);
	  std::swap(sqlType, other.sqlType);
	  std::swap(cType, other.cType);
	  std::swap(complexity, other.complexity);
	  std::swap(size, other.size);
   }

   // exception-safe assignment
   TypeTranslation &operator=(const TypeTranslation &other)
   {
	  if (this != &other)
	  {
		 TypeTranslation temp(other);
		 swap(temp);
	  }

	  return *this;
   }

   // is this a primitive type
   bool IsPrimitive() const { return complexity == TYPE_PRIMITIVE; }

   friend bool operator==(const TypeTranslation &tt1, const TypeTranslation &tt2)
   {
	  return tt1.typeNm == tt2.typeNm && tt1.typeId == tt2.typeId &&
		     tt1.sqlType == tt2.sqlType && tt1.cType == tt2.cType &&
			 tt1.complexity == tt2.complexity && tt1.size == tt2.size;
   }

   friend bool operator!=(const TypeTranslation &tt1, const TypeTranslation &tt2)
   {
	  return !(tt1 == tt2);
   }

   friend class ETI_Map;
};

// extended type information containing type name and SQL to C mappings
// for the appropriate types
class ETI_Map : public map<string, TypeTranslation>
{
    public:
		// build our ETI_Map of SQL to C type mappings
		static ETI_Map BuildETI();

		// does the stringified type represent a primitive?
		// primitive is defined as being in the map
		// if not in map, we assume the type is not primitive
		bool IsPrimitive(const string &typeNm) const
		{
			ETI_Map::const_iterator e_it = this->find(typeNm);

			// type not found --> it's not primitive
			if (e_it == end())
				return false;

			// check the ETI for this type and return whether it's
			// primitive or not
			return ((*e_it).second.IsPrimitive());
		}
};


// the actual type translation map is here
extern ETI_Map SQL_types_to_C;

// used in GenericCmp()
extern const int TYPE_NOT_SUPPORTED;

// compare the contents of the pointers of the type specified by CTypeStr
// if (*pMember1 < *pMember2)
//	 return -1;
// else if (*pMember1 == *pMember2)
//   return 0;
// else if (*pMember1 > *pMember2)
//	 return 1;
int GenericCmp(void *pMember1, void *pMember2, int typeId);

// map SQL column type to C type
TypeTranslation Map_SQL_types_to_C(int sql_type);

END_DTL_NAMESPACE

#endif
