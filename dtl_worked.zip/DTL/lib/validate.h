/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// simple class which simply keeps track whether an object is in a valid state
// Initial: 9/5/2000 - MG
// Edited: 11/14/2000 - MG - Inherited ValidityException from RootException class
// Edited: 12/19/2000 - MG - added namespaces

#ifndef _VALIDATE_H
#define _VALIDATE_H

#include "std_inc.h"
#include "RootException.h"

BEGIN_DTL_NAMESPACE

// enum Validity { INVALID = 0, VALID = 1 };
// enum Revalidation { NONE_TRIED = 0, REVALIDATE_FAILED = 1 };

// thrown on a ValidatedObject if object's state is invalid when validate() called
class ValidityException : public RootException
{
   public:
      enum Revalidation { NONE_TRIED = 0, REVALIDATE_FAILED = 1 };

	  const string objType; // stringified type of the object
	  // const string errmsg;  // message inherited from RootException

      ValidityException(const string &meth, const string &obType,
		  Revalidation reval = NONE_TRIED) : 
		  RootException(meth, "Cannot operate on invalidated object of type " + obType + "!  " +
		  (reval == REVALIDATE_FAILED ? "(irreconcilable revalidate())" : ""),
		  "ValidityException"),
		  objType(obType)
	  {
		// write to error log???
	  }

	  virtual const char *what() const throw()
	  {	
		string rootWhat = RootException::what();

		ostrstream o;
	
		o << rootWhat << "objType: " << objType << endl << ends;
	    
		// this gymnastics is needed so result isn't destroyed
		// paste these two lines into all what() code
		whatbuf = o.str();
		return whatbuf.c_str();
	  }
};


class ValidatedObject
{
  public:
      enum Validity { INVALID = 0, VALID = 1 };
  private:
 	  Validity validity;	// is the object's state valid?
  public:
	  ValidatedObject() : validity(VALID)
	  { }

	  virtual ~ValidatedObject() {invalidate();}

	  virtual void swap(ValidatedObject &other) {
		  std::swap(validity, other.validity);
	  }

	  // mark object as invalid!
	  virtual void invalidate()
	  {
		 validity = INVALID;
	  }

	  // throws an exception if the object is invalid
	  virtual void validate() const
	  {
		 if (!valid())
			 throw ValidityException("ValidatedObject::validate()", 
				typeid(*this).name());
	  }

	  // make the object valid again by trying to get it back
	  // in a valid state, if not reconcilable, throw an exception
	  virtual void revalidate()
	  {
		 // nothing to do if already valid
		 if (valid())
			 return;

		 throw ValidityException("ValidatedObject::revalidate()",
			 typeid(*this).name(), ValidityException::REVALIDATE_FAILED);
	  }

	  Validity GetValidity() const
	  { 
		  valid(); // coerce validity flag to be updated
		  return validity;
	  }

	  // overrides of this function should invalidate() the object if they discover that
	  // the object is invalid
	  virtual bool valid() const { return validity == VALID; }
};

END_DTL_NAMESPACE

#endif

