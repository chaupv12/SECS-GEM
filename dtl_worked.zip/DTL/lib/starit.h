/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// Edited: 12/19/2000 - MG - added namespaces

#ifndef _STAR_IT_
#define _STAR_IT_

#include "std_inc.h"

BEGIN_DTL_NAMESPACE

// TEMPLATE CLASS star_bidirectional_iterator
template<class _BI,
	class _Ty,
	class _Rt = _Ty&,
	class _Pt = _Ty *,
	class _D = ptrdiff_t>
	class star_bidirectional_iterator :	
#ifndef __SGI_STL_PORT
	public iterator<bidirectional_iterator_tag,  _Ty, _D>
#else
	 // not sure why STLport not recognizing the standard iterator tag
	 // when used in algorithms like copy(_InputIter __first, _InputIter __last, _OutputIter __result)
	 // use STLport specific alternative
	 public bidirectional_iterator<_Ty, _D>
#endif
 {
public:
	typedef star_bidirectional_iterator<_BI,
		_Ty, _Rt, _Pt, _D> _Myt;
	typedef _BI iter_type;
	typedef _Rt reference_type;
	typedef _Pt pointer_type;
	star_bidirectional_iterator()
		{}
	explicit star_bidirectional_iterator(_BI _X)
		: current(_X) {}
	_BI base() const
		{return (current); }
	_Rt operator*() const
		{return **current;}
	_Pt operator->() const
		{return (&**this); }
	_Myt& operator++()
		{++current;
		return (*this); }
	const _Myt operator++(int) // const here to prevent iterator++++ type operations
		{_Myt oldValue(*this); // standard is to return old value
		++current;
		return oldValue;}
	_Myt& operator--()
		{--current;
		return (*this); }
	const _Myt operator--(int)
		{_Myt oldValue(*this);
	    --current;
		return oldValue;}
protected:
	_BI current;
	};
template<class _BI, class _Ty, class _Rt, class _Pt,
	class _D> inline
	bool operator==(const star_bidirectional_iterator<_BI,
			_Ty, _Rt, _Pt, _D>& _X,
		const star_bidirectional_iterator<_BI,
			_Ty, _Rt, _Pt, _D>& _Y)
	{return (_X.base() == _Y.base()); }
template<class _BI, class _Ty, class _Rt, class _Pt,
	class _D> inline
	bool operator!=(const star_bidirectional_iterator<_BI,
			_Ty, _Rt, _Pt, _D>& _X,
		const star_bidirectional_iterator<_BI,
			_Ty, _Rt, _Pt, _D>& _Y)
	{return (!(_X == _Y)); }


END_DTL_NAMESPACE
#endif
