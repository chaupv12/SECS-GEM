/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// base class for DB accessors ... nested classes inside of DBView template
// initial: 9/7/2000 - MG
// Reviewed: 11/12/2000 - CJ
// Edited: 12/19/2000 - MG - added namespaces

#ifndef _ITERATOR_H
#define _ITERATOR_H

#include "std_inc.h"
#include "DB_Base.h"
#include "DBView.h"
#include "DBStmt.h"
#include "DBDefaults.h"
#include "CountedPtr.h"

BEGIN_DTL_NAMESPACE

// creating the BoundIOs object is common for both kinds of 
// contains facilities common to all database accessors (SELECT, INSERT, UPDATE, 
// DELETE)
template<class DataObj, class ParamObj = DefaultParamObj<DataObj> > class DB_iterator :
	public dtl_ios_base
{
public:
	// What type of query?
    // enum SQLQueryType { SELECT, INSERT, UPDATE, DEL, USER_DEFINED };
    // typename DBView<DataObj, ParamObj>::IOHandler;
protected:
	DBView<DataObj, ParamObj> *pDBview; 
			// view this accessor refers to
	BoundIOs boundIOs;		// map of bindings from memory structures to DB columns
							// and parameters
	CountedPtr<DataObj>  pRowbuf;		// pointer to the buffer for a DataObj
	CountedPtr<ParamObj> pParambuf;		// current parameter object for accessor
	DBStmt stmt;			// statement for this accessor

	SQLQueryType sqlQryType; // what type of SQL query is this?

	typedef BPAWrap<ParamObj> BPA;

	BPA bpa; // bind parameter address function

	// signature of error handler for the iterator
	// couldn't get a typedef in DBView with a forwarding typedef here to work
	// due to template instantiation problem
	// typedef typename DBView<DataObj, ParamObj>::IOHandler IOHandler;

	mutable IOHandler<DataObj, ParamObj> io_handler; // error handler for this iterator

	long count;		// # of records accessed so far since iterator was opened
	long lastCount; // # of records accessed in last operation
					// insert and select iterators, means since last
					// iterator assignment or copy
					// update and delete, means since last call
					// to operator++()

    // is accessor ready for use ... that is, is stmt. ready to be executed
	bool IsReady() const { return stmt.IsReady(); }

    // return a reference to the accessor's stmt.
	DBStmt &GetStmt() const { return stmt; }

	// functions to open and destroy the iterators - mainly for bindings and DB resources
    // how do we make this exception safe???
	virtual void open()
	{
	    try
		{  
		  if (IsReady())
			return;

		  pRowbuf = new DataObj;

		  stmt.Initialize();

		  MakeBindings(); // virtual call will invoke appropriate version of MakeBindings()

		  count = 0;
		  lastCount = 0;
		}
		catch (...)
		{
			setstate(badbit);   // iterator is bad if open is unsuccessful
			throw;
		}
	}

	// no throw destroy()
	virtual void destroy()
	{
		// clean out stmt
	   	if (stmt.IsAllocated())
	   	{
		   try
		   {
			   stmt.Destroy();
		   }
		   catch (...)
		   {

		   }
		}

		count = 0;
		lastCount = 0;

		// note that we don't touch the rowbuf reference in here
		// if the iterator gets reopened, it will get a fresh rowbuf reference to work
		// with
	}

	// utility function to aid with making the necessary calls
	// to stmt.BindCol() and stmt.BindParam() for the BoundIOs

	// exception safety impossible if BPA isn't exception safe
	// (may not be possible anyway?)
	virtual void MakeBindings()
	{
	  try
	  {
		// apply BPA
		boundIOs.BindParamBase(*pParambuf);
		bpa(boundIOs, *pParambuf);

		// need to know the number of parameters already bound so
		// we can add the proper offset to calls to BindParam()
		int numParamsAlreadyBound;

		// number of parameters already bound is:
		// 0 in the case of a select (they've been bound using BindCol())
		// boundIOs.NumColumns() in the case of an insert, update, or delete

		switch (sqlQryType)
		{
		case SELECT: default: numParamsAlreadyBound = 0; break;
		case INSERT: case UPDATE: case DEL:
			numParamsAlreadyBound = boundIOs.NumColumns();
			break;
		}

		// now bind the parameters using stmt.BindParam()
		for (BoundIOs::iterator b_it = boundIOs.begin();
				b_it != boundIOs.end(); b_it++)
		{
			BoundIO &param = (*b_it).second;

			if (param.IsParam())
			{
			   // bind the actual column using BindParam()

			   // apply offset to get parameter # we need to bind to in the SQL stmt.
			   int paramNum = numParamsAlreadyBound + atoi(param.GetName().c_str());
			   
			   // now actually bind the parameter
			   stmt.BindParam(paramNum, SQL_PARAM_INPUT,
						param.GetCType(), param.GetSQLType(),
						param.GetRawSize(), param.GetPrecision(), param.GetRawPtr(),
						param.GetBufferLength(), param.GetBytesFetchedPtr());
			}

		}
	  }
	  catch (...)
	  {
		 setstate(badbit);
		 throw;
	  }

	}

	// returns a valid rowbuf reference in order to preserve the invariants for input iterators
	CountedPtr<DataObj> GetRowbufPtr()
	{
		if (!pRowbuf)
			open(); // exception safe if open() is exception safe

		return pRowbuf;
	}

public:
	DB_iterator() : dtl_ios_base(),
				pDBview(NULL), pRowbuf(NULL), pParambuf(new ParamObj), sqlQryType(USER_DEFINED), 
				count(0), lastCount(0), stmt(),
				boundIOs(), io_handler(LoggingHandler<DataObj, ParamObj>()), 
				bpa(DefaultBPA<ParamObj>())
	{ }

	DB_iterator(const DBView<DataObj, ParamObj> &view, SQLQueryType qryType) :
				dtl_ios_base(),
				pDBview(NULL), pRowbuf(NULL), pParambuf(new ParamObj), sqlQryType(qryType), bpa(view.GetBPA()), 
				count(0), lastCount(0), stmt(view.BuildQry(qryType), view.GetConnection()),
				boundIOs(BoundIO::BIND_ADDRESSES), io_handler(view.io_handler)
	{ 
	  DBView<DataObj, ParamObj> &view_ref =
		  const_cast<DBView<DataObj, ParamObj> &>(view);
	  pDBview = &view_ref;
	}

    // copy constructor and assignment operator required for Assignable property
	DB_iterator(const DB_iterator<DataObj, ParamObj> &db_it) :
	    dtl_ios_base(),
		pDBview(db_it.pDBview), pRowbuf(db_it.pRowbuf), pParambuf(db_it.pParambuf),
		sqlQryType(db_it.sqlQryType), bpa(db_it.bpa), count(db_it.count),
		lastCount(db_it.lastCount), stmt(db_it.GetQuery(), (db_it.pDBview)->GetConnection()),
		boundIOs(BoundIO::BIND_ADDRESSES), io_handler(db_it.io_handler)
		{  }

	// exception-safe swap()
	void swap(DB_iterator<DataObj, ParamObj> &other) {
		// put the two user constructs at the beginning to minimize damage if they throw
		// -- which they should not as part of the user requirements
		dtl_ios_base::swap(other);
		bpa.swap(other.bpa);
		std::swap(pDBview, other.pDBview);
		boundIOs.swap(other.boundIOs);
		pParambuf.swap(other.pParambuf);
		pRowbuf.swap(other.pRowbuf);
		stmt.swap(other.stmt);
		std::swap(sqlQryType, other.sqlQryType);
		std::swap(count, other.count);
		std::swap(lastCount, other.lastCount);
		io_handler.swap(other.io_handler);
	}

	// exception-safe assignment
	DB_iterator<DataObj, ParamObj> &
		operator=(const DB_iterator<DataObj, ParamObj> &db_it)
	{
	  if (this != &db_it)
	  {
		DB_iterator<DataObj, ParamObj> temp(db_it);
		swap(temp);
	  }

	  return *this;
	}

#if 0
	// return a pointer to the rowbuf 
	DataObj *operator->()
	{
	   return GetRowbufPtr();
	}
#endif

	// operator*() must return a DataObj rather than
	// a DataObj & for select iterators
	// all other iterator types return a DataObj &

	// needed so users can set parameter values
	ParamObj &Params()
	{
		return *pParambuf;
    }

	// exception-safety - atomicity and consistency guaranteed
	// if ParamObj::operator=() is atomic and consistent
	void Params(const ParamObj &params)
	{
		*pParambuf = params;
	}

	// return view referred to by this iterator
	// made to return as const so the caller can not modify the view
	const DBView<DataObj, ParamObj> &GetView() const
	{
	  return *pDBview;
	}

	// return # of records accessed so far since iterator was opened
	long GetCount() const
	{
	  return count;
	}

	// return # of records accessed since last operation
	// (see description of lastCount data member for more details)
	long GetLastCount() const
	{
      return lastCount;
	}

	// return query string associated with this iterator
    string GetQuery() const
	{
	  return stmt.GetQuery();
	}

	// set and get error handler functions
	// similar to set_new_handler() and get_new_handler() in the standard library
    
	// Note: no outstanding iterators over a view are affected when the handler is
	// changed, but any iterators created after the handler is reset will
	// use the new handler by default

	template<class UserHandler> const UserHandler &
		   get_io_handler(const UserHandler *dummy) const
	{
		return io_handler.get(dummy);
	}

	// returns raw IOHandler object

	IOHandler<DataObj, ParamObj> &get_io_handler() const
	{
		return io_handler;
	}

	void set_io_handler(IOHandler<DataObj, ParamObj> h)
	{
		io_handler.swap(h) ;
	}

	virtual ~DB_iterator()
	{
		try
		{
		    destroy();
		}
		catch (...)
		{

		}
	}
};

// cursor base with added abstractions for columns ... needed for SELECT, INSERT, 
// UPDATE
template<class DataObj, class ParamObj = DefaultParamObj<DataObj> >
	class DB_iterator_with_cols :
       public DB_iterator<DataObj, ParamObj>
{
  protected:
	typedef BCAWrap<DataObj> BCA;
	BCA bca; // bind column address function

	// utility function to aid with making the necessary calls
	// to stmt.BindCol() and stmt.BindParam() for the BoundIOs 

	// can't be made exception safe???
	virtual void MakeBindings()
	{
	 try
	 {
	   // apply BCA (generate binding addr. mapping)
	   boundIOs.BindAsBase(*pRowbuf);
       bca(boundIOs, *pRowbuf);

	   // superclass method does first part of work
	   // binding the params ... needed to be done first as mySQL requires
	   // all parameters to be bound before any columns may be bound
	   DB_iterator<DataObj, ParamObj>::MakeBindings();

	   // column # needed by stmt.BindCol() and stmt.BindParam()
	   int columnNumToBind = 0;

	   // bind columns appropriately
	   // note that columns will appear in the map in the same order that they are
	   // in the view's colNames set as both conainers are ordered
	   for (BoundIOs::iterator bc_it = boundIOs.begin(); bc_it != boundIOs.end(); bc_it++)
	   {
			BoundIO &column = (*bc_it).second;

			if (column.IsColumn())
			{
				// get target buffer we need to bind to
				void *addr_to_bind = column.GetRawPtr();
				int size_to_bind = column.GetRawSize();
				int buffer_len = column.GetBufferLength();

				// must call stmt.BindCol() on a SELECT
				// and BindParam() for INSERT and UPDATE
				switch (sqlQryType)
				{
				   case SELECT:
					  // bind the actual column using BindCol()
					  stmt.BindCol(columnNumToBind++,
						    column.GetCType(), addr_to_bind,
					        size_to_bind, column.GetBytesFetchedPtr());
					  break;
				   case INSERT: case UPDATE: case DEL:
					  // bind the actual column using BindParam()
					  stmt.BindParam(columnNumToBind++, SQL_PARAM_INPUT,
						column.GetCType(), column.GetSQLType(),
						size_to_bind, column.GetPrecision(), addr_to_bind,
						buffer_len, column.GetBytesFetchedPtr());
					  break;
				}
			}

	   }

	 }
	 catch (...)
	 {
		setstate(badbit);
		throw;
	 }
	}

  public:
	DB_iterator_with_cols() : DB_iterator<DataObj, ParamObj>(), 
		bca(DefaultBCA<DataObj>()) { }

	DB_iterator_with_cols(const DBView<DataObj, ParamObj> &view, SQLQueryType qryType) : 
			DB_iterator<DataObj, ParamObj>(view, qryType), bca(view.GetBCA()) { }    

	// copy constructor and assignment operator required for Assignable property
	// the superclass versions should do all the work
	DB_iterator_with_cols(const DB_iterator_with_cols<DataObj, ParamObj> &db_it) :
			DB_iterator<DataObj, ParamObj>(db_it), bca(db_it.GetView().GetBCA()) { }

	// exception safe swap function
	void swap(DB_iterator_with_cols<DataObj, ParamObj> &other) {
		DB_iterator<DataObj, ParamObj>::swap(other);
		bca.swap(other.bca);
	}

	// exception safe assignment
	DB_iterator_with_cols<DataObj, ParamObj> &
		operator=(const DB_iterator_with_cols<DataObj, ParamObj> &db_it)
	{
		if (this != &db_it)
		{
			DB_iterator_with_cols<DataObj, ParamObj> temp(db_it);
			swap(temp);
		}

		return *this;
	}

	virtual ~DB_iterator_with_cols() { }
};

END_DTL_NAMESPACE

#endif
