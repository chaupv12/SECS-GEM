/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// iterator used for INSERTS
// nested class of DBView
// Initial: 9/8/2000 - MG
// Edited: 12/19/2000 - MG - added namespaces

#ifndef _INSERT_ITERATOR_H
#define _INSERT_ITERATOR_H

#include "std_inc.h"
#include "DBView.h"
#include "select_insert_iterator.h"

BEGIN_DTL_NAMESPACE

// iterator used for INSERTS
template<class DataObj, class ParamObj = DefaultParamObj<DataObj> >
  class DB_insert_iterator :
    public DB_select_insert_iterator<DataObj, ParamObj>,
#ifndef __SGI_STL_PORT
	 public iterator<output_iterator_tag, DataObj, ptrdiff_t>
#else
	 // not sure why STLport not recognizing the standard iterator tag
	 // when used in algorithms like copy(_InputIter __first, _InputIter __last, _OutputIter __result)
	 // use STLport specific alternative
	 public forward_iterator<DataObj, ptrdiff_t>
#endif
{
private:

	InsValWrap<DataObj> InsValidate;
	bool validRowbuf; // was previous object valid?

	// write the current row out to the database
	// exception-safety questionable
	void WriteCurrentRow()
	{
		try
		{
		  if (!IsReady())
	    	 open();
		
		  if (bad())
		  {
			throw DBException("DBView::delete_iterator::ExecDelete()",
				"iterator tested bad!", NULL, NULL);
		  }

		  // do nothing if rowbuf is invalid
		  if (!validRowbuf)
			return;

		  // propagate STL strings to their strbufs for proper binding
		  boundIOs.PropagateToSQL();
		  stmt.Execute();
		}
		catch (RootException &ex)
		{
			if (stmt.valid())
				setstate(failbit);
			else
				setstate(badbit);

			dtl_ios_base::MeansOfRecovery error_action =
				io_handler(ex, *this, *(pRowbuf.get()), *pParambuf);

			// what to do for REPERFORM_OPERATION?
			switch (error_action)
			{
			  case dtl_ios_base::THROW_EXCEPTION: throw;
			  case dtl_ios_base::SUPPRESS_ERROR: return;
			}
		}
	    
		count++;
		lastCount++;

		clear();
		validRowbuf = false;
	}

public:
    DB_insert_iterator() : DB_select_insert_iterator<DataObj, ParamObj>(), 
		InsValidate(DefaultInsValidate<DataObj>()), validRowbuf(false)
	{ }
	
	DB_insert_iterator(const DBView<DataObj, ParamObj> &view) :
		DB_select_insert_iterator<DataObj, ParamObj>(view, INSERT), InsValidate(view.GetInsVal()),
			validRowbuf(false)
            { }


	// copy constructor and assignment operator required for Assignable property
	DB_insert_iterator(const DB_insert_iterator<DataObj, ParamObj> &write_it) :
		   DB_select_insert_iterator<DataObj, ParamObj>(write_it), 
		   InsValidate(write_it.InsValidate), validRowbuf(write_it.validRowbuf)
            { }


	// exception-safe swap()
	void swap(DB_insert_iterator<DataObj, ParamObj> &other)
	{
		DB_select_insert_iterator<DataObj, ParamObj>::swap(other);
		std::swap(InsValidate, other.InsValidate);
		std::swap(validRowbuf, other.validRowbuf);
	}

	// exception-safe assignment
	DB_insert_iterator<DataObj, ParamObj> &
		operator=(const DB_insert_iterator<DataObj, ParamObj> &other)
	{
		if (this != &other)
		{
			DB_insert_iterator<DataObj, ParamObj> temp(other);
			swap(temp);
		}

		return *this;
	}

	// return a proxy
	// exception-safe
	DB_insert_iterator<DataObj, ParamObj> &
		operator*()
	{
		return *this;
	}

	// proxy paradigm used to be able to perform InsValidate()
	// on the rowbuf held by the iterator

	// exception-safety guaranteed if GetRowbufPtr(), InsValidate(),
	// and DataObj::operator=() are exception-safe
	DB_insert_iterator<DataObj, ParamObj> &
		operator=(const DataObj &data)
	{
		try
		{  
			if (bad())
			{
			   throw DBException("DBView::delete_iterator::ExecDelete()",
				"iterator tested bad!", NULL, NULL);
			}
			
			CountedPtr<DataObj> pData = GetRowbufPtr();
		
			*pData = data;

		    
			// if user specified a InsVal, apply it
			if (!InsValidate(*pData))
			{
				validRowbuf = false;
		
				if (stmt.valid())
					setstate(failbit);
				else
					setstate(badbit);

				throw DBException("DBView::insert_iterator::operator=(const DataObj &)",
							  "InsValidate() failed on statement \"" +
							  stmt.GetQuery() + "\"!", NULL, NULL);
			}
		
			validRowbuf = true;
		}
		catch (RootException &ex)
		{
			if (stmt.valid())
				setstate(failbit);
			else
				setstate(badbit);

			dtl_ios_base::MeansOfRecovery error_action =
				io_handler(ex, *this, *(pRowbuf.get()), *pParambuf);

			// what to do for REPERFORM_ACTION?
			switch (error_action)
			{
			  case dtl_ios_base::THROW_EXCEPTION: throw;
			  case dtl_ios_base::SUPPRESS_ERROR: return *this;
			}

		}

		clear();
		return *this;
	}

#if 0  // replaced by proxy code
	DataObj &operator*()
	{ 
 	   return *GetRowbufPtr();
	}    
#endif

	// "advance to next record" (preincrement) ... involves writing out latest record
	// while conceptually advancing the iterator, we really aren't changing the state
	// of the iterator at all.

	// IO handler logic is inside of WriteCurrentRow()
	DB_insert_iterator<DataObj, ParamObj> &operator++()
	{
      WriteCurrentRow();
      return *this;    
	}

    // "advance to next record" (postincrement) ... involves writing out latest record
	// while conceptually advancing the iterator, we really aren't changing the state
	// of the iterator at all.
    inline const DB_insert_iterator<DataObj, ParamObj> operator++(int) //const return to prevent iterator++++
	{
	  DB_insert_iterator<DataObj, ParamObj> oldValue(*this);
	  ++(*this);
	  return oldValue;
	}

	// commit inserts from this iterator and clean up
	virtual ~DB_insert_iterator()
	{ }
};  

END_DTL_NAMESPACE

#endif
