/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// misc. string utilities for our DB abstractions
// Initial: 9/7/2000 - MG
// Reviewed: 11/12/2000 - CJ
// Edited: 12/19/2000 - MG - added namespaces

#include "string_util.h"
#include "RootException.h"

BEGIN_DTL_NAMESPACE

// parse a comma-separated list of strings, packaging the result in a vector
// of the strings
vector<string> ParseCommaDelimitedList(string commaList)
{
	  string commaListCopy = commaList; // make copy of string as strtok() may destroy the 

	  vector<string> resultList;
	  char *tokenName;

	  char *c_str = new char[commaListCopy.length() + 1];

	  if (c_str == NULL)
		  throw RootException("ParseCommaDelimetedList", "out of memory");

	  strncpy(c_str, commaListCopy.c_str(), commaListCopy.length() + 1);

	  // grab first entry
	  tokenName = strtok(c_str, ", ");

	  // add latest grabbed name to the set and grab next token
	  // while there are more names to be parsed
	  while (tokenName != NULL)
	  {
		EatLeadingWhitespace(tokenName);
	    resultList.push_back(tokenName);
	    tokenName = strtok(NULL, ", ");
	  }

	  delete[] c_str;

	  return resultList;
}


// finds the number of occurrences of the character in the string
unsigned int numOfOccurrences(char c, string inString)
{
	unsigned int occurrences = 0;

	for (size_t i = 0; i < inString.length(); i++)
	{
		if (c == inString[i])
		{
			occurrences++;
		}
	}

	return occurrences;
}

char *EatLeadingWhitespace(char * & c_str)
{
	if (c_str != NULL)
	{
	   while (*c_str != '\0' && isspace(*c_str))
		  c_str++;
	}

	return c_str;
}

char *EatTrailingWhitespace(char *c_str)
{
	if (c_str != NULL)
	{
		size_t len = strlen(c_str);
	
		for (int i = (int)len - 1; i >= 0; i--)
		{
			if (isspace(c_str[i]))
				c_str[i] = '\0';
			else
				break;
		}
	}

	return c_str;
}

#ifndef _MSC_VER
// define case insensitive string compare routine
// many compilers may already have this

int stricmp(const char *s1, const char *s2) {
	assert(s1 != NULL && s2 != NULL);
	char v1, v2;
	int d=0;
	do{
		v1 = *s1;
		v2 = *s2;
		d = (int)toupper(v1) - (int)toupper(v2);
		s1++;
		s2++;
	} while (d==0 && v1 > 0);
	return d;
}

int strnicmp(const char *s1, const char *s2, int len) {
	assert(s1 != NULL && s2 != NULL && len > 0);
	char v1, v2;
	int d=0;
  int i=0;
	do{
		v1 = *s1;
		v2 = *s2;
		d = (int)toupper(v1) - (int)toupper(v2);
		s1++;
		s2++;
		i++;
	} while (d==0 && v1 > 0 && i < len);
	return d;
}

#endif


END_DTL_NAMESPACE

