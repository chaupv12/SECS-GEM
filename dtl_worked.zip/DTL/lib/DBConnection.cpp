/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// source for DBConnection
// Initial: 9/20/2000 - MG
// Reviewed: 11/12/2000 - CJ
// Edited: 12/19/2000 - MG - added namespaces

#pragma	warning(disable: 4786)

#include "DBConnection.h"

BEGIN_DTL_NAMESPACE

DBEnvironment DBConnection::dbe;

DBConnection DBConnection::defaultConn;

HDBC GetHDBC(const DBConnection &conn)
{
	return conn.GetHDBC();
}

HENV GetHENV(const DBConnection &conn)
{
    return conn.GetHENV();
}

END_DTL_NAMESPACE
