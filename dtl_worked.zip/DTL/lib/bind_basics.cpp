/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 

// this module contains the basic bind operators for binding DB columns
// and SQL parameters to memory structures
// Initial: 9/6/2000 - MG
// Reviewed: 11/12/2000 - CJ
// Edited: 11/20/2000 - MG
// Edited: 12/19/2000 - MG - added namespaces

#include "bind_basics.h"
#include "variant_row.h"
#include "DBConnection.h"
#include "DBStmt.h"

BEGIN_DTL_NAMESPACE

// this version of buildETI() is based on the old Pricer's type lists
// probably will want to switch off of the platform to make the map appropriate for it

// types supported: short, unsigned short, int, unsigned int, long, unsigned long
//					double, float, struct TIMESTAMP_STRUCT, char *, string

ETI_Map ETI_Map::BuildETI()
{
	ETI_Map buildETIMap;	// the ETI map we're building

	// add to these mappings as needed ...
	buildETIMap[typeid(short).name()] =
		TypeTranslation(typeid(short).name(), C_SHORT, SQL_INTEGER, SQL_C_SSHORT, TypeTranslation::TYPE_PRIMITIVE, sizeof(short));
	buildETIMap[typeid(unsigned short).name()] =
		TypeTranslation(typeid(unsigned short).name(), C_USHORT, SQL_INTEGER, SQL_C_USHORT, TypeTranslation::TYPE_PRIMITIVE, sizeof(unsigned short));
	buildETIMap[typeid(int).name()] =
		TypeTranslation(typeid(int).name(), C_INT, SQL_INTEGER, SQL_C_SLONG, TypeTranslation::TYPE_PRIMITIVE, sizeof(int));
	buildETIMap[typeid(unsigned int).name()] =
		TypeTranslation(typeid(unsigned int).name(), C_UINT, SQL_INTEGER, SQL_C_ULONG, TypeTranslation::TYPE_PRIMITIVE, sizeof(unsigned int));
	buildETIMap[typeid(long).name()] =
		TypeTranslation(typeid(long).name(), C_LONG, SQL_INTEGER, SQL_C_SLONG, TypeTranslation::TYPE_PRIMITIVE, sizeof(long));
	buildETIMap[typeid(unsigned long).name()] =
		TypeTranslation(typeid(unsigned long).name(), C_ULONG, SQL_INTEGER, SQL_C_ULONG, TypeTranslation::TYPE_PRIMITIVE, sizeof(unsigned long));
	buildETIMap[typeid(double).name()] =
		TypeTranslation(typeid(double).name(), C_DOUBLE, SQL_DOUBLE, SQL_C_DOUBLE, TypeTranslation::TYPE_PRIMITIVE, sizeof(double));
	buildETIMap[typeid(float).name()] = TypeTranslation(typeid(float).name(), C_FLOAT, SQL_FLOAT, SQL_C_FLOAT, TypeTranslation::TYPE_PRIMITIVE, sizeof(float));
	buildETIMap[typeid(struct tagTIMESTAMP_STRUCT).name()] =
		TypeTranslation(typeid(struct tagTIMESTAMP_STRUCT).name(), C_TIMESTAMP, SQL_TIMESTAMP, SQL_C_TIMESTAMP, TypeTranslation::TYPE_PRIMITIVE, sizeof(struct tagTIMESTAMP_STRUCT));
	buildETIMap[typeid(char *).name()] =
		TypeTranslation(typeid(char *).name(), C_CHAR_STAR, SQL_VARCHAR, SQL_C_CHAR, TypeTranslation::TYPE_PRIMITIVE, sizeof(char *));
    buildETIMap[typeid(string).name()] =
		TypeTranslation(typeid(string).name(), C_STRING, SQL_VARCHAR, SQL_C_CHAR, TypeTranslation::TYPE_COMPLEX, sizeof(string));
	buildETIMap[typeid(jtime_c).name()] =
		TypeTranslation(typeid(jtime_c).name(), C_JTIME_C, SQL_TIMESTAMP, SQL_C_TIMESTAMP, TypeTranslation::TYPE_COMPLEX, sizeof(jtime_c));

	return buildETIMap;
}

ETI_Map SQL_types_to_C = ETI_Map::BuildETI();

const int TYPE_NOT_SUPPORTED = -1000;

// The next function is used by DYNAMIC queries with variant datatypes to
// map SQL column types from SQLGetTypeInfo into target C types to hold values from the columns
// The default mappings shown here were guided by the default conversion table
// for ODBC 3.0 -- Microsoft ODBC 3.0 Programmer's Reference, vol. 2, p. 1218
TypeTranslation Map_SQL_types_to_C(SWORD sql_type) {
	switch (sql_type) {
		case SQL_CHAR: return SQL_types_to_C[typeid(string).name()];
		case SQL_VARCHAR: return SQL_types_to_C[typeid(string).name()];
		case SQL_LONGVARCHAR: return SQL_types_to_C[typeid(string).name()];
		case SQL_DECIMAL: return SQL_types_to_C[typeid(double).name()];
		case SQL_NUMERIC: return SQL_types_to_C[typeid(double).name()];
		case SQL_BIT: return SQL_types_to_C[typeid(short).name()];
		case SQL_TINYINT: return SQL_types_to_C[typeid(short).name()];
		case SQL_SMALLINT: return SQL_types_to_C[typeid(int).name()];
		case SQL_INTEGER: return SQL_types_to_C[typeid(long).name()];
		case SQL_BIGINT: return SQL_types_to_C[typeid(long).name()];
		case SQL_REAL: return SQL_types_to_C[typeid(float).name()];
		case SQL_FLOAT: case SQL_DOUBLE: return SQL_types_to_C[typeid(double).name()];
		case SQL_BINARY: return SQL_types_to_C[typeid(string).name()];
		case SQL_VARBINARY: case SQL_LONGVARBINARY: return SQL_types_to_C[typeid(string).name()];
		case SQL_DATE: case SQL_TIME: case SQL_TIMESTAMP: 
		   case SQL_TYPE_DATE:
                   case SQL_TYPE_TIMESTAMP: 
                        return SQL_types_to_C[typeid(struct tagTIMESTAMP_STRUCT).name()];
		default: {
			string errmsg = "Unknown SQL column type ";
			errmsg += " encountered in Map_SQL_types_to_C()!";
			throw ETIException("Map_SQL_types_to_C()", errmsg);
		}
	}
}

// Analyze a given table and fields to get information 
// about the types of the fields in the table
variant_row_fields GetFieldInfo(const string &TableName, const string &TableFields, DBConnection &conn) {
	const int MAX_COLNAME=50;
	HSTMT hstmt;
	SWORD cCols;
	unsigned char szColName[MAX_COLNAME + 1];
	SWORD cbColName;
	SWORD fSQLType;
	UDWORD cbPrec;
	SWORD cbScale;
	SWORD fNullable;
	RETCODE rc;

	string szSQL = "SELECT " + TableFields + " FROM " + TableName;
	TypeTranslation tt;
	vector<TypeTranslation> vtt;
	vector<string> fields;

	// Allocate and initialize SQL statement
	DBStmt stmt(szSQL, conn);
#ifdef MYODBC_BUG
	stmt.Execute();
#else
	stmt.Initialize();
#endif

	// Have prepared SQL statement, now get information about columns
	// Eventually we will likely make this a method of the DBstmt class itself
	hstmt = GetHSTMT(stmt);

	SQLNumResultCols(hstmt, &cCols);
	for (int i=1; i <=cCols; i++) {
		rc = SQLDescribeCol(hstmt, i, szColName, MAX_COLNAME, &cbColName, &fSQLType,
			&cbPrec, &cbScale, &fNullable);
		if (!RC_SUCCESS(rc)) {
			throw DBException(string("GetFieldInfo"), string("Unable to get field metadata"),
			&conn, &stmt);
		}
		tt = Map_SQL_types_to_C(fSQLType);
		tt.sqlType = fSQLType; // Be sure to tell variant_row_fields actual source SQL type, not mapped type


		vtt.push_back(tt);
		//N.B. we need to let the SQL parser determine the field names here since
		//complex parsing may be involved to parse functions such as 
		//TO_DATE('DD-MM-YYYY', field_name) to a single field name
		fields.push_back(string((char *)szColName));
	}

	return variant_row_fields(vtt, fields);

}

// compare the contents of the pointers of the type specified by CTypeStr
// if (*pMember1 < *pMember2)
//	 return -1;
// else if (*pMember1 == *pMember2)
//   return 0;
// else if (*pMember1 > *pMember2)
//	 return 1;

int GenericCmp(void *pMember1, void *pMember2, int typeId)
{
		// types supported: short, unsigned short, int, unsigned int,
		// long, unsigned long, double, float, struct TIMESTAMP_STRUCT,
		// char *, string

	switch(typeId) {
	case C_SHORT: {
			short *pShort1 = (short *) pMember1;
			short *pShort2 = (short *) pMember2;
					
			if (*pShort1 < *pShort2)
				return -1;
			else
				return (*pShort2 < *pShort1);
		}

	case C_USHORT: {
			unsigned short *pUShort1 =
				(unsigned short *) pMember1;
			unsigned short *pUShort2 =
				(unsigned short *) pMember2;

			if (*pUShort1 < *pUShort2)
				return -1;
			else
				return (*pUShort2 < *pUShort1);
		}

	case C_INT: {
			int *pInt1 = (int *) pMember1;
			int *pInt2 = (int *) pMember2;
					
			if (*pInt1 < *pInt2)
				return -1;
			else
				return (*pInt2 < *pInt1);
		}

	case C_UINT: {
			unsigned int *pUInt1 = (unsigned int *) pMember1;
			unsigned int *pUInt2 = (unsigned int *) pMember2;
					
			if (*pUInt1 < *pUInt2)
				return -1;
			else
				return (*pUInt2 < *pUInt1);
		}

	case C_LONG: {
			long *pLong1 = (long *) pMember1;
			long *pLong2 = (long *) pMember2;
					
			if (*pLong1 < *pLong2)
				return -1;
			else
				return (*pLong2 < *pLong1);
		}

	case C_ULONG: {
			unsigned long *pULong1 = (unsigned long *) pMember1;
			unsigned long *pULong2 = (unsigned long *) pMember2;
					
			if (*pULong1 < *pULong2)
				return -1;
			else
				return (*pULong2 < *pULong1);
		}

	case C_DOUBLE: {
			double *pDouble1 = (double *) pMember1;
			double *pDouble2 = (double *) pMember2;
			const double epsilon = 1 >> 20; // 1/1048576
							
			if (*pDouble1 < *pDouble2 - (fabs(*pDouble1)+fabs(*pDouble2))*epsilon)
				return -1;
			else
				return (*pDouble2 < *pDouble1 - (fabs(*pDouble1)+fabs(*pDouble2))*epsilon);
		}

	case C_FLOAT: {
			float *pFloat1 = (float *) pMember1;
			float *pFloat2 = (float *) pMember2;
			const double epsilon = 1 >> 20; // 1/1048576

							
			if (*pFloat1 < *pFloat2 - (fabs(*pFloat1)+fabs(*pFloat2))*epsilon)
				return -1;
			else
				return (*pFloat2 < *pFloat1 - (fabs(*pFloat1)+fabs(*pFloat2))*epsilon);
		}

	case C_TIMESTAMP: {
			struct tagTIMESTAMP_STRUCT *pTS1 =
				(struct tagTIMESTAMP_STRUCT *) pMember1;
			struct tagTIMESTAMP_STRUCT *pTS2 = 
				(struct tagTIMESTAMP_STRUCT *) pMember2;
			
			return TSCmp(*pTS1, *pTS2);
		}

	case C_CHAR_STAR: {
			char **pCStr1 = (char **) pMember1;
			char **pCStr2 = (char **) pMember2;
							
			return strcmp(*pCStr1, *pCStr2);
		}

	case C_STRING: {
			string *pStr1 = (string *) pMember1;
			string *pStr2 = (string *) pMember2;
						
			return pStr1->compare(*pStr2);
		}
		
	case C_JTIME_C: {
			jtime_c *pTS1 =
				(jtime_c *) pMember1;
			jtime_c *pTS2 = 
				(jtime_c *) pMember2;
						
			if (*pTS1 < *pTS2)
				return -1;
			else
				return (*pTS2 < *pTS1);
		}
	
	default:
			throw ETIException("GenericCmp()", "Unable to compare objects of this type!");
	}
}

END_DTL_NAMESPACE
