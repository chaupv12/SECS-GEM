/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// DBIndexes are used to allow the user to key off of fields in the database
// through the classes he defines
// Initial: 10/4/2000 - MG
// Revised: 11/12/2000 - CJ - upgraded IndexFields to contain only key fields
// Edited: 12/19/2000 - MG - added namespaces

#include "std_inc.h"
#include "DB_Base.h"
#include "DBView.h"
#include "BoundIO.h"
#include "DBException.h"
#include "Callback.h"

#ifndef _DB_INDEX_H
#define _DB_INDEX_H

BEGIN_DTL_NAMESPACE

// used to allow the user to key off of fields in the database through the classes he defines
template<typename View> class DBIndex
{
   public:

	   typedef typename View::DataObject DataObj;
	   typedef typename View::ParamObject ParamObj;
	   typedef BCAWrap<DataObj> BCA;
	   typedef BPAWrap<ParamObj> BPA;

       // is the index unique or not
       enum Uniqueness { NONUNIQUE_INDEX = 0, UNIQUE_INDEX = 1 };   

   private:


	   // prohibit assignment?
	   DBIndex<View> &operator=(const DBIndex<View> &idx);

	   View *pDBview;						  // referenced view???

	   BCA bca;

	   BoundIOs IndexFields;				  // the parts of the key are stored as BoundIOs

	   vector<string> orderOfFields;		  // which fields to compare on first, second, etc.

	   DataObj rowbuf;					      // used for filling IndexFields with rel. addr.

	   Uniqueness uniqueKey;				  // is this index unique or not

	   typedef CBFunctor2wRet<const DataObj *, const DataObj *, bool> Compare;


	   // less than function to sort keys ... required for multiset<DataObj *, lt>
	   bool lt(const DataObj *key1, const DataObj *key2)
	   {
		   // At this point, IndexFields should contain only the BoundIOs in the index
		   for (BoundIOs::iterator b_it = IndexFields.begin();
					b_it != IndexFields.end(); b_it++)
			{
				BoundIO &b = (*b_it).second;
				int result = b.Compare(key1, key2);

				if (result != 0)
					return (result < 0);
				
				// these two fields is equal if we get here
				// so continue to next field
			}

			// all fields equal if we get here, return false
			return false;
	   }

	   // used for equality ... would be used in something like hash_multiset<DataObj *, eq>
	   bool eq(const DataObj *key1, const DataObj *key2)
	   {
		  return (!lt(key1, key2) && !lt(key2, key1));
	   }

     
	   multiset<DataObj *, Compare> index_data;    // refers to the data in the underlying view
										      // based on the point of view of the indices
   public:
	   // note that as multiset::iterator is a constant bidirectional iterator, so is
	   // DBIndex::iterator
	   typedef typename multiset<DataObj *, Compare>::iterator const_iterator;
	   typedef const_iterator iterator;

   public:
	   DBIndex() : pDBview(NULL), IndexFields(BoundIO::BIND_AS_INDICES), 
		   bca(DefaultBCA<DataObj>()),
		   orderOfFields(), rowbuf(), index_data(), uniqueKey(NONUNIQUE_INDEX) { }

	   // copy constructor must take care to bind functor to this object
	   DBIndex(const DBIndex<View> &idx) : pDBview(idx.pDBview),
		   IndexFields(BoundIO::BIND_AS_INDICES), rowbuf(idx.rowbuf), orderOfFields(idx.orderOfFields),
		   bca(idx.bca), uniqueKey(idx.uniqueKey)
	   {
		   // this is the whole reason why we need our own copy constructor
		   // to bind the functor to this object
		   index_data = 
			   multiset<DataObj *, Compare>(makeFunctor((Compare *) 0,
					*this, &DBIndex::lt));

		   // record base address of rowbuf so we can compute offsets when the bca is called
		   IndexFields.BindAsBase(rowbuf);
		   
		   bca(IndexFields, rowbuf); // generate relative addresses and RTTI for this index

		   BoundIOs tmp(ExtractKey());
		   IndexFields.swap(tmp);
		   IndexFields.BindAsBase(rowbuf);

		   // now must copy over the multiset
		   // should be inexpensive as we're just inserting pointers
           for (multiset<DataObj *, Compare>::const_iterator it = idx.index_data.begin();
		         it != idx.index_data.end(); it++)
			{
				index_data.insert(*it);

			}


	   }

	   // orderOfFields must take on the order specified in fieldNames
	   DBIndex(const string &fieldNames, const View &view,
		   Uniqueness isUnique) : pDBview(NULL), rowbuf(),
		   IndexFields(BoundIO::BIND_AS_INDICES), bca(view.GetBCA()), orderOfFields(ParseCommaDelimitedList(fieldNames)),
		   uniqueKey(isUnique)
	   {
	
		    View &view_ref = const_cast<View &>(view);
			pDBview = &view_ref;

		    index_data = 
				multiset<DataObj *, Compare>(makeFunctor((Compare *) 0, 
					*this, &DBIndex::lt));

		    // record base address of rowbuf so we can compute offsets when the bca is called
		    IndexFields.BindAsBase(rowbuf);

		    bca(IndexFields, rowbuf);   // generate relative addresses and RTTI for this index

			if (orderOfFields.empty())
				throw DBException("DBIndex::DBIndex()", "Invalid FieldList \"" +
					fieldNames + "\"!  FieldList is empty!", NULL, NULL);

			set<string> processedFieldNames;
			set<string> colNames = pDBview->GetColNames();

			for (vector<string>::iterator it = orderOfFields.begin(); it != orderOfFields.end(); it++)
			{
				string fieldName = *it;

				if (fieldName.length() == 0)
					throw DBException("DBIndex::DBIndex()", "Invalid FieldList \"" +
					  fieldNames + "\"!  Field \"" + fieldName + "\" is an empty name!",
					  NULL, NULL);

				// field name must refer to an existing column in the view
				// if it's not found, throw an exception
				if (colNames.find(fieldName) == colNames.end())
					throw DBException("DBIndex::DBIndex()", "Invalid FieldList \"" +
					   fieldNames + "\"!  Field \"" + fieldName + "\" does not exist in "
					   "view for tables \"" + MakeDelimitedList(pDBview->GetTableNames()) +
					   "\"!", NULL, NULL);

                // check to see if this fieldName has been processed
				// if so, this is a duplicate and throw an exception
				// otherwise record it
				pair<set<string>::iterator, bool> pr = processedFieldNames.insert(fieldName);

				if (!(pr.second))
					throw DBException("DBIndex::DBIndex()", "Invalid FieldList \"" +
					  fieldNames + "\"!  Field \"" + fieldName + "\" redefined!",
					  NULL, NULL);
			}

			BoundIOs tmp(ExtractKey());
			IndexFields.swap(tmp);
			IndexFields.BindAsBase(rowbuf);
	   }

	   // exception-safe swap()
	   void swap(DBIndex<View> &other)
	   {
		   bca.swap(other.bca);
		   index_data.swap(other.index_data);
		   IndexFields.swap(other.IndexFields);
		   orderOfFields.swap(other.orderOfFields);
		   std::swap(pDBview, other.pDBview);
		   std::swap(rowbuf, other.rowbuf);
		   std::swap(uniqueKey, other.uniqueKey);
	   }

	   // extract BoundIOs representing the key from the complete list of BoundIO's
	   BoundIOs ExtractKey()
	   {
		   // BoundIOs boundIOs(IndexFields);
		   BoundIOs boundIOs;

		   boundIOs.clear();

		   // the key fields are listed in orderOfFields
		   // so iterate over those column names and copy them over as BoundIO objects
		   for (vector<string>::iterator field_it = orderOfFields.begin(); field_it != orderOfFields.end(); field_it++)
		   {
			   BoundIOs::iterator b_it = IndexFields.find(*field_it);

			   if (b_it == IndexFields.end())
			   {
					throw DBException("DBIndex::ExtractKey()",
						"Unable to find index field's BoundIO \"" + *field_it 
						+ "\" in IndexFields!", NULL, NULL);
			   }

			   boundIOs[*field_it] = (*b_it).second;		   
		   }
		   return boundIOs;
	   }


	   // see if inserting dataObj into index keeps the index
	   // satisfying uniqueness constraints
	   pair<iterator, bool> CheckUniqueness(const DataObj &dataObj)
	   {
			if (IsUnique())
			{
				iterator find_it = find(dataObj);

				// if element found, uniqueness check fails
				// return iterator to existing element and false
				// and return pair(find_it, false)
				if (find_it != end())
				{
					   return pair<iterator, bool>(find_it, false);
				}
			}

			// element is not unique or uniqueness test succeeded means return success!
			return pair<iterator, bool>(end(), true);
	   }

	   iterator begin()
	   {
		  return index_data.begin();
	   }


	   iterator end()
	   {
		  return index_data.end();
	   }

	   const_iterator begin() const
	   {
		  return index_data.begin();
	   }

	   const_iterator end() const
	   {
		  return index_data.end();		   
	   }

	   size_t size() const
	   {
		  return index_data.size();
	   }

	   size_t max_size() const
	   {
		  return index_data.max_size();
	   }

	   bool empty() const
	   {
		  return index_data.empty();
	   }

	   // comparison operators
	   friend bool operator==(const DBIndex<View> &idx1,
							  const DBIndex<View> &idx2)
	   {
		  return idx1.index_data == idx2.index_data;
	   }

	   friend bool operator!=(const DBIndex<View> &idx1,
							  const DBIndex<View> &idx2)
	   {
		  return !(idx1 == idx2);
	   }
	   
	   friend bool operator<(const DBIndex<View> &idx1,
							 const DBIndex<View> &idx2)
	   {
		  return idx1.index_data < idx2.index_data;

	   }

	   friend bool operator>(const DBIndex<View> &idx1,
							 const DBIndex<View> &idx2)
	   {
		  return idx1.index_data > idx2.index_data;
	   }

	   friend bool operator<=(const DBIndex<View> &idx1,
							  const DBIndex<View> &idx2)
	   {
		  return idx1.index_data <= idx2.index_data;
	   }

	   friend bool operator>=(const DBIndex<View> &idx1,
							  const DBIndex<View> &idx2)
	   {
		  return idx1.index_data >= idx2.index_data;
	   }

	   // insert the DataObj (actually its address) into the indexed data
	   // exception safe - atomic and consistent - only one mutating operation
	   iterator insert(const DataObj &data)
	   {
		    DataObj &dataRef = (DataObj &) data;
		    DataObj *const pData = (DataObj *const) &dataRef;
		    return index_data.insert(pData);
	   }

	   // return an iterator to an element based on its address
	   // (calling find() would do a search based on value rather than the address passed in)
	   // the element will appear once in the list
	   iterator find_by_addr(const DataObj &data)
	   {
		    DataObj &dataRef = (DataObj &) data;
			DataObj *const pData = (DataObj *const) &dataRef;
			
			// we should be able to just say: index_data.find(pData);
			// however, that statement would find all elements which have the identical
			// key value based on lt(), not the same pointer

			// the element is guaranteed to be in the range returned by equal_range()
			// as the method will find all elements which have the same key as *pData

			pair<iterator, iterator> pr = equal_range(*pData);

			// now we just need to find which element has the same address as *pData
			for (iterator find_it = pr.first; find_it != pr.second; find_it++)
			{
				// if addresses match, this is the element to return from the list
				if (pData == *find_it)  // *find_it returns a DataObj *
				{
					return find_it;
				}
			} 

			// in the odd event the element is not found, return end()
			return end();
	   }			

	   // erase the DataObj (actually its address) from the indexed data
	   // (note this differs from the standard form of erase() which
	   // removes all elements with the value passed in)

	   // exception safe - atomic and consistent - only one mutating operation
	   // overall
	   void erase(const DataObj &data)
	   {
		    DataObj &dataRef = (DataObj &) data;
			DataObj *const pData = (DataObj *const) &dataRef;
			
			// we should be able to just say: index_data.erase(pData);
			// however, that statement would erase all elements which have the identical
			// key value based on lt(), not the same pointer

			// the element is guaranteed to be in the range returned by equal_range()
			// as the method will find all elements which have the same key as *pData
			pair<iterator, iterator> pr = equal_range(*pData);

			// now we just need to find which element has the same address as *pData
			for (iterator find_it = pr.first; find_it != pr.second; find_it++)
			{
				// if addresses match, this is the element to remove from the list
				if (pData == *find_it)  // *find_it returns a DataObj *
				{
					index_data.erase(find_it);
					break;
				}
			} 
	   }


   // ------------- equal_range methods ------------------------------------

     // return an iterator to objects that have the given value
	   // based on a key composed of a single field
	   template<class DataField> pair<iterator, iterator> equal_range(const DataField &df)
	   {

	   	// it's an error if we use this function on a key that has more than one field
		    if (orderOfFields.size() != 1)
		  	{
			  	ostrstream errstr;

			  	errstr << "Expected one key field in index!  Instead found " <<
						orderOfFields.size() << "!" << ends;
			  	throw DBException("DBIndex::equal_range(const DataField &df)",
				  	errstr.str(), NULL, NULL);
		 	 	}

		  	// copy field df to key via BoundIO's ... we want orderOfFields[0]
		  	BoundIO &boundIO = IndexFields[orderOfFields[0]];

		  	boundIO.CopyMember(rowbuf, df);

		  	return equal_range(rowbuf);
	   }


	   // return an iterator to objects that have the given key
	  pair<iterator, iterator> equal_range (const DataObj &key)
	   {
		    DataObj &keyRef = (DataObj &) key;
			  return index_data.equal_range(&keyRef);
	   }


     // ------------- find methods ------------------------------------

     // return an iterator to object that has the given value
	   // based on a key composed of a single field
	   template<class DataField> iterator find(const DataField &df)
	   {

		  // it's an error if we use this function on a key that has more than one field
		  if (orderOfFields.size() != 1)
		  {
			  ostrstream errstr;

			  errstr << "Expected one key field in index!  Instead found " <<
					orderOfFields.size() << "!" << ends;
			  throw DBException("DBIndex::find(const DataField &df)",
				  errstr.str(), NULL, NULL);
		  }

		  // DataObj key;

		  // copy field df to key via BoundIO's ... we want orderOfFields[0]
		  BoundIO &boundIO = IndexFields[orderOfFields[0]];

		  boundIO.CopyMember(rowbuf, df);

		  return find(rowbuf);
	   }
	
	   // return an iterator to object that has the given key
	   iterator find(const DataObj &key)
	   {
		    DataObj &keyRef = (DataObj &) key;
			return index_data.find(&keyRef);
	   }


	   // same as the single DataField version, but based on two key fields
	   template<class DataField1, class DataField2> pair<iterator, iterator>
		   equal_range(const DataField1 &df1, const DataField2 &df2)
	   {
		  // it's an error if we use this function on a key that has less than or
		  // more than two fields
		  if (orderOfFields.size() != 2)
		  {
			  ostrstream errstr;

			  errstr << "Expected two key fields in index!  Instead found " <<
					orderOfFields.size() << "!" << ends;
			  throw DBException("DBIndex::equal_range(const DataField &df)",
				  errstr.str(), NULL, NULL);
		  }

		  // copy fields df1 and df2 via BoundIO's ... we want to match off of
		  // orderOfFields[0] and orderOfFields[1]
		  BoundIO &df1_boundIO = IndexFields[orderOfFields[0]];
		  df1_boundIO.CopyMember(rowbuf, df1);

		  BoundIO &df2_boundIO = IndexFields[orderOfFields[1]];
		  df2_boundIO.CopyMember(rowbuf, df2);

		  return equal_range(rowbuf);
	   }

	   // same as the single DataField version, but based on two key fields
	   template<class DataField1, class DataField2> iterator
		  find(const DataField1 &df1, const DataField2 &df2)
	   {
		  // it's an error if we use this function on a key that has less than or
		  // more than two fields
		  if (orderOfFields.size() != 2)
		  {
			  ostrstream errstr;

			  errstr << "Expected two key fields in index!  Instead found " <<
					orderOfFields.size() << "!" << ends;
			  throw DBException("DBIndex::find(const DataField &df)",
				  errstr.str(), NULL, NULL);
		  }

		  // need to copy construct DataObj?
		  // DataObj key;

		  // copy fields df1 and df2 via BoundIO's ... we want to match off of
		  // orderOfFields[0] and orderOfFields[1]
		  BoundIO &df1_boundIO = IndexFields[orderOfFields[0]];
		  df1_boundIO.CopyMember(rowbuf, df1);

		  BoundIO &df2_boundIO = IndexFields[orderOfFields[1]];
		  df2_boundIO.CopyMember(rowbuf, df2);

		  return find(rowbuf);
	   }


	   // return whether the key is unique or not
	   bool IsUnique()
	   {
		  return uniqueKey == UNIQUE_INDEX;
	   }

	   BoundIOs &GetIndexFields()
	   {
		  return IndexFields;
	   }

#ifdef DATAOBJ_PRINTABLE
	   // debugging operator<<() .., DataObj must have an operator<<()
	   friend ostream &operator<<(ostream &o, const DBIndex<View> &idx)
	   {
		   DBIndex<View>::const_iterator it;
			
			for (it = idx.begin(); it != idx.end(); it++)
			{
			   o << **it << endl;
			}

			o << "DBIndex.size() = " << idx.size() << endl;
			return o;
	   }
#endif
};

// compare the contents of the pointers of the type specified by CTypeStr
// if (*pMember1 < *pMember2)
//	 return -1;
// else if (*pMember1 == *pMember2)
//   return 0;
// else if (*pMember1 > *pMember2)
//	 return 1;
int GenericCmp(void *pMember1, void *pMember2, string CTypeStr);



END_DTL_NAMESPACE

#endif
