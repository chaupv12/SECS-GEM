/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
#include "BoundIO.h"

// Reviewed: 11/12/2000 - CJ
// Edited: 12/19/2000 - MG - added namespaces

BEGIN_DTL_NAMESPACE

//We need STRBUFLEN to be 255 at most, otherwise Access97 will give error 
//"Invalid precision or scale value" since 255 is the largest length text 
//field it allows. See SQLBindParam() for details
const size_t BoundIO::STRBUFLEN = 255;  
const int BoundIO::DATE_PRECISION = 16;

extern ETI_Map SQL_types_to_C;

// get the actual pointer we need to bind to
void *BoundIO::GetRawPtr() const
{
		// use like a case statement
		// add other types that need special handling here
		if (IsPrimitive)
			return addr;   // can use object address directly for primitives
		else
			return const_cast<char *>(strbuf.get()); // address of buffer for complex types
}

// get size of raw buffer
SDWORD BoundIO::GetRawSize() const
{
		// use like a case statement
		// add other types that need special handling here
	
		if (IsPrimitive)
			return size;    // use bound object directly for primitives
		else	
			return strbuf.size();	// use strbuf size for complex types
}

// get value for precision
SDWORD BoundIO::GetPrecision() const
{
	 // use like a case statement
	 // add other types that need special handling here

	 if (typeId == C_TIMESTAMP || typeId == C_JTIME_C)
		return DATE_PRECISION;
	 return 0;
}

END_DTL_NAMESPACE
