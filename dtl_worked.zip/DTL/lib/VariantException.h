#ifndef _VARIANT_EXCEPTION_H
#define _VARIANT_EXCEPTION_H

#include "DB_Base.h"
#include "RootException.h"

BEGIN_DTL_NAMESPACE

// exception class when something goes wrong in Variants
class VariantException : public RootException
{
public:
	VariantException(const string &meth, const string &msg) :
	  RootException(meth, msg, "VariantException") { }

	// superclass behavior ok for what()
};

END_DTL_NAMESPACE

#endif
