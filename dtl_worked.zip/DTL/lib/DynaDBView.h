/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// Code to bind a dynamic row
// Initial: 11/18/2000 - CJ
// Edited: 12/19/2000 - MG - added namespaces

#ifndef _DYNADBVIEW_H
#define _DYNADBVIEW_H

#include "std_inc.h"
#include "DB_Base.h"
#include "BoundIO.h"
#include "DBDefaults.h"
#include "DBView.h"
#include "select_iterator.h"
#include "insert_iterator.h"
#include "update_iterator.h"
#include "delete_iterator.h"
#include "IndexedDBView.h"
#include "variant_row.h"

BEGIN_DTL_NAMESPACE

variant_row_fields GetFieldInfo(const string &TableName, const string &TableFields, DBConnection &conn);

#if 0
class variant_row_fields {
public:
	vector<TypeTranslation> types;
	vector<string> names;
	vector<size_t> offsets;
	size_t row_size;
}
#endif

class DynamicRowBCA
{
  private:
	  variant_row_fields fields;
  public:
	  DynamicRowBCA() : fields() { }
	  DynamicRowBCA(const variant_row_fields &f) : fields(f) {}

	  // should be exception-safe as synthesized copy constructor used for fields
	  DynamicRowBCA(const DynamicRowBCA &bca) :
		fields(bca.fields) { }

	  // exception-safe swap()
	  void swap(DynamicRowBCA &other)
	  {
		fields.swap(other.fields);
	  }

	  // exception-safe assignment
	  DynamicRowBCA &operator=(const DynamicRowBCA &other)
	  {
		  if (this != &other)
		  {
			 DynamicRowBCA temp(other);
			 swap(temp);
		  }

		  return *this;
	  }

	  // bca applied here
	  void operator()(BoundIOs &boundIOs, variant_row &rowbuf)
	  {
		  // initialize progenitor row class
		  // all other rows must be assign constructed or copy constructed from this row
		  // to have the correct size & types
		  variant_row row(fields.types, fields.names);
		  rowbuf = row;
		 
		  boundIOs.clear();
		  boundIOs.BindAsBase(rowbuf.p_data, fields.row_size, typeid(rowbuf).name());

	
		  // create boundIOs with full data
		  for (vector<string>::iterator i = fields.names.begin(); i != fields.names.end(); i++)
		  {
				int idx = i - fields.names.begin();
			    // Create full boundIO versus rowbuf
			    BoundIO boundIO(boundIOs, *i, fields.types[idx], rowbuf.p_data + fields.offsets[idx], rowbuf.p_data, fields.row_size);
				boundIO.SetAsVariantRow();
				pair<BoundIOs::iterator, bool> pr = 
					boundIOs.insert(pair<const string, BoundIO>(*i, boundIO));  // do not use make_pair here - required for STLport
				if (!pr.second)
					throw DBException("DynamicRowBCA:operator()()", "In attempting to tack on "
					+ string("to BoundIOs, BoundIO \"") + *i + " exists!", NULL, NULL);
		  }
			
	  }
};

// select default behavior ... record null columns in rowbuf
// if there are other checks you wish to make, put them in
// your own SelValidate function (of type DBView<DataObj, ParamObj>::SelVal)
// This function is specialized version of DefaultSelValidate to copy 
// information about NULL columns to the variant_row class
template<> class DefaultSelValidate<variant_row> {
public:
	bool operator()(BoundIOs &boundIOs, variant_row &rowbuf)
	{
		for (BoundIOs::iterator b_it = boundIOs.begin();
				b_it != boundIOs.end(); b_it++)
		{
			BoundIO &boundIO = (*b_it).second;
			if (boundIO.IsColumn() && boundIO.IsNull())
				rowbuf.SetAsNull(boundIO.GetName()); // found null column ... record null status in rowbuf 
		}

		return true;	// assume data is OK
	}
};


template<class ParamObj = DefaultParamObj<variant_row> >
class DynamicDBView : public DBView<variant_row, ParamObj> {
public:
	typedef BPAWrap<ParamObj> BPA;
	typedef typename DBView<variant_row, ParamObj>::InsVal InsVal;
	typedef typename DBView<variant_row, ParamObj>::SelVal SelVal;

	DynamicDBView(const string tableList, const string fieldList,
		const string postfix = "",	const BPA bpa_fn = DefaultBPA<ParamObj>(),
		const SelVal sel_val = DefaultSelValidate<variant_row>(),
		const InsVal ins_val = DefaultInsValidate<variant_row>(),
		DBConnection &connection = DBConnection::GetDefaultConnection()) :
		DBView<variant_row, ParamObj>(tableList, 
			DynamicRowBCA(GetFieldInfo(tableList, fieldList, connection)),
			postfix, bpa_fn, sel_val, ins_val, connection)
		{}

	// return a variant_row initialized by the BCA as a prototype	
	variant_row DataObj() const {
		variant_row dummy_obj;
		BoundIOs dummy_bc(BoundIO::BIND_ADDRESSES);
		dummy_bc.BindAsBase(dummy_obj);
		DynamicDBView *mutable_this = const_cast<DynamicDBView *>(this);
		//conceptually const - tho in practice bca may be initialized here
		mutable_this->bca(dummy_bc, dummy_obj);
		return dummy_obj;
	}


	// exception-safe swap()
	void swap(DynamicDBView<variant_row> &other)
	{

		DBView<variant_row, ParamObj>::swap(other);
	}

	// exception-safe assignment
	DynamicDBView<variant_row> &
		operator=(const DynamicDBView<variant_row> &other)
	{
		if (this != &other)
		{
		   DynamicDBView<variant_row> temp(other);
		   swap(temp);
		}

		return *this;
	}
};


template<class DynamicView> class DynamicIndexedDBView : public IndexedDBView<DynamicView>
{
private:
    // given a DynamicView, build the IndexNamesAndFields string for the
	// indexed view
	// this function constructs a general nonunique key composed of all fields
	// from the view
	static string BuildNamesAndFieldsStr(const DynamicView &view)
	{
	   string result;

	   result += "PrimaryKey; "; // generate key name
	   result += MakeDelimitedList(view.GetColNames()); // tack on column names

	   return result;
	}

	typedef typename DynamicView::ParamObject ParamObj;
public:
	DynamicIndexedDBView(const DynamicView &view, const string IndexNamesAndFields = "",
		  BoundMode bm = UNBOUND, KeyMode km = USE_ALL_FIELDS, 
		  SetParamsFn SetPar = DefaultSetParams<ParamObj>())  :

		IndexedDBView<DynamicView>(view, 
			(IndexNamesAndFields == "" ? BuildNamesAndFieldsStr(view) :
										 IndexNamesAndFields), bm, km, SetPar) 
		{}


    // exception-safe swap()
	void swap(DynamicIndexedDBView<DynamicView> &other)
	{
		IndexedDBView<DynamicView>::swap(other);
	}

	// exception-safe assignment
	DynamicIndexedDBView<DynamicView> &
		operator=(const DynamicIndexedDBView<DynamicView> &other)
	{
		if (this != &other)
		{
			DynamicIndexedDBView<DynamicView> temp(other);
			swap(temp);
		}
	}

	variant_row DataObj() const {return pDBview->DataObj();}

};

END_DTL_NAMESPACE
#endif
