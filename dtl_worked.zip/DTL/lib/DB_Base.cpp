// initialization of statics from DB_Base

#include "DB_Base.h"

BEGIN_DTL_NAMESPACE

const dtl_iostate dtl_ios_base::goodbit = dtl_iostate::goodbit;
const dtl_iostate dtl_ios_base::failbit = dtl_iostate::failbit;
const dtl_iostate dtl_ios_base::badbit  = dtl_iostate::badbit;

END_DTL_NAMESPACE
