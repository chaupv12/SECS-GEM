// iterator used for SELECTS
// nested class of DBView
// Initial: 9/8/2000 - MG
/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// Edited: 12/19/2000 - MG - added namespaces

#ifndef _SELECT_ITERATOR_H
#define _SELECT_ITERATOR_H

#include "std_inc.h"
#include "DBView.h"
#include "select_insert_iterator.h"

BEGIN_DTL_NAMESPACE

// iterator used for SELECTS
template<class DataObj, class ParamObj = DefaultParamObj<DataObj> >
  class DB_select_iterator :
	public DB_select_insert_iterator<DataObj, ParamObj>,
#ifndef __SGI_STL_PORT
	public iterator<input_iterator_tag, DataObj, ptrdiff_t>
#else
	 // not sure why STLport not recognizing the standard iterator tag
	 // when used in algorithms like copy(_InputIter __first, _InputIter __last, _OutputIter __result)
	 // use STLport specific alternative
	 public input_iterator<DataObj, ptrdiff_t>
#endif
{
public:
	// is this a dummy iterator representing view.begin() or view.end()???
    enum DummyFlag { NOT_DUMMY = 0, DUMMY = 1 };

    // action specifying how to initialize dummy values for view.begin() and view.end()
    enum DummyAction { DUMMY_BEGIN = 0, DUMMY_END = 1 };

private:
	bool begin; // are we at the beginning of the recordset?
	bool end;    // are we at the end of the recordset?
	bool empty; // is recordset empty?

	DummyFlag isDummy; // was this iterator set as a dummy for view.begin() and view.end()?

	SelValWrap<DataObj> SelValidate;


	// called from catch blocks to fetch rows until errors are handled
	// returns the action that should be taken by the caller
	dtl_ios_base::MeansOfRecovery FetchNextRowUntilHandled(RootException &ex)
	{
		  dtl_ios_base::MeansOfRecovery error_action;

		  error_action = io_handler(ex, *this, *(pRowbuf.get()), *pParambuf);

		  // if we wish to reperform the operation, keep trying to fetch rows
		  // until successful or otherwise directed by the handler
		  while (error_action == dtl_ios_base::SUPPRESS_ERROR && !bad())
		  {
			// think of this as a 3rd condition &&'ed with the other two
			// we want to break out of the loop if at the end of the view
			// must perform it here otherwise operator!=() might
			// throw with an uncaught exception
			if (*this == pDBview->end())
				break;

	        try
			{
				FetchNextRow();
			}
			catch (RootException &ex1)
			{
				error_action = io_handler(ex1, *this, *(pRowbuf.get()), *pParambuf);

				// if the handler tells us to throw on a retry,
				// then we will rethrow the original exception???
				if (error_action == dtl_ios_base::THROW_EXCEPTION)
					throw;
			}

		  }

		  // the only action we need to take here is to throw
		  // if the handler said to
		  return error_action;
	}

	// version of FetchFirstRow() that will grab the first row of the recordset
	// but with proper error handling using IOHandlers
    void FetchFirstRowUntilHandled()
	{
	    // try to fetch first row ... if fail, apply the handler and
		// keep trying rows until succeed (if applicable)

		// try to fetch first row
		// if failed, then try to read more rows if the handler says to
		try
		{
			if (bad())
				throw DBException("DBView::select_iterator::FetchFirstRowUntilHandled()",
					"iterator tested bad!", NULL, NULL);

			FetchFirstRow();
		}
		catch (RootException &ex)
		{
		  // fetch next rows until the exception (and any others triggered are cleared)
		  dtl_ios_base::MeansOfRecovery handled = FetchNextRowUntilHandled(ex);
		  
		  // rethrow original exception if it wasn't handled above
		  if (handled == dtl_ios_base::THROW_EXCEPTION)
			  throw;
		}
	}

	// fetch first row of recordset
	// exception-safety questionable
	void FetchFirstRow()
	{
		if (bad())
		{
			end = true; // set iterator to end of view
			
		    // error handler call in caller will determine how to handle the exception
			throw DBException("DBView::select_iterator::FetchFirstRow()",
				"iterator tested bad!", NULL, NULL);
		}

		// propagate postfix parameters to their strbufs
		// before we execute!

		try
		{
			boundIOs.PropagateToSQL(true);
		}
		catch (...)
		{
			if (stmt.valid())
				setstate(failbit);
			else
			{
				end = true;
				setstate(badbit);
			}

			throw;
		}

		try
		{
			stmt.Execute();
		}
		catch (...)
		{
			setstate(badbit);
			end = true;
			throw;
		}

		begin = true;
		empty = false;

		DBStmt::FetchStatus fetch_rc = stmt.Fetch();  // should fetch into rowbuf

		if (fetch_rc == DBStmt::NO_DATA_FETCHED)
		{
			// at end of recordset
			end = true;
			empty = true;
			clear();
		}
		else if (fetch_rc == DBStmt::ROW_FETCHED)
		{
			// first record fetched

			// must propagate results back
			// to the bound objects
			
			// iterate through BoundIOs and make any necessary propagations
			try
			{
				boundIOs.PropagateFromResults();
			}
			catch (...)
			{
			    if (stmt.valid())
				   setstate(failbit);
			    else
				{
				   end = true;
				   setstate(badbit);
				}

				throw;
			}

			count++;
			lastCount++;
			clear();
		}
		else // stmt.Fetch() failed -- shouldn't get here as exception is thrown
			 // in DBStmt::Fetch()
		{
			end = true; // set iterator to view.end() to break infinite loops

			if (stmt.valid())
				setstate(failbit);
			else
				setstate(badbit);


			throw DBException("DBView::select_iterator::FetchFirstRow()",
					"Fetch failed on statement \"" + stmt.GetQuery() + "\"!", 
					&(stmt.GetConnection()), &stmt);
		}
	}


	// initialize the iterator
	// exception-safety depends on FetchFirstRow() and DB_iterator::open()
	virtual void open()
	{
		try
		{
			DB_select_insert_iterator<DataObj, ParamObj>::open();
		
		    // try to fetch first row ... if fail, apply the handler and
		    // keep trying rows until succeed (if applicable)
            FetchFirstRowUntilHandled();
		
		    isDummy = NOT_DUMMY;
		}
		
		catch (...)
		{
			setstate(badbit);
			end = true;
			throw;
		}

	}

	// close the iterator
	virtual void close()
	{
	   	try
		{
			if (IsReady())
			{
		     stmt.Reset();
			}
		}
		catch (...)
		{
			setstate(badbit);
			end = true;
		}

		// only need to reset the count
		count = 0;
		lastCount = 0;

		// must grab the first row of the recordset so iterator points there
		FetchFirstRowUntilHandled();
	}

	// are we at the beginning or the end of the recordset?
	bool at_beginning() const { return begin; }
	bool at_end() const	      { return end || !(stmt.valid());    }

	// is recordset empty?
	bool is_empty() const     { return empty; }



	// fetches next row from database
	// exception-safety questionable
	void FetchNextRow()
	{
		if (bad())
		{
			end = true; // set iterator to end of view
			throw DBException("DBView::select_iterator::FetchFirstRow()",
				"iterator tested bad!", NULL, NULL);
		}

		if (!IsReady())
	        open();

		if (!at_end())  // don't try to advance the iterator if we know we're at the end of 
						// the recordset
		{	
		   // propagate STL strings to their strbufs for proper binding
		   boundIOs.PropagateToSQL(true);

		   DBStmt::FetchStatus fetch_rc = stmt.Fetch();  // should fill rowbuf
	     
		   // update begin, end flags  
		   if (fetch_rc == DBStmt::NO_DATA_FETCHED) // end of recordset
		   {
	          begin = false;  // no longer pointing to beginning of recordset
			  end = true;	  // now pointing at end
		   }
		   else if (fetch_rc == DBStmt::ROW_FETCHED) // row fetched
		   {
			  // propagate results back to bound STL strings
			  boundIOs.PropagateFromResults();

			  count++;
			  lastCount++;

			  begin = false;
		   }
		   else // stmt.Fetch() failed - shouldn't happen
				// as exception should be thrown in DBStmt::Fetch()
		   {
			 end = true; // set to view.end() to break infinite loops
			 throw DBException("DBView::select_iterator::FetchNextRow()",
							  "Fetch failed on statement \"" + stmt.GetQuery() +
							  "\"!", &(stmt.GetConnection()), &stmt);
		   }
		}

		clear();
	}

	static bool EqualCompare(const DB_select_iterator<DataObj, ParamObj> &i1,
		const DB_select_iterator<DataObj, ParamObj> &i2)
	{
		// need to bypass our logical constness to open() iterators if necessary
		DB_select_iterator<DataObj, ParamObj> &j1 =
			const_cast<DB_select_iterator<DataObj, ParamObj> &>(i1);

		DB_select_iterator<DataObj, ParamObj> &j2 =
			const_cast<DB_select_iterator<DataObj, ParamObj> &>(i2);

		// must catch exceptions here or comparisons will crash
		try
		{
		  if (!i1.IsReady() && !(i1.isDummy == DUMMY && i1.at_end()))
		     j1.open();
		}
		catch (RootException &ex)
		{
			dtl_ios_base::MeansOfRecovery error_action = 
				j1.io_handler(ex, j1, *(j1.pRowbuf.get()), *(j1.pParambuf));

			if (error_action == dtl_ios_base::THROW_EXCEPTION)
				throw;
		}

		try
		{
		  if (!i2.IsReady() && !(i2.isDummy == DUMMY && i2.at_end()))
		     j2.open();
		}
		catch (RootException &ex)
		{
			dtl_ios_base::MeansOfRecovery error_action = 
				j2.io_handler(ex, j2, *(j2.pRowbuf.get()), *(j2.pParambuf));

			if (error_action == dtl_ios_base::THROW_EXCEPTION)
				throw;			
		}

		bool same_view = (*(i1.pDBview) == *(i2.pDBview));
		bool at_same_place = (i1.at_beginning() && i2.at_beginning()  ||
				i1.at_end() && i2.at_end());
		bool same_ref = (i1.pRowbuf.get() == i2.pRowbuf.get());

		// if we are testing against end(), we need to add a special case if both
		// rowbuf pointers are NULL
		// otherwise, we'll terminate out of an iterator's loop improperly
		if (!i1.pRowbuf && !i2.pRowbuf)
		{
			if (!at_same_place)
				same_ref = false;
		}

		return (same_view && (at_same_place || same_ref));
	}

	// common code used by operator*() and operator->() to get pRowbuf properly
	// uses IOHandlers for proper error handling
	CountedPtr<DataObj> OperatorArrow() const
	{
		// variables used in try/catch
		CountedPtr<DataObj> pData = NULL;

		DB_select_iterator<DataObj, ParamObj> *this_ptr = 
			const_cast<DB_select_iterator<DataObj, ParamObj> *>(this);


		// handle errors that occur in try block using our IOHandler
		try
		{  
			if (bad())
			{	
			  this_ptr->end = true;
			  throw DBException("DBView::select_iterator::OperatorArrow()",
				"iterator tested bad!", NULL, NULL);
			}

			this_ptr = const_cast<DB_select_iterator<DataObj, ParamObj> *>(this);

		    pData = this_ptr->GetRowbufPtr(); 
				// pointer guaranteed to be non-NULL
		
		    
		   // if user specified a SelVal, apply it
		   if (!this_ptr->SelValidate(this_ptr->boundIOs, *pData))
		   {
			if (stmt.valid())
				this_ptr->setstate(failbit);
			else
			{
				this_ptr->end = true;
				this_ptr->setstate(badbit);
			}
			 
			throw DBException("DBView::select_iterator::operator*()",
							  "SelValidate() failed on statement \"" +
							  stmt.GetQuery() + "\"!", NULL, NULL);
		   }
			
		}
		catch (RootException &ex)
		{
//		  throw;

#if 1
		  // fetch next rows until the exception (and any others triggered are cleared)
		  dtl_ios_base::MeansOfRecovery handled = this_ptr->FetchNextRowUntilHandled(ex);
		  
		  // rethrow original exception if it wasn't handled above
		  if (handled == dtl_ios_base::THROW_EXCEPTION)
			  throw;
#endif
		}		

		return pRowbuf; // in the face of an exception:
						// we can get a bad object if we try to use pData as the
						// assignment doesn't complete
						// here we are guaranteed a default constructed DataObj
	}

public:
	DB_select_iterator() : DB_select_insert_iterator<DataObj, ParamObj>(),
		SelValidate(DefaultSelValidate<DataObj>()), begin(false), end(false), 
		empty(false), isDummy(NOT_DUMMY) { }

    DB_select_iterator(const DBView<DataObj, ParamObj> &view) : 
       DB_select_insert_iterator<DataObj, ParamObj>(view, SELECT), SelValidate(view.GetSelVal()),
		   begin(false), end(false), empty(false), isDummy(NOT_DUMMY)
       { }

	// copy constructor and assignment operator required for Assignable property
	DB_select_iterator(const DB_select_iterator &read_it) : 
	   DB_select_insert_iterator<DataObj, ParamObj>(read_it), 
	   SelValidate(read_it.SelValidate),
	   begin(read_it.begin), end(read_it.end), empty(read_it.empty), isDummy(read_it.isDummy)
       { }

	// exception-safe swap()
	void swap(DB_select_iterator<DataObj, ParamObj> &other)
	{
		DB_select_insert_iterator<DataObj, ParamObj>::swap(other);
		std::swap(begin, other.begin);
		std::swap(end, other.end);
		std::swap(empty, other.empty);
		std::swap(isDummy, other.isDummy);
		std::swap(SelValidate, other.SelValidate);
	}

	// exception-safe assignment
	DB_select_iterator<DataObj, ParamObj> &
		operator=(const DB_select_iterator<DataObj, ParamObj> &other)
	{
		if (this != &other)
		{
			DB_select_iterator<DataObj, ParamObj> temp(other);
			swap(temp);
		}

		return *this;
	}

	// forms of constructor that only should be used for begin and end iterators

	// dummy form that uses another select iterator to build this one
	DB_select_iterator(const DB_select_iterator &read_it, DummyAction dumAction) :
	   DB_select_insert_iterator<DataObj, ParamObj>(read_it), 
	   SelValidate(read_it.SelValidate),
	   begin(dumAction == DUMMY_BEGIN),
	   end(dumAction == DUMMY_END), empty(false),
	   isDummy(DUMMY)
       { }

	// dummy form that uses a view to build this iterator
	DB_select_iterator(const DBView<DataObj, ParamObj> &view, DummyAction dumAction) :
       DB_select_insert_iterator<DataObj, ParamObj>(view, SELECT),
	   SelValidate(view.GetSelVal()), begin(dumAction == DUMMY_BEGIN),
	   end(dumAction == DUMMY_END), empty(false), isDummy(DUMMY)
	   { }


	// return current record
	// DB_iterator::GetRowbufPtr() provides the necessary support to maintain
	// the following invariants as specified in the C++ standard for input iterators
	// exception-safety dependent on GetRowbufPtr(), SelValidate(),
	// and DataObj copy constructor
	const DataObj &operator*() const
	{
		return *OperatorArrow();
	}

	// overriding operator->() behavior to provide SelValidate() checks
	// exception-safety depends on GetRowbufPtr() and SelValidate()
	CountedPtr<DataObj> operator->() const
	{
		return OperatorArrow();
	}

	// advance to next record (preincrement)
	DB_select_iterator<DataObj, ParamObj> &operator++()
	{
      try
	  {
		FetchNextRow();
	  }
	  catch (RootException &ex)
	  {
		  // fetch next rows until the exception (and any others triggered are cleared)
		  dtl_ios_base::MeansOfRecovery handled = FetchNextRowUntilHandled(ex);
		  
		  // rethrow original exception if it wasn't handled above
		  if (handled == dtl_ios_base::THROW_EXCEPTION)
			  throw;
	  }

      return *this;
	}
	
	// advance to next record (postincrement)
    inline const DB_select_iterator<DataObj, ParamObj> operator++(int) // const return to prevent iterator++++
	{
       DB_select_iterator<DataObj, ParamObj> oldValue(*this);
	   ++(*this);
	   return oldValue;
	}



	// are the iterators pointing to the same place
	// only applies at begin and end of 
	// recordset
	bool operator==(const DB_select_iterator<DataObj, ParamObj> &i2)
	{
		return EqualCompare(*this, i2);
	}

	// are the iterators pointing to different records?
	// only meaningful if both iterators are at the start or end of the same recordset
	bool operator!=(const DB_select_iterator<DataObj, ParamObj> &i2)
	{
		return !(*this == i2);
	}

	// these DBView members need access to begin() and end()
	friend DB_select_iterator<DataObj, ParamObj>
		DBView<DataObj, ParamObj>::begin();
	friend DB_select_iterator<DataObj, ParamObj>
		DBView<DataObj, ParamObj>::end();

	virtual ~DB_select_iterator()
	{ }

};

END_DTL_NAMESPACE

#endif
