/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// root exception type for DBObjects
// Initial: 11/14/2000 - MG
// Edited: 12/19/2000 - MG - added namespaces

// derives from standard STL exception class
#ifndef _ROOT_EXCEPTION_H
#define _ROOT_EXCEPTION_H

#include "std_inc.h"

BEGIN_DTL_NAMESPACE

class RootException : public exception
{
public:
  const string method;
  const string errmsg;
  const string exType;

  mutable string whatbuf;	// buffer used to store result of what() operation
							// so it doesn't get destroyed on us

  RootException() : exception(), method(""), errmsg(""), exType("RootException"), whatbuf() { }

  RootException(const string &meth, const string &err,
	  const string &excType = "RootException") :
	exception(), method(meth), errmsg(err), exType(excType), whatbuf() { }

  friend ostream &operator<<(ostream &o, const RootException &ex)
  {
	 o << ex.what();
	 return o;
  }

  // override if you have additional members to print
  virtual const char *what() const throw()
  {
	 ostrstream errstr;
	 errstr << "Exception type: " << exType << endl;
	 errstr << "Method: " << method << endl;
	 errstr << "Error Message: " << errmsg << endl;
	 errstr << ends;

	 // this gymnastics is needed so result isn't destroyed
	 // paste these two lines into all what() code
	 whatbuf = errstr.str();
	 return whatbuf.c_str();
  }

};

END_DTL_NAMESPACE

#endif
