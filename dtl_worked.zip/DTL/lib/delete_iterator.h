/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// abstraction for DELETES
// nested class of DBView
// Initial: 9/8/2000 - MG
// Edited: 12/19/2000 - MG - added namespaces

#ifndef _DELETE_ITERATOR_H
#define _DELETE_ITERATOR_H

#include "std_inc.h"
#include "iterator.h"
#include "DBView.h"

BEGIN_DTL_NAMESPACE

template<class DataObj, class ParamObj = DefaultParamObj<DataObj> >
  class DB_delete_iterator :
     public DB_iterator_with_cols<DataObj, ParamObj>,
#ifndef __SGI_STL_PORT
	 public iterator<output_iterator_tag, DataObj, ptrdiff_t>
#else
	 // not sure why STLport not recognizing the standard iterator tag
	 // when used in algorithms like copy(_InputIter __first, _InputIter __last, _OutputIter __result)
	 // use STLport specific alternative
	 public forward_iterator<DataObj, ptrdiff_t>
#endif
{
private:

	// call this function to execute the update
	// returns number of rows updated
	// to perform another update, change the necessary parameter values
	// and then make another call to ExecDelete() to perform that Delete

	// exception-safety questionable
	int ExecDelete()
	{
		  int rowsDeleted = 0;

		  try
		  {
			if (!IsReady())
				open();

		    if (bad())
			{
			  throw DBException("DBView::delete_iterator::ExecDelete()",
				 "iterator tested bad!", NULL, NULL);
			}

			// propagate STL strings to their strbufs for proper binding
		    boundIOs.PropagateToSQL();  // if this throws, no delete is executed
			stmt.Execute();
		  }
		  catch (RootException &ex)
		  {
			  if (stmt.valid())
				  setstate(failbit);
			  else
				  setstate(badbit);

			  dtl_ios_base::MeansOfRecovery error_action =
				  io_handler(ex, *this, *(pRowbuf.get()), *pParambuf);

			  // what do we do on a REPERFORM_ACTION???
			  switch (error_action)
			  {
			    case dtl_ios_base::THROW_EXCEPTION: throw;
				case dtl_ios_base::SUPPRESS_ERROR: return (lastCount = 0);
			  }

		  }

		  // trying to stay as consistent as we can be here
		  // but no way we can be if this line throws ... in matter of fact, we'll have
		  // a corrupted iterator, but at least it's contained to here
		  // only the row count info will be messed up
		  // (the delete will have already been performed, but not the update
		  // of the state information of the iterator)
		  try
		  {
			  rowsDeleted = stmt.RowCount();
		  }
		  catch (RootException &ex)
		  {
			  if (stmt.valid())
				  setstate(failbit);
			  else
				  setstate(badbit);

			  dtl_ios_base::MeansOfRecovery error_action =
				  io_handler(ex, *this, *(pRowbuf.get()), *pParambuf);

			  switch (error_action)
			  {
			    case dtl_ios_base::THROW_EXCEPTION: throw;
				case dtl_ios_base::SUPPRESS_ERROR: return (lastCount = 0);
			  }

		  }

		  // count member keeps track of *cumulative* number of elements deleted
		  // through this iterator in order to be consistent with the other
		  // DB iterator classes
		  count += rowsDeleted;
		  clear();
	      return (lastCount = rowsDeleted);	
	}

public:
	DB_delete_iterator() : DB_iterator_with_cols<DataObj, ParamObj>() { }

    DB_delete_iterator(const DBView<DataObj, ParamObj> &view) :
		DB_iterator_with_cols<DataObj, ParamObj>(view, DEL)
		{ }

	// copy constructor and assignment operator required for Assignable
	DB_delete_iterator(const DB_delete_iterator<DataObj, ParamObj> &del_it) :
	   DB_iterator_with_cols<DataObj, ParamObj>(del_it)
	{ }

	// exception-safe swap()
	void swap(DB_delete_iterator<DataObj, ParamObj> &other)
	{
		DB_iterator_with_cols<DataObj, ParamObj>::swap(other);
	}

	// exception-safe assignment
	DB_delete_iterator<DataObj, ParamObj> &
		operator=(const DB_delete_iterator<DataObj, ParamObj> &other)
	{
		if (this != &other)
		{
			DB_delete_iterator<DataObj, ParamObj> temp(other);
			swap(temp);
		}

		return *this;
	}

	// commit deletes from this deleter and clean up
	virtual ~DB_delete_iterator()
	{ }


	// return a proxy
	// exception-safe
	DB_delete_iterator<DataObj, ParamObj> &
		operator*()
	{
		return *this;
	}

	// proxy paradigm used to be able to perform InsValidate()
	// on the rowbuf held by the iterator

	// exception-safe if DataObj::operator=() is exception-safe
	// and GetRowbufPtr() is also
	DB_delete_iterator<DataObj, ParamObj> &
		operator=(const DataObj &data)
	{
		CountedPtr<DataObj> pData = NULL;

		try
		{
		    if (bad())
			{
			   throw DBException("DBView::delete_iterator::ExecDelete()",
				  "iterator tested bad!", NULL, NULL);
			}

			pData = GetRowbufPtr();

		    *pData = data; // assign DataObj to internal rowbuf
		}
		catch (RootException &ex)
		{
			if (stmt.valid())
				setstate(failbit);
			else
				setstate(badbit);

			dtl_ios_base::MeansOfRecovery error_action = 
				io_handler(ex, *this, *(pRowbuf.get()), *pParambuf);
			
			// on the proxy assignment, what's the context of REPERFORM_OPERATION???
			switch (error_action)
			{
			   case dtl_ios_base::THROW_EXCEPTION: throw;
			   case dtl_ios_base::SUPPRESS_ERROR: break;
			}
		}

		clear();
		return *this;
	}

#if 0 // replaced by proxy code
	DataObj &operator*()
	{ 
 	   return *GetRowbufPtr();
	} 
#endif

	// execute the delete and preincrement
	// handler logic taken care of in ExecDelete()
	DB_delete_iterator<DataObj, ParamObj> &operator++()
	{
	    ExecDelete(); // will open() the iterator if necessary
		return *this;
	}

	// execute the delete and postincrement
	inline const DB_delete_iterator<DataObj, ParamObj> operator++(int) // const return to prevent iterator++++
	{
		DB_delete_iterator<DataObj, ParamObj> oldValue(*this); // standard is to return old value
		++(*this);
		return oldValue;
	}
};  
 
END_DTL_NAMESPACE

#endif
