/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// this class abstracts ODBC statements and their operations
// Initial: 9/5/2000-9/6/2000 - MG
// Revised: 11/12/2000 - CJ - fixed exception handling in Initialize()
// Revised: 11/20/2000 - MG - minor changes to expose proper methods
//							  so we can throw DBExceptions in GetFieldInfo()
// Edited: 12/19/2000 - MG - added namespaces

#ifndef _DBSTMT_H
#define _DBSTMT_H

#include "std_inc.h"
#include "DB_Base.h"
#include "DBConnection.h"


BEGIN_DTL_NAMESPACE

//#define DTL_MEM_DEBUG
#ifdef DTL_MEM_DEBUG

class mcheck {
public:

	void *ptr;
	size_t size;
	unsigned long checksum;
	unsigned long calc_check() {
		char *p;
		int i;
		long check = 0;

		for (p = (char *)ptr, i=0; i < size; i++) {
			check = (check + *(p+i))%LONG_MAX;
		}
		return check;
	}
	void write_mem(void) {
		char *p;
		int i;
		
		for (p = (char *)ptr, i=0; i < size; i++) {
			*(p+i) = (char)0xFF;
		}
	}

	mcheck(void *TargetValuePtr, size_t BufferLength) : ptr(TargetValuePtr),
		size(BufferLength) , checksum(calc_check())
	{};
	bool validate() {
		bool b_valid  = (checksum == calc_check());
		//write_mem(); // test write to memory
		return b_valid;
	}
	void revalidate() {
		checksum = calc_check();
	}
};

#endif

class DBStmt : public ValidatedObject
{
  public:
	// state of statement
    enum StmtState { STMT_UNALLOCATED = 0, STMT_ALLOCATED, STMT_PREPARED, STMT_EXECUTED };

	// status returned by Fetch()
    enum FetchStatus { ROW_FETCHED, NO_DATA_FETCHED };

    // ODBC errors deemed fatal to a DBStmt on Execute()
    // causes the DBStmt to become invalidated
    // all other errors do not validate the DBStmt
	static const vector<string> FatalErrors;

  private:

	DBConnection *pConn; // connection this statement is using
	HSTMT hstmt;		// this statement
	string sqlQuery;	// SQL query string for the statement

	StmtState state;	// is hstmt. allocated?

#ifdef DTL_MEM_DEBUG
	vector<mcheck> vc;
	vector<mcheck> vp;
#endif


	HSTMT GetHSTMT() const
	{
		return hstmt;
	}

	// prohibit copy construction and assignment
	DBStmt &operator=(const DBStmt &stmt);
	DBStmt(const DBStmt &stmt);

	static vector<string> BuildFatalErrorsList()
	{
		vector<string> errors;

	    errors.push_back("07002"); // COUNT field incorrect ... wrong # of parameters to SQLBindParam
	    errors.push_back("08S01"); // Communication link failure (lost connection to driver)
	    errors.push_back("21S02"); // Degree of table error ... number of columns mismatch
	    errors.push_back("42000"); // Syntax error or access violation
	    errors.push_back("HY105"); // Invalid parameter type (input or output)
	    errors.push_back("HYC00"); // Optional feature not implemented
        errors.push_back("HYT00"); // Timeout expired for operation
	    errors.push_back("HYT01"); // Connection timeout expired
	    errors.push_back("IM001"); // Driver does not support this function
		errors.push_back("01006"); // Privilege not revoked
		errors.push_back("01007"); // Privilege not granted
		errors.push_back("40001"); // Serialiazation failure
		errors.push_back("HY000"); // General error / no statement parsed
		errors.push_back("HY010"); // Function sequence error
		errors.push_back("HY109"); // Invalid cursor position
		errors.push_back("42S22"); // Invalid column name
		errors.push_back("07001"); // SQLBindParameter() not called for parameter
		errors.push_back("37000"); // Native error
		errors.push_back("42S02"); // No such table or view exists
		return errors;
    }

  public:

	// constructs a DBStmt associated with the connection
	// allocate (and prepare stmt) if alloc_stmt set to true
	DBStmt(string query = "", const DBConnection &connection = DBConnection::GetDefaultConnection()):
		   ValidatedObject(), sqlQuery(query), pConn(NULL),
		   hstmt(SQL_NULL_HSTMT), state(STMT_UNALLOCATED)
	{ 
	   DBConnection &connxn = const_cast<DBConnection &>(connection);
	   pConn = &connxn;
	}

		   
	// no-throw swap
	void swap(DBStmt &other) {
		std::swap(pConn, other.pConn);
		std::swap(hstmt, other.hstmt);
		sqlQuery.swap(other.sqlQuery);
		std::swap(state, other.state);
		ValidatedObject::swap(other);
	}

	// return reference to the connection associated with this stmt.
	DBConnection &GetConnection() const { return *pConn; }

	// set stmt. to refer to a different existing connection
	void SetConnection(const DBConnection &conn)
	{
	   // must destroy old HSTMT as it will now be invalid
	   // due to new connection
       try
	   {
		   Destroy();
	   }
	   catch (...)
	   {

	   }

	   DBConnection &connxn = const_cast<DBConnection &>(conn);
	   pConn = &connxn;
	}

	// Destroy() may have tricky destruction semantics
    ~DBStmt()
	{
	   try
	   {
		   Destroy();
	   }
	   catch (...)
	   {

	   }
	}


	// is the stmt. ready for execution?
	bool IsReady() const { return (state == STMT_PREPARED || state == STMT_EXECUTED)
									&& valid(); }

	// does the stmt. refer to an allocated handle?
	bool IsAllocated() const { return (state != STMT_UNALLOCATED) && valid(); }

    // check the state of the object against what we know about the hstmt
	virtual bool valid() const
	{
		// if we know the object is invalid from a previous error,
		// object is still invalid
		if (!ValidatedObject::valid())
			return false;

		// we know the object is in an invalid state
		// if the hstmt is not null and the state of the object says the statement has
		// not been allocated, then the object is in an inconsistent state
		// the same is true if the hstmt is null and the state of the object says
		// the statement has been allocated
	
		// if the handle and state are in agreement (both are nonzero or both are zero)
		// we're ok
		// so the negation of an XOR will give us whether the object is valid or not
		// as we need a *logical* XOR, we have to emulate it
		bool stmtValid = !((hstmt || state) && !(hstmt && state));

		// don't forget to invalidate the object if the statement is found invalid
		if (!stmtValid)
			const_cast<DBStmt *>(this)->invalidate();

		return stmtValid;
	}

	// get a statement ready for execution
	void Initialize()
	{
	   if (!IsReady() && valid())
	   {
		    // try to allocate stmt.
			RETCODE rc = SQLAllocStmt(pConn->GetHDBC(), &hstmt);

			if (!RC_SUCCESS(rc))
			{
				string errmsg = "Unable to allocate statement handle for \"";
				errmsg += sqlQuery;
				errmsg += "\"";

				invalidate();

				// making sure we're atomic and consistent

				state = STMT_UNALLOCATED;
				hstmt = SQL_NULL_HSTMT;

				throw DBException("DBStmt::Initialize()", errmsg, pConn, this);
			}
			
			// stmt. successfully allocated ... next try to prepare stmt.
			state = STMT_ALLOCATED;

#ifndef MYODBC_BUG
			// MyODBC driver for MySQL has a bug with SQLPrepare.
			// If we call SQLPrepare first and then try to set a string parameter
			// MyODBC will not recognize it.  Therefore, for MyODBC we use the
			// less efficient SQLExecDirect()
			char *c_str = new char[sqlQuery.length() + 1];
			if (c_str != NULL) {
				strncpy(c_str, sqlQuery.c_str(), sqlQuery.length() + 1);
				rc = SQLPrepare(hstmt, (unsigned char *) c_str, SQL_NTS);
				delete[] c_str;
			}
			else {
				invalidate();
				Destroy();
				throw DBException("DBStmt::Execute()", "Unable to allocate memory for query", pConn, this);
			}

			if (!RC_SUCCESS(rc))
			{
				string errmsg = "Unable to prepare statement handle for \"" +
								sqlQuery + "\"";

				// N.B.!! it is very important to capture the SQLError messages
				// here before we free the handle
				DBException dbe("DBStmt::Initialize()", errmsg, pConn, this);

				invalidate();

				Destroy();

				throw dbe;
			}
#endif

			state = STMT_PREPARED;

	   }
	}

	// execute the stmt.
	void Execute()
	{
		  validate();

	      if (!IsReady() && valid())
			Initialize();

#ifdef DTL_MEM_DEBUG
		vector<mcheck>::iterator it;
		for(it = vp.begin(); it != vp.end(); it++) 
			cout << it->ptr << ", ";
		cout << endl;
#endif

		RETCODE rc; 

#ifdef MYODBC_BUG
		// MyODBC driver for MySQL has a bug with SQLPrepare.
		// If we call SQLPrepare first and then try to set a string parameter
		// MyODBC will not recognize it.  Therefore, for MyODBC we use the
		// less efficient SQLExecDirect()
		// little hassle to get sqlQuery in right form
		char *c_str = new char[sqlQuery.length() + 1];
		if (c_str != NULL) {
			strncpy(c_str, sqlQuery.c_str(), sqlQuery.length() + 1);
			rc = SQLExecDirect(hstmt, (unsigned char *) c_str, SQL_NTS);
			delete[] c_str;
		}
		else {
			invalidate();
			Destroy();
			throw DBException("DBStmt::Execute()", "Unable to allocate memory for query", pConn, this);
		}
#else
	    rc = SQLExecute(hstmt);
#endif

		if (!RC_SUCCESS(rc))
		{ 
		  string errmsg = "Unable to execute statement \"";
		  errmsg += sqlQuery;
		  errmsg += "\"";


		  const DBException dbe("DBStmt::Execute()", errmsg, pConn, this);

		  // gets the actual ODBC error string
		  pair<string, string> info = dbe.GetODBCError();
		  const string szSQLError = info.first;
  
		  // if error is fatal, invalidate the DBStmt
		  if (find(FatalErrors.begin(), FatalErrors.end(),
			  szSQLError) != FatalErrors.end())
			  invalidate();

		  throw dbe;
  
		  // destructor should free statement
		}

		  state = STMT_EXECUTED;
	}

    // for SELECT's only ... fetch next row from recordset	
	FetchStatus Fetch()
	{
		validate();

#ifdef DTL_MEM_DEBUG
		vector<mcheck>::iterator it;
		bool b_check;
		//cout << "fetch: ";
		for(it = vc.begin(); it != vc.end(); it++) {
			b_check = it->validate();
			// cout << it->ptr << " - " << (b_check ? "T" : "F") << ", ";
			assert(it->validate());
		}
		//cout << endl;
#endif

		RETCODE rc = SQLFetch(hstmt);

#ifdef DTL_MEM_DEBUG
		for(it = vc.begin(); it != vc.end(); it++) 
			it->revalidate();
#endif

		switch (rc)
		{
		   // fetch went OK
		   case SQL_SUCCESS : case SQL_SUCCESS_WITH_INFO: return ROW_FETCHED;

		   // no data returned, reached end of recordset ... this is also OK
		   case SQL_NO_DATA : return NO_DATA_FETCHED;

		   // all other scenarios - an error occurred
		   default:
			{			   
			  const string errmsg = "Unable to fetch for statement \"" +
								  sqlQuery + "\"";

			  const DBException dbe("DBStmt::Fetch()", errmsg, pConn, this);
			  
			  // gets the actual ODBC error string
			  pair<string, string> info = dbe.GetODBCError();
			  const string szSQLError = info.first;
		  
			  // if error is fatal, invalidate the DBStmt
			  if (find(FatalErrors.begin(), FatalErrors.end(),
				  szSQLError) != FatalErrors.end())
				  invalidate();
			   			    
			  throw dbe;
			}
		}
		return NO_DATA_FETCHED;
	}

	// destroy this hstmt. ... must use if done with the hstmt completely or the
	// underlying SQL string is changed
	// (can always reuse the hstmt with the same query)

	// tricky destructor issues here!
	void Destroy()
	{
		   // state may be only partly valid() partial destructions allowed below

	       if (state != STMT_UNALLOCATED)
		   {	
			 RETCODE rc = SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
			 
			 if (!RC_SUCCESS(rc))
			 {
				invalidate();

				string errmsg = "Unable to free stmt. handle for \"";
				errmsg += sqlQuery;
				errmsg += "\"";

				// these two lines needed to provide local atomicity and
				// consistency for exception safety
				state = STMT_UNALLOCATED;
				hstmt = SQL_NULL_HSTMT;
				
				throw DBException("DBStmt::Destroy()", errmsg, pConn, this);
			 }
			 else
			 {
				hstmt = SQL_NULL_HSTMT;
			 }
 	       }
		
	       state = STMT_UNALLOCATED;

	}

	// frees current statement handle and allocates and prepares a new one
	void ReInitialize()
	{
	       try
		   {
			   Destroy();
		   }
		   catch (...)
		   {

		   }
	       Initialize();
	}

	// reexecute the statement ... should only be used on a select stmt.
	void ReExecute()
	{
	      Reset();
	      Execute();
	}

	// close the stmt. so we can reexecute it ... use on a SELECT stmt. to reset the
	// cursor to the top of the recordset
	void Reset()
	{
		   validate();

	       RETCODE rc = SQLCloseCursor(hstmt);

		   // if unable to close cursor, we have no choice but to execute a fresh
		   // statement
		   if (!RC_SUCCESS(rc))
		   {
				ReInitialize();
		   }
	}

	// form of reset which accepts a new query string for the stmt.
	// must destroy and realloc the hstmt in order to bind
	// query string to stmt.
	void ResetWithNewQuery(string qry)
	{
	       try
		   {
			   Destroy();
		   }
		   catch (...)
		   {


		   }

	       // set the new query string before we reinitialize
	       // as Initialize does the SQLPrepare()
	       sqlQuery = qry; // atomicity not guaranteed (but consistency maintained)
						   // if string asssigment fails

	}

	// bind a parameter for the statement
	void BindParam(SDWORD ParameterNumber, SDWORD InputOutputType,
					  SDWORD ValueType,	SDWORD ParameterType,
					  SDWORD ColumnSize, SDWORD DecimalDigits,
					  void *ParameterValuePtr, SDWORD BufferLength,
					  SDWORD *StrLen_or_IndPtr)
	{
		  validate();

	      if (!IsReady() && valid())
	          Initialize();

		  RETCODE rc = SQLBindParameter((SQLHSTMT) hstmt,
			    (SQLUSMALLINT) ParameterNumber + 1,
			    (SQLSMALLINT) InputOutputType, (SQLSMALLINT) ValueType,
				(SQLSMALLINT) ParameterType, (SQLUINTEGER) ColumnSize,
				(SQLSMALLINT) DecimalDigits, (SQLPOINTER) ParameterValuePtr, 
				(SQLINTEGER) BufferLength, (SQLINTEGER *) StrLen_or_IndPtr);

	      if (!RC_SUCCESS(rc))
		  {
			string errmsg = "Parameter binding failed for parameter #";

			// get parameter number
			ostrstream errstr;
			errstr << errmsg;

			errstr << ParameterNumber << " in statement \"" << sqlQuery << "\"!  ";
			errstr << endl << "(Remember: Parameter numbers are zero-index based!)";
			errstr << "DB expected type is incompatible with C++ type!" << ends;

			const DBException dbe("DBStmt::BindParam()", errstr.str(), pConn, this);
			  
			// gets the actual ODBC error string
			pair<string, string> info = dbe.GetODBCError();
			const string szSQLError = info.first;
		  
			// if error is fatal, invalidate the DBStmt
			if (find(FatalErrors.begin(), FatalErrors.end(),
				  szSQLError) != FatalErrors.end())
				  invalidate();
			   			    
			throw dbe;
		  }

#ifdef DTL_MEM_DEBUG	  
		  vp.push_back(mcheck(ParameterValuePtr, BufferLength));
		  vc.push_back(mcheck(StrLen_or_IndPtr, sizeof(SDWORD)));
#endif
	}

	// bind a column for the statement
	void BindCol(SDWORD ColumnNumber, SDWORD TargetType,
					void *TargetValuePtr, SDWORD BufferLength,
					SDWORD *StrLen_or_IndPtr)
	{
		  validate();

	      if (!IsReady())
			Initialize();

	      RETCODE rc = SQLBindCol((SQLHSTMT) hstmt,
			    (SQLUSMALLINT) ColumnNumber + 1,
			    (SQLSMALLINT) TargetType, (SQLPOINTER) TargetValuePtr, 
				(SQLINTEGER) BufferLength, (SQLINTEGER *) StrLen_or_IndPtr);

	      if (!RC_SUCCESS(rc))
		  {
			string errmsg = "Column binding failed for parameter #";

			// get parameter number
			ostrstream errstr;
			errstr << errmsg;

			errstr << ColumnNumber << " in statement \"" << sqlQuery << "\"!  ";
			errstr << endl << "(Remember: Column numbers are zero-index based!)";
			errstr << "DB expected type incompatible with C++ type!" << ends;

			const DBException dbe("DBStmt::BindCol()", errstr.str(), pConn, this);
			  
			// gets the actual ODBC error string
			pair<string, string> info = dbe.GetODBCError();
			const string szSQLError = info.first;
		  
			// if error is fatal, invalidate the DBStmt
			if (find(FatalErrors.begin(), FatalErrors.end(),
				  szSQLError) != FatalErrors.end())
				  invalidate();
			   			    
			throw dbe;
		  }
		  
#ifdef DTL_MEM_DEBUG	  
		  vc.push_back(mcheck(TargetValuePtr, BufferLength));
		  vc.push_back(mcheck(StrLen_or_IndPtr, sizeof(SDWORD)));		  
#endif
	}


	// return number of affected rows ... used by UPDATE and DELETE
	long RowCount() const
	{
		validate();
		if (!IsReady() && valid())
			const_cast<DBStmt *>(this)->Initialize();

		long result;

		RETCODE rc = SQLRowCount(hstmt, &result);
		
		if (!RC_SUCCESS(rc))
		{
		   const_cast<DBStmt *>(this)->invalidate();
		   throw DBException("DBStmt::RowCount()",
							 "Unable to get row count for statement \"" + sqlQuery +
							 "\"!", pConn, this);
		}

		return result;
	}

	// get the query string for this statement
	string GetQuery() const
	{
	     return sqlQuery;
	}

    friend class DBException;

	// kludge to get around header hell
	friend HSTMT GetHSTMT(const DBStmt &stmt);

};

END_DTL_NAMESPACE

#endif
