#include "CountedPtr.h"

BEGIN_DTL_NAMESPACE

#ifdef DTL_MEM_DEBUG
set<char *> MemPtr::memChecker;
#endif

END_DTL_NAMESPACE
