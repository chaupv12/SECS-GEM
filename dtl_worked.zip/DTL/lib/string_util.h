/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// misc. string utilities for our DB abstractions
// Initial: 9/7/2000 - MG
// Edited: 12/19/2000 - MG - added namespaces
#include "std_inc.h"

#ifndef _STRING_UTIL_H
#define _STRING_UTIL_H

BEGIN_DTL_NAMESPACE

// construct a delimited list out of the strings in the container, each
// having the suffix tacked on to it
// (should also work for char *'s)
template <typename StrContainer> string
	MakeDelimitedList(const StrContainer &container, string suffix = "",

					  string delimiter = ", ")
{
	string delimitedList;
	delimitedList.reserve(192); // reserve size of 128 for speed in concatenation
	for (typename StrContainer::const_iterator str_it = container.begin();
			str_it != container.end(); str_it++)
	{
		if (str_it != container.begin())
		{
			// only add delimiter if this isn't the first item
		    delimitedList += delimiter;
		}
	
		// tack item on to end of list along with the suffix
		delimitedList += *str_it;
		delimitedList += suffix;
	}


	return delimitedList;
}


// finds the number of occurrences of the character in the string
unsigned int numOfOccurrences(char c, string inString);

// parse a comma-separated list of strings, packaging the result in a vector
// of the strings
vector<string> ParseCommaDelimitedList(string commaList);

char *EatLeadingWhitespace(char * & c_str);
char *EatTrailingWhitespace(char *c_str);

#ifndef _MSC_VER
// define case insensitive string compare routine
// many compilers may already have this
int stricmp(const char *s1, const char *s2);
int strnicmp(const char *s1, const char *s2, int len);
#endif

END_DTL_NAMESPACE

#endif
