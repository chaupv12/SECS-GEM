/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// abstraction for views -- main class only
// the nested classes (the DB cursor abstractions)are each defined
// in their own separate headers
// Initial: 9/7/2000 - MG
// Edited: 12/19/2000 - MG - added namespaces

#ifndef _DBVIEW_H
#define _DBVIEW_H

#include "std_inc.h"
#include "BoundIO.h"
#include "DB_Base.h"
#include "DBConnection.h"
#include "DBDefaults.h"

BEGIN_DTL_NAMESPACE

template<class DataObj, class ParamObj> class DB_iterator;

template<class DataObj, class ParamObj> class DB_iterator_with_cols;

template<class DataObj, class ParamObj> class DB_select_insert_iterator;

template<class DataObj, class ParamObj> class DB_select_iterator;

template<class DataObj, class ParamObj> class DB_insert_iterator;

template<class DataObj, class ParamObj> class DB_update_iterator;

template<class DataObj, class ParamObj> class DB_delete_iterator;

// default functors for BCA and BPA -- bind nothing
// wrap function pointers with these objects to use

template<class DataObj> class DefaultBCA : public binary_function<BoundIOs &, DataObj &, void>
{
  public:
	  void operator()(BoundIOs &boundIOs, DataObj &rowbuf)
	  {
			throw DBException("DefaultBCA::operator()()", "Must define a BCA!", NULL, NULL);

	  }

};

template<class ParamObj> class DefaultBPA : public binary_function<BoundIOs &, ParamObj &, void>
{
  public:
	  void operator()(BoundIOs &boundIOs, ParamObj &paramObj)
	  { }
};

template<class ParamObj> class EmptyBPA : public binary_function<BoundIOs &, ParamObj &, void>
{
  public:
	  void operator()(BoundIOs &boundIOs, ParamObj &paramObj)
	  { }

};

// generic IO handler that expects a signature of
// dtl_ios_base::MeansOfRecovery handler()
template<class DataObj, class ParamObj> class IOHandler
{
     private:
	    variant_cc_t v; // polymorphically stores the handler object
		IOHandler() : v() { } // Don't allow default constructor -- too dangerous
     public:
	    enum Handlers
		{
          IO_HANDLER
		};


	    // constructor takes a raw error handler function object
	    // and then registers the UserHandler::operator() that serves as its error handler
        template<class UserHandler> IOHandler(const UserHandler &handler) :
	    v(handler) 
		{ 
		   	if (false) {
				// Let the compiler do compile time type checking.
				// This is purely to get a good compile time warning
				// if the required signature does not match.
				// Signature of UserClass::operator() must be:
				// dtl_ios_base::MeansOfRecovery(RootException &ex, dtl_ios_base &base,
				//	   DataObj &data, ParamObj &params;
	
				ParamObj p;
				DataObj d;
				RootException ex;
				dtl_ios_base b;
				dtl_ios_base::MeansOfRecovery r;
				UserHandler *pmethod = const_cast<UserHandler *>(&handler);
				r = pmethod->operator()(ex, b, d, p);  // compile-time type check: see above
			}
			v.AddCBFunctor4_w_ret(IO_HANDLER, &UserHandler::operator());
		}

	    // copy constructor
	    IOHandler(const IOHandler &handler) : v(handler.v)  { }

	    // exception-safe swap
	    void swap(IOHandler &h)
		{
           v.swap(h.v);
		}

	    // assignment operator
	    IOHandler &operator=(const IOHandler &handler)
		{
		   if (this != &handler)
		   {
		      IOHandler tmp(handler);
		      swap(tmp);
		   }

		   return *this;
		}

	    // act as the error functor ... in reality forward the call
	    // to the actual handler itself

		// signature of handler must be:
		// dtl_ios_base::MeansOfRecovery(RootException &ex, dtl_ios_base &base,
		//	   DataObj &data, ParamObj &params;
		dtl_ios_base::MeansOfRecovery
			operator()(RootException &ex, dtl_ios_base &base,
			   DataObj &data, ParamObj &params)
		{

		 return variant_invoke_w_ret4<RootException &, dtl_ios_base &, DataObj &, 
			 ParamObj &, dtl_ios_base::MeansOfRecovery> 
		 (v, IO_HANDLER, ex, base, data, params, (dtl_ios_base::MeansOfRecovery *) NULL);


		}

	    // conversion operator needed so we can reextract the actual handler
	    // held by v
	    template<typename UserHandler> const UserHandler &
		   get(const UserHandler *dummy) const
		{
		   return v.get(dummy);
		}
};

// translation class from IOHandler<DataObj, ParamObj> to IOHandler<DataObj, DataObj>
// (this actually is a monomorphic IOHandler that contains the dimorphic one we 'converted)
template<class DataObj, class ParamObj> class DimorphToMonomorph 
{
private:
	IOHandler<DataObj, ParamObj> io_handler;
public:
	DimorphToMonomorph(IOHandler<DataObj, ParamObj> h) : io_handler(h) { }
	
	dtl_ios_base::MeansOfRecovery operator()(RootException &ex, dtl_ios_base &base,
		DataObj &data, DataObj &dummy) 
	{
		ParamObj temp;
		return io_handler(ex, base, data, temp);
	}

};

// template function to make an IOHandler<DataObj, DataObj> out of a 
// IOHandler<DataObj, ParamObj> by using a DimorphToMonomorph translator
template<class DataObj, class ParamObj> 
	IOHandler<DataObj, DataObj> monomorphize(IOHandler<DataObj, ParamObj> h) 
{
	return IOHandler<DataObj, DataObj>(DimorphToMonomorph<DataObj, ParamObj>(h));
}

// two error handlers that provide predefined behavior

// this one directs the handling code to always throw

template<class DataObj, class ParamObj = DefaultParamObj<DataObj> > class AlwaysThrowsHandler
{
public:
	dtl_ios_base::MeansOfRecovery
		operator()(RootException &ex, dtl_ios_base &base,
		   DataObj &data, ParamObj &params)
	{
		return dtl_ios_base::THROW_EXCEPTION;
	}

};

// this handler logs exceptions to a vector
// then tells caller to reperform the action
template<class DataObj, class ParamObj = DefaultParamObj<DataObj> > class LoggingHandler
{
public:
	struct LoggedTriple
	{
		string errmsg;
		DataObj dataObj;
		ParamObj paramObj;

		LoggedTriple() : errmsg(""), dataObj(), paramObj() { }

		LoggedTriple(const string &msg, const DataObj &data, const ParamObj &param) :
		  errmsg(msg), dataObj(data), paramObj(param) { }
	};

private:
	CountedPtr<vector<LoggedTriple> > pErrorLog;
	
public:

	LoggingHandler() :
		  pErrorLog(new vector<LoggedTriple>) { }
	
	dtl_ios_base::MeansOfRecovery
		operator()(RootException &ex, dtl_ios_base &base,
			DataObj &data, ParamObj &params)
	{
		pErrorLog->push_back(LoggedTriple(ex.what(), data, params));
		
		// throw if the iterator is bad
		// if (base.bad())
		//	 return dtl_ios_base::THROW_EXCEPTION;

		// otherwise take the action that the user passed in at construction time
		return dtl_ios_base::SUPPRESS_ERROR;
	}

	// returns a *copy* of the error log
	vector<LoggedTriple> GetLog() const
	{
		return *pErrorLog;
	}

};

// What type of query?
enum SQLQueryType { SELECT, INSERT, UPDATE, DEL, USER_DEFINED };

// generic IO method that expects a signature of
// dtl_ios_base::MeansOfRecovery method()
template<class DataObj> class BCAWrap
{
     private:
	    variant_cc_t v; // polymorphically stores the method object
		BCAWrap() : v() { } // Don't allow default constructor -- too dangerous
     public:
	    enum Methods
		{
          INVOKE
		};


	    // constructor takes a raw error method function object
	    // and then registers the UserClass::operator() that serves as its error method
        template<class UserClass> BCAWrap(const UserClass &method) :
	    v(method) 
		{ 
			if (false) {
				// Let the compiler do compile time type checking.
				// This is purely to get a good compile time warning
				// if the required signature does not match.
				// signature of UserClass::operator() must be:
				// void bca(BoundIOs &boundIOs, DataObj &rowbuf)

				BoundIOs b;
				DataObj d;
				UserClass *pmethod = const_cast<UserClass *>(&method);
				pmethod->operator()(b, d);  // compile-time type check: see above
			}

		   v.AddCBFunctor2(INVOKE, &UserClass::operator());
		}

	    // copy constructor
	    BCAWrap(const BCAWrap &other) : v(other.v)  { }

	    // exception-safe swap
	    void swap(BCAWrap &h)
		{
           v.swap(h.v);
		}

	    // assignment operator
	    BCAWrap &operator=(const BCAWrap &method)
		{
		   if (this != &method)
		   {
		      BCAWrap tmp(method);
		      swap(tmp);
		   }

		   return *this;
		}

	    // act as the error functor ... in reality forward the call
	    // to the actual method itself

		// signature of BCAWrap must be:
		// void bca(BoundIOs &boundIOs, DataObj &rowbuf)
		void operator()(BoundIOs &boundIOs, DataObj &rowbuf) {
			variant_invoke2<BoundIOs &,DataObj &> (v, INVOKE, boundIOs, rowbuf);
		}

	    // conversion operator needed so we can reextract the actual method
	    // held by v
	    template<typename UserClass> const UserClass &
		   get(const UserClass *dummy) const
		{
		   return v.get(dummy);
		}
};

// wrap a BPA
template<class ParamObj> class BPAWrap
{
     private:
	    variant_cc_t v; // polymorphically stores the method object

		BPAWrap() : v() { } // Don't allow default constructor -- too dangerous

     public:
	    enum Methods
		{
          INVOKE
		};

	
	    // constructor takes a raw error method function object
	    // and then registers the UserClass::operator() that serves as its error method
        template<class UserClass> BPAWrap(const UserClass &method) :
	    v(method) 
		{ 
			if (false) {
				// Let the compiler do compile time type checking.
				// This is purely to get a good compile time warning
				// if the required signature does not match.
				// Signature of UserClass::operator() must be:
				// void bca(BoundIOs &boundIOs, ParamObj &rowbuf)


				BoundIOs b;
				ParamObj d;
				UserClass *pmethod = const_cast<UserClass *>(&method);
				pmethod->operator()(b, d);  // compile-time type check: see above
			}

		    v.AddCBFunctor2(INVOKE, &UserClass::operator());
		}

	    // copy constructor
	    BPAWrap(const BPAWrap &other) : v(other.v)  { }

	    // exception-safe swap
	    void swap(BPAWrap &h)
		{
           v.swap(h.v);
		}

	    // assignment operator
	    BPAWrap &operator=(const BPAWrap &method)
		{
		   if (this != &method)
		   {
		      BPAWrap tmp(method);
		      swap(tmp);
		   }

		   return *this;
		}

	    // act as the error functor ... in reality forward the call
	    // to the actual method itself

		// signature of BPAWrap must be:
		// void bca(BoundIOs &boundIOs, ParamObj &param)
		void operator()(BoundIOs &boundIOs, ParamObj &param) {
			variant_invoke2<BoundIOs &,ParamObj &> (v, INVOKE, boundIOs, param);
		}

	    // conversion operator needed so we can reextract the actual method
	    // held by v
	    template<typename UserClass> const UserClass &
		   get(const UserClass *dummy) const
		{
		   return v.get(dummy);
		}
};

// InsVal & SelVal functions should only be responsible for validating a single record
 
// wrap an InsVal
template<class DataObj> class InsValWrap
{
     private:
	    variant_cc_t v; // polymorphically stores the method object

		InsValWrap() : v() { } // Don't allow default constructor -- too dangerous

     public:
	    enum Methods
		{
          INVOKE
		};

	
	    // constructor takes a raw error method function object
	    // and then registers the UserClass::operator() that serves as its error method
        template<class UserClass> InsValWrap(const UserClass &method) :
	    v(method) 
		{ 
			if (false) {
				// Let the compiler do compile time type checking.
				// This is purely to get a good compile time warning
				// if the required signature does not match.
				// Signature of UserClass::operator() must be:
				// bool (DataObj &rowbuf)

				DataObj d;
				UserClass *pmethod = const_cast<UserClass *>(&method);
				bool b = pmethod->operator()(d);  // compile-time type check: see above
			}

			v.AddCBFunctor1_w_ret(INVOKE, &UserClass::operator());
		}

	    // copy constructor
	    InsValWrap(const InsValWrap &other) : v(other.v)  { }

	    // exception-safe swap
	    void swap(InsValWrap &h)
		{
           v.swap(h.v);
		}

	    // assignment operator
	    InsValWrap &operator=(const InsValWrap &method)
		{
		   if (this != &method)
		   {
		      InsValWrap tmp(method);
		      swap(tmp);
		   }

		   return *this;
		}

	    // act as the error functor ... in reality forward the call
	    // to the actual method itself

		// signature of InsValWrap must be:
		//  bool (*InsValWrap) (DataObj &rowbuf)
		bool operator()(DataObj &rowbuf) {
			return variant_invoke_w_ret1<DataObj &, bool> (v, INVOKE, rowbuf, (bool *)NULL);
		}

	    // conversion operator needed so we can reextract the actual method
	    // held by v
	    template<typename UserClass> const UserClass &
		   get(const UserClass *dummy) const
		{
		   return v.get(dummy);
		}
};

 
// wrap a SelVal
template<class DataObj> class SelValWrap
{
     private:
	    variant_cc_t v; // polymorphically stores the method object

		SelValWrap() : v() { } // Don't allow default constructor -- too dangerous

     public:
	    enum Methods
		{
          INVOKE
		};

	
	    // constructor takes a raw error method function object
	    // and then registers the UserClass::operator() that serves as its error method
        template<class UserClass> SelValWrap(const UserClass &method) :
	    v(method) 
		{ 
			if (false) {
				// Let the compiler do compile time type checking.
				// This is purely to get a good compile time warning
				// if the required signature does not match.
				// Signature of UserClass::operator() must be:
				// bool SelValWrap(BoundIOs &boundIOs, DataObj &rowbuf)

				DataObj d;
				BoundIOs b;
				UserClass *pmethod = const_cast<UserClass *>(&method);
				bool r = pmethod->operator()(b, d);  // compile-time type check: see above
			}
		   v.AddCBFunctor2_w_ret(INVOKE, &UserClass::operator());
		}

	    // copy constructor
	    SelValWrap(const SelValWrap &other) : v(other.v)  { }

	    // exception-safe swap
	    void swap(SelValWrap &h)
		{
           v.swap(h.v);
		}

	    // assignment operator
	    SelValWrap &operator=(const SelValWrap &method)
		{
		   if (this != &method)
		   {
		      SelValWrap tmp(method);
		      swap(tmp);
		   }

		   return *this;
		}

	    // act as the error functor ... in reality forward the call
	    // to the actual method itSelValWrapf

		// signature of SelValWrap must be:
		// bool SelValWrap(BoundIOs &boundIOs, DataObj &rowbuf)
		bool operator()(BoundIOs &boundIOs, DataObj &rowbuf) {
			return variant_invoke_w_ret2<BoundIOs &,DataObj &, bool> 
				(v, INVOKE, boundIOs, rowbuf, (bool *)NULL);
		}

	    // conversion operator needed so we can reextract the actual method
	    // held by v
	    template<typename UserClass> const UserClass &
		   get(const UserClass *dummy) const
		{
		   return v.get(dummy);
		}
};

// default parameter object for a data class can either use a general template which will
// contain zero parameters to bind to or specialize the DefaultParamObj template to get
// the desired default behavior you want
template<class DataObj, class ParamObj = DefaultParamObj<DataObj> >
class DBView
{
public: 
	typedef BCAWrap<DataObj> BCA;
	typedef BPAWrap<ParamObj> BPA;
	typedef InsValWrap<DataObj> InsVal;
	typedef SelValWrap<DataObj> SelVal;
    // typedef void (*BCA) (BoundIOs &boundIOs, DataObj &rowbuf);
    // typedef void (*BPA) (BoundIOs &boundIOs, ParamObj &paramBuf);

	// standard STL typedefs
	typedef DataObj value_type;
	typedef value_type* pointer;
	typedef const value_type* const_pointer;
	typedef value_type& reference;
	typedef const value_type& const_reference;

	typedef DB_select_iterator<DataObj, ParamObj> const_iterator;
    typedef const_iterator iterator;
	typedef ptrdiff_t difference_type;
	typedef size_t size_type;

	// typedefs for cursor abstractions
	// should be accessible as DBView<DataObj, ParamObj>::name
	typedef DB_iterator<DataObj, ParamObj> base_iterator;
	typedef DB_iterator_with_cols<DataObj, ParamObj> iterator_with_cols;
	typedef DB_select_insert_iterator<DataObj, ParamObj> select_insert_iterator;
	typedef DB_select_iterator<DataObj, ParamObj> select_iterator;
	typedef DB_insert_iterator<DataObj, ParamObj> insert_iterator;
	typedef DB_update_iterator<DataObj, ParamObj> update_iterator;
	typedef DB_delete_iterator<DataObj, ParamObj> delete_iterator;

	// typedefs exposed for binding
	typedef DataObj DataObject;
	typedef ParamObj ParamObject;
 
protected:
    set<string> tableNames;
    set<string> colNames;
    string postfixClause;
    BCA bca; // bind column addr. fn. - used for all column abstractions
	         // select, insert, update
    BPA bpa; // bind posfix addr. fn. - used for postfix clauses in all contexts
    unsigned int numParams;
    unsigned int numColumns;
    InsVal InsValidate;  // insert validate fn. - used both for insert and update
    SelVal SelValidate; // select validate fn. - used for select

	mutable IOHandler<DataObj, ParamObj> io_handler; // the default error handler for iterators over this view

    DBConnection *pConn;  // pointer to connection used by this view

public:

	// needed only for default constructor of DBIndex .. never use
	DBView() : tableNames(), pConn(&(DBConnection::GetDefaultConnection())), postfixClause(""),
				bca(DefaultBCA<DataObj>()), bpa(DefaultBPA<ParamObj>()),
				InsValidate(DefaultInsValidate<DataObj>()),
				SelValidate(DefaultSelValidate<DataObj>()), colNames(),
				numColumns(0), numParams(0), 
				io_handler(LoggingHandler<DataObj, ParamObj>()) { }


    // constructor ... build view representation with table names
    // only actually initializes table names
    // "tables" is a comma separated list of table names
    // NULL for any of the function pointers means no action is performed in that context
    // for that view

    DBView(const string tableList, const BCA bca_fn = DefaultBCA<DataObj>(),
		   const string postfix = "", const BPA bpa_fn = DefaultBPA<ParamObj>(),
		   const SelVal sel_val = DefaultSelValidate<DataObj>(),
		   const InsVal ins_val = DefaultInsValidate<DataObj>(),
		   DBConnection &connection = DBConnection::GetDefaultConnection()) :
		   pConn(&connection),
		   tableNames(ParseTableList(tableList)),
		   postfixClause(postfix), bca(bca_fn), bpa(bpa_fn),
		   InsValidate(ins_val),
		   SelValidate(sel_val), colNames(), numColumns(0), numParams(0),
		   io_handler(LoggingHandler<DataObj, ParamObj>())
    {
		DataObj dummy_obj;
	    ParamObj param_obj;
	    BoundIOs dummy_bc(BoundIO::BIND_ADDRESSES);

		dummy_bc.BindAsBase(dummy_obj);

		bca(dummy_bc, dummy_obj);

		BoundIOs dummy_bp(BoundIO::BIND_ADDRESSES);
		
		dummy_bp.BindParamBase(param_obj);
		
		bpa(dummy_bp, param_obj);

		colNames = dummy_bc.GetColumnNames();
	
        numParams = ParsePostfixForParams();
        numColumns = colNames.size();
    }

	// copy constructor and assignment operator required for Assignable and swap()
	// note that as the list of active rowbufs and the ref count map refer to DataObj's
	// in use by iterators of the particular view and no iterators are held by a
    // freshly constructed DBView, the list and map are made empty in the copy built
	DBView(const DBView<DataObj, ParamObj> &view) : bca(view.bca), bpa(view.bpa),
		colNames(view.colNames), InsValidate(view.InsValidate), numColumns(view.numColumns),
		numParams(view.numParams), pConn(view.pConn), postfixClause(view.postfixClause),
		SelValidate(view.SelValidate), tableNames(view.tableNames),
		io_handler(view.io_handler)
	{ }

	// note that all existing iterators into the destination view become invalid
	// upon assignment of a new view!!!!
	DBView<DataObj, ParamObj> &operator=(const DBView<DataObj, ParamObj> &view)
	{
		if (this != &view)
		{
			DBView<DataObj, ParamObj> temp(other);
			swap(temp);
		}

		return *this;

	}

	// thanks to our custom copy constructor and assignment operator, swap()
	// should behave as desired!
	// Note that all iterators pointing into *this and other are invalidated
	// upon calling this function!!!!

	// rewritten to make exception-safe - MG - 1/10/2001
	void swap(DBView<DataObj, ParamObj> &other)
	{
		bca.swap(other.bca);
		bpa.swap(other.bpa);
		colNames.swap(other.colNames);
		InsValidate.swap(other.InsValidate);
		std::swap(numColumns, other.numColumns);
		std::swap(numParams, other.numParams);
		postfixClause.swap(other.postfixClause);
		SelValidate.swap(other.SelValidate);
		tableNames.swap(other.tableNames);
		io_handler.swap(other.io_handler);
	}

    // does nothing as other views may be using the connection
    ~DBView() { }

    // return number of parameters expected in query
    unsigned int GetBoundParamCount() const
    {
	  return numParams;
    }

    // get number of columns in query
    unsigned int GetColumnCount() const
    {
	  return numColumns;
    }

	// set and get error handler functions
	// similar to set_new_handler() and get_new_handler() in the standard library
    
	// Note: no outstanding iterators over a view are affected when the handler is
	// changed, but any iterators created after the handler is reset will
	// use the new handler by default

	template<class UserHandler> const UserHandler &
		get_io_handler(const UserHandler *dummy) const
	{
		return io_handler.get(dummy);
	}

	// returns raw IOHandler object

	IOHandler<DataObj, ParamObj> &get_io_handler() const
	{
		return io_handler;
	}

	// pass by value instead of const reference as otherwise const_cast occurs
	// and h would change
	void set_io_handler(IOHandler<DataObj, ParamObj> h)
	{	
		io_handler.swap(h);
	}

    // parse postfix clause to figure out the number of parameters expected by query
    unsigned int ParsePostfixForParams() const
    {
	  return numOfOccurrences('?', postfixClause);
    }

    // are the 2 views the same?
	// really we want the two views to actually be the same reference
	// given the design of the rest of DBObjects
    friend bool operator==(const DBView &v1, const DBView &v2)
    {
		return &v1 == &v2;
    }

    // are the 2 views different?
    friend bool operator!=(const DBView &v1, const DBView &v2)
    {
	  return !(v1 == v2);
    }


	// parse a comma-separated list of table names, packaging the result in a sorted set
	// of the strings
	static set<string> ParseTableList(string tableList)
	{
	  vector<string> parsedVec = ParseCommaDelimitedList(tableList);

	  set<string> parsedSet;
	  
	  // copy list into a set, which is properly sorted for our needs

	  for (vector<string>::iterator it = parsedVec.begin(); it != parsedVec.end(); it++)
		  parsedSet.insert(*it);

	  return parsedSet;
	}


    // return a SQL query based on the query type
    // uses the tableNames, colNames, and postfixClause structures
    string BuildQry(SQLQueryType qryType) const
	{
	  string Query;

	  // validate to make sure on INSERT, UPDATE, and DELETE that exactly one
      // table is being operated on
      // and for SELECT, at least one table is being selected from
      // then build query
          
      switch (qryType)
	  {
	  case SELECT: {
		 // SELECT colNames FROM tableNames postfixClause
		 if (tableNames.empty())
			throw DBException("DBView::BuildQry()",
				   "SELECT : must select from at least one table", NULL, NULL);

		 if (colNames.empty())
			throw DBException("DBView::BuildQry()",
				   "SELECT : must select from at least one column", NULL, NULL);

		 // build SELECT stmt into Query
		 Query += "SELECT ";

		 // build comma-separated list of columns and tack on to the query
		 Query += MakeDelimitedList(colNames);

		 Query += " FROM ";

		 // now add a comma-separated list of the tables
		 Query += MakeDelimitedList(tableNames);

		 break;
		}
	  case INSERT: {
		 // INSERT INTO tableName (colName[0], colName[1], ...)
		 // VALUES (?, ?, ...) postfixClause

		 if (tableNames.size() != 1)	
			throw DBException("DBView::BuildQry()",
				"INSERT:  must insert into exactly one table", NULL, NULL);

		 if (colNames.empty())
			throw DBException("DBView::BuildQry()",
				"INSERT:  must insert with at least one column", NULL, NULL); 

		 // build INSERT stmt into Query
		 Query += "INSERT INTO ";

		 // tack on table name
		 Query += (*tableNames.begin());

		 // tack on column names

		 Query += " (";
		 Query += MakeDelimitedList(colNames);
		 Query += ")";

		 // tack on appropriate number of question marks for values
		 Query += " VALUES (";

		 vector<string> questionMarks(colNames.size(), "(?)");

		 // build comma-separated list of colName=? entries and tack it on
		 Query += MakeDelimitedList(questionMarks);

		
		 Query += ")";

		 break;
		}
	  case UPDATE: {
		 // UPDATE tableName SET colName[0]=?, colName[1]=?, ... postfixClause
		 if (tableNames.size() != 1)
			throw DBException("DBView::BuildQry()", 
				"UPDATE: must update in exactly one table", NULL, NULL);

		 if (colNames.empty())
			throw DBException("DBView::BuildQry()",
				"UPDATE: must update at least one column", NULL, NULL);

		 // build UPDATE stmt into Query

		 Query += "UPDATE ";

		 // tack on table name
		 Query += (*tableNames.begin());

		 Query += " SET ";

		 // build comma-separated list of colName=? entries and tack it on
		 Query += MakeDelimitedList(colNames, " = (?) ");

		 break;
		}
	  case DEL: {
		 // DELETE FROM tableName WHERE colName[0] and colName[1] ... postfixClause
		 if (tableNames.size() != 1)
			throw DBException("DBView::BuildQry()",
				"DELETE: must delete from exactly one table", NULL, NULL);

		 // build DELETE stmt into Query

		 Query += "DELETE FROM ";

		 // tack on table name
		 Query += (*tableNames.begin());

		 Query += " WHERE ";

		 // don't allow deletes to wipe out a whole table
		 if (colNames.empty())
			 throw DBException("DBView::BuildQry()",
			   "DELETE: Must specify at least one column to filter on!", NULL, NULL);

		 // now build colNames clause in form of
		 // colName1 = (?) AND colName2 = (?) AND colName3 = (?)
		 Query += MakeDelimitedList(colNames, " = (?) ", " AND ");

		 break;
		 }
	   default: // shouldn't happen ... throw exception if it does
		   throw DBException("DBView::BuildQry()",
			    "Invalid statement type!", NULL, NULL);
	  }

     // tack on postfix clause
     if (postfixClause.length() > 0)
			Query += " " + postfixClause;

     return Query;
    }

	
	// accessors
    string GetPostfixClause() const    { return postfixClause; }

    BCA GetBCA() const				   { return bca;			  }

    BPA GetBPA() const				   { return bpa;			  }

    InsVal GetInsVal() const		   { return InsValidate;   }

    SelVal GetSelVal() const		   { return SelValidate;   }

    DBConnection &GetConnection() const{ return *pConn;          }

    set<string> GetTableNames() const  { return tableNames;    }
	set<string> GetColNames() const    { return colNames;      }

    // return "dummy" iterators for beginning and end of view

	// iterators for begin and end of view
    const_iterator begin() const
	{
		return const_iterator(*this, select_iterator::DUMMY_BEGIN);
	}

    const_iterator end() const
	{
		return const_iterator(*this, select_iterator::DUMMY_END);
	}

	iterator begin()
	{
		return iterator(*this, select_iterator::DUMMY_BEGIN);
	}

	iterator end()
	{
		return iterator(*this, select_iterator::DUMMY_END);
	}

	friend class DB_iterator<DataObj, ParamObj>;
};

END_DTL_NAMESPACE

#endif
