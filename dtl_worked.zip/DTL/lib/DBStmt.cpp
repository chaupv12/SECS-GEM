/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
#include "DBStmt.h"

// Edited: 12/19/2000 - MG - added namespaces

BEGIN_DTL_NAMESPACE

HSTMT GetHSTMT(const DBStmt &stmt)
{
   return stmt.hstmt;
}

// errors deemed fatal to a DBStmt on Execute()
// causes the DBStmt to become invalidated
// all other errors do not validate the DBStmt

// anything bad due to the SQL Query String (unless if possibly due to
// bad parameters) will be considered fatal
const vector<string> DBStmt::FatalErrors = DBStmt::BuildFatalErrorsList();


END_DTL_NAMESPACE
