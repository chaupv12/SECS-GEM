/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// abstraction for UPDATES
// nested class of DBView
// Initial: 9/8/2000 - MG
// Edited: 12/19/2000 - MG - added namespaces

#ifndef _UPDATE_ITERATOR_H
#define _UPDATE_ITERATOR_H

#include "std_inc.h"
#include "iterator.h"
#include "DBView.h"

BEGIN_DTL_NAMESPACE

// abstraction for UPDATES
template<class DataObj, class ParamObj = DefaultParamObj<DataObj> >
  class DB_update_iterator :
     public DB_iterator_with_cols<DataObj, ParamObj>,
#ifndef __SGI_STL_PORT
	 public iterator<output_iterator_tag, DataObj, ptrdiff_t>
#else
	 // not sure why STLport not recognizing the standard iterator tag
	 // when used in algorithms like copy(_InputIter __first, _InputIter __last, _OutputIter __result)
	 // use STLport specific alternative
	 public forward_iterator<DataObj, ptrdiff_t>
#endif
{
private:
    InsValWrap<DataObj> InsValidate;
    bool validRowbuf; // was previous object valid?

	// call this function to execute the update
	// returns number of rows updated
	// to perform another update, change the necessary data and parameter values
	// and then make another call to ExecUpdate() to perform that update

	// exception-safety questionable
	int ExecUpdate()
	{
		    if (!IsReady())
	    	    open();

		    if (bad())
			{
			  throw DBException("DBView::delete_iterator::ExecDelete()",
				"iterator tested bad!", NULL, NULL);
			}
			
			if (!validRowbuf)
				return (lastCount = 0);

			int updatedRows = 0;

			
			try
			{
			   // propagate STL strings to their strbufs for proper binding
			   boundIOs.PropagateToSQL();
			   stmt.Execute();
			}
			catch (RootException &ex)
			{
				if (stmt.valid())
					setstate(failbit);
				else
					setstate(badbit);

				dtl_ios_base::MeansOfRecovery error_action =
					io_handler(ex, *this, *(pRowbuf.get()), *pParambuf);

				// what to do in case of REPERFORM_OPERATION???
				switch (error_action)
				{
				case dtl_ios_base::THROW_EXCEPTION: throw;
				case dtl_ios_base::SUPPRESS_ERROR: return (lastCount = 0);
				}

			}

			validRowbuf = false; // may write out only once per operator++()

			// object becomes inconsistent if this line fails
			try
			{
				updatedRows = stmt.RowCount();
			}
			catch (RootException &ex)
			{
				if (stmt.valid())
					setstate(failbit);
				else
					setstate(badbit);

				dtl_ios_base::MeansOfRecovery error_action =
					io_handler(ex, *this, *(pRowbuf.get()), *pParambuf);

				// what to do in case of REPERFORM_OPERATION???
				switch (error_action)
				{
				case dtl_ios_base::THROW_EXCEPTION: throw;
				case dtl_ios_base::SUPPRESS_ERROR: return (lastCount = 0);
				}
			}

			// count member is *cumulative* number of rows updated so far
			// do things this way in order to stay consistent with the other
			// DB iterator classes
			count += updatedRows;
			clear();
			return (lastCount = updatedRows);	
	}

public:
    DB_update_iterator() : DB_iterator_with_cols<DataObj, ParamObj>(), 
		InsValidate(DefaultInsValidate<DataObj>()), validRowbuf(false)
	{ }

    DB_update_iterator(const DBView<DataObj, ParamObj> &view) :
			DB_iterator_with_cols<DataObj, ParamObj>(view, UPDATE),
			InsValidate(view.GetInsVal()), validRowbuf(false)
			{ }

	// copy constructor and assignment operator required for Assignable property
	DB_update_iterator(const DB_update_iterator<DataObj, ParamObj> &up_it) : 

		DB_iterator_with_cols<DataObj, ParamObj>(up_it),
			InsValidate(up_it.InsValidate), validRowbuf(up_it.validRowbuf)
	{ }

	// exception-safe swap()
	void swap(DB_update_iterator<DataObj, ParamObj> &other)
	{
		DB_iterator_with_cols<DataObj, ParamObj>::swap(other);
		std::swap(InsValidate, other.InsValidate);
		std::swap(validRowbuf, other.validRowbuf);
	}

	// exception-safe assignment
	DB_update_iterator<DataObj, ParamObj> &
		operator=(const DB_update_iterator<DataObj, ParamObj> &other)
	{
		if (this != &other)
		{
			DB_update_iterator<DataObj, ParamObj> temp(other);
			swap(temp);
		}

		return *this;
	}

	// commit updates from this updater and clean up
	virtual ~DB_update_iterator()
	{ }

	// return a proxy
	// exception-safe
	DB_update_iterator<DataObj, ParamObj> &
		operator*()
	{
		return *this;
	}

	// proxy paradigm used to be able to perform InsValidate()
	// on the rowbuf held by the iterator
	// exception-safety dependent on GetRowbufPtr(), InsValidate(),
	// and DataObj::operator=()
	DB_update_iterator<DataObj, ParamObj> &
		operator=(const DataObj &data)
	{

		CountedPtr<DataObj> pData = NULL;
		
		try
		{ 
		   pData = GetRowbufPtr();
		   *pData = data; // assign data to internal rowbuf

	
			// if user specified a InsVal, apply it
			if (!InsValidate(*pData))
			{
				validRowbuf = false;

				if (stmt.valid())
					setstate(failbit);
				else
					setstate(badbit);

				throw DBException("DBView::update_iterator::operator=(const DataObj &)",
							  "InsValidate() failed on statement \"" +
							  stmt.GetQuery() + "\"!", NULL, NULL);
			}

		}
		catch (RootException &ex)
		{
			dtl_ios_base::MeansOfRecovery error_action =
				io_handler(ex, *this, *(pRowbuf.get()), *pParambuf);

			// what to do for REPERFORM_OPERATION?
			switch (error_action)
			{
			case dtl_ios_base::THROW_EXCEPTION: throw;
			case dtl_ios_base::SUPPRESS_ERROR: return *this;
			}

		}

		validRowbuf = true;
		clear();
		return *this;
	}

#if 0 // replaced by proxy code
	// get data object so user can specify what data (columns) to update
	DataObj &operator*()
	{
	   return *GetRowbufPtr();
	}
#endif

	// execute the update for the referenced DataObj and preincrement
	// IO handler logic is in ExecUpdate()
	DB_update_iterator<DataObj, ParamObj> &operator++()
	{
	   ExecUpdate(); // ExecUpdate() will open() the iterator if necessary
	   return *this;
	}
     
	// execute the update for the referenced DataObj and postincrement
	inline const DB_update_iterator<DataObj, ParamObj> operator++(int) // const to prevent iterator++++
	{
	   DB_update_iterator<DataObj, ParamObj> oldValue(*this);
	   ++(*this);
	   return oldValue;
	}
};

// builds the postfix clause for update of the fields listed in boundIOs
inline pair<string, vector<string> > PostfixForUpdate(const BoundIOs &boundIOs)
{
   string postfix = "WHERE (";
   vector<string> orderOfParams;

   BoundIOs::const_iterator it = boundIOs.begin();
   // Doubles cannot be compared exactly via equality, therefore, it's a bad
   // idea to have them in a WHERE clause. Some databases such as MySQL are strict
   // about this and will fail on SQL_DOUBLE or SQL_FLOAT comparisons.
   // Here we try to do something sensible for these cases.
   // Compare within an epsilon of accuracy.
   if ((*it).second.GetTypeID() == C_DOUBLE || (*it).second.GetTypeID() == C_FLOAT)
	   postfix += "ABS(" + (*it).first + " - (?)) <= " + (*it).first + "/1000000 ";
   else
       postfix += (*it).first + " = (?) ";
   orderOfParams.push_back((*it).first);
   it++;

   while (it != boundIOs.end())
   {
	   postfix += " AND ";
	   if ((*it).second.GetTypeID() == C_DOUBLE || (*it).second.GetTypeID() == C_FLOAT)
			postfix += "ABS(" + (*it).first + " - (?)) <= " + (*it).first + "/1000000 ";
       else
			postfix += (*it).first + " = (?) ";
	   orderOfParams.push_back((*it).first);
	   it++;
   }

   postfix += ")";

   return pair<string, vector<string> >(postfix, orderOfParams);
}

END_DTL_NAMESPACE

#endif
