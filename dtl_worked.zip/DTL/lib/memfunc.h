/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// Provides function objects for pointer to member methods
// Initial: 10/12/2000 - MG
// Edited: 11/14/2000 - MG - inheriting MemFunException from RootException
// Edited: 12/19/2000 - MG - added namespaces

#ifndef _MEMFUNC_H
#define _MEMFUNC_H

#include "std_inc.h"
#include "RootException.h"

BEGIN_DTL_NAMESPACE

class MemFunException : public RootException
{
public:
	MemFunException(const string &meth, const string &msg) : 
		RootException(meth, msg, "MemFunException") { }

	// default behavior for what() is adequate
};

// *** Function objects ***

// Enclosing is the type of the enclosing class of the member function we're pointing to
template<class Enclosing> class MemFunctor0
{
public:
	typedef void (Enclosing::* memFuncPtr)(void); // pointer to member type needed
private:
	Enclosing *encl;	// enclosing object that the "bound pointer" is referring to 
	memFuncPtr memPtr;  // the actual pointer to member stored here
public:
	MemFunctor0() : encl(NULL), memPtr(NULL) { }

	// pass in the enclosing object and the pointer to the member
	MemFunctor0(Enclosing &e, memFuncPtr funcptr) : encl(&e), memPtr(funcptr) { }

	// invoke like function using operator()
	void operator()(void) const
	{
		if (memPtr == NULL || encl == NULL)
			throw MemFunException("MemFunctor0::operator()", "NULL functor");

		// actually binds the pointer to member to an object for a single call to the
		// method we're pointing to itself and calls that method
		(encl->*memPtr)();
	}

};

// Acts as a *bound* pointer to member that we can pass to the multiset constructor
// which expects either a function pointer or a function object

// Enclosing is the type of the enclosing class of the member function we're pointing to
template<class Enclosing, class Arg> class MemFunctor1
{
public:
	typedef void (Enclosing::* memFuncPtr)(Arg arg); // pointer to member type needed
private:
	Enclosing *encl;	// enclosing object that the "bound pointer" is referring to 
	memFuncPtr memPtr;  // the actual pointer to member stored here
public:
	MemFunctor1() : encl(NULL), memPtr(NULL) { }

	// pass in the enclosing object and the pointer to the member
	MemFunctor1(Enclosing &e, memFuncPtr funcptr) : encl(&e), memPtr(funcptr) { }

	// invoke like function using operator()
	void operator()(Arg arg) const
	{
		if (memPtr == NULL || encl == NULL)
			throw MemFunException("MemFunctor1::operator()", "NULL functor");

		// actually binds the pointer to member to an object for a single call to the
		// method we're pointing to itself and calls that method
		(encl->*memPtr)(arg);
	}

};

// Enclosing is the type of the enclosing class of the member function we're pointing to
template<class Enclosing, class Arg1, class Arg2> class MemFunctor2
{
public:
	typedef void (Enclosing::* memFuncPtr)(Arg1 arg1, Arg2 arg2);
		// pointer to member type needed
private:
	Enclosing *encl;	// enclosing object that the "bound pointer" is referring to 
	memFuncPtr memPtr;  // the actual pointer to member stored here
public:
	MemFunctor2() : encl(NULL), memPtr(NULL) { }

	// pass in the enclosing object and the pointer to the member
	MemFunctor2(Enclosing &e, memFuncPtr funcptr) : encl(&e), memPtr(funcptr) { }

	// invoke like function using operator()
	void operator()(Arg1 arg1, Arg2 arg2) const
	{
		if (memPtr == NULL || encl == NULL)
			throw MemFunException("MemFunctor2::operator()", "NULL functor");

		// actually binds the pointer to member to an object for a single call to the
		// method we're pointing to itself and calls that method
		(encl->*memPtr)(arg1, arg2);
	}

};

// Enclosing is the type of the enclosing class of the member function we're pointing to
template<class Enclosing, class Ret> class MemFunctor0WithRet
{
public:
	typedef Ret (Enclosing::* memFuncPtr)(void); // pointer to member type needed
private:
	Enclosing *encl;	// enclosing object that the "bound pointer" is referring to 
	memFuncPtr memPtr;  // the actual pointer to member stored here
public:
	MemFunctor0WithRet() : encl(NULL), memPtr(NULL) { }

	// pass in the enclosing object and the pointer to the member
	MemFunctor0WithRet(Enclosing &e, memFuncPtr funcptr) : encl(&e), memPtr(funcptr) { }

	// invoke like function using operator()
	Ret operator()(void) const
	{
		if (memPtr == NULL || encl == NULL)
			throw MemFunException("MemFunctor0WithRet::operator()", "NULL functor");

		// actually binds the pointer to member to an object for a single call to the
		// method we're pointing to itself and calls that method
		return (encl->*memPtr)();
	}

};




// Enclosing is the type of the enclosing class of the member function we're pointing to
template<class Enclosing, class Arg, class Ret> class MemFunctor1WithRet
{
public:
	typedef Ret (Enclosing::* memFuncPtr)(Arg arg); // pointer to member type needed
private:
	Enclosing *encl;	// enclosing object that the "bound pointer" is referring to 
	memFuncPtr memPtr;  // the actual pointer to member stored here
public:
	MemFunctor1WithRet() : encl(NULL), memPtr(NULL) { }

	// pass in the enclosing object and the pointer to the member
	MemFunctor1WithRet(Enclosing &e, memFuncPtr funcptr) : encl(&e), memPtr(funcptr) { }

	// invoke like function using operator()
	Ret operator()(Arg arg) const
	{
		if (memPtr == NULL || encl == NULL)
			throw MemFunException("MemFunctor1WithRet::operator()", "NULL functor");

		// actually binds the pointer to member to an object for a single call to the
		// method we're pointing to itself and calls that method
		return (encl->*memPtr)(arg);
	}

};

// Enclosing is the type of the enclosing class of the member function we're pointing to
template<class Enclosing, class Arg1, class Arg2, class Ret> class MemFunctor2WithRet
{
public:
	typedef Ret (Enclosing::* memFuncPtr)(Arg1 arg1, Arg2 arg2);
		// pointer to member type needed
private:
	Enclosing *encl;	// enclosing object that the "bound pointer" is referring to 
	memFuncPtr memPtr;  // the actual pointer to member stored here
public:

	MemFunctor2WithRet() : encl(NULL), memPtr(NULL) { }

	// pass in the enclosing object and the pointer to the member
	MemFunctor2WithRet(Enclosing &e, memFuncPtr funcptr) : encl(&e), memPtr(funcptr) { }

	// invoke like function using operator()
	Ret operator()(Arg1 arg1, Arg2 arg2) const
	{
		if (memPtr == NULL || encl == NULL)
			throw MemFunException("MemFunctor2WithRet::operator()", "NULL functor");

		// actually binds the pointer to member to an object for a single call to the
		// method we're pointing to itself and calls that method
		return (encl->*memPtr)(arg1, arg2);
	}

};

END_DTL_NAMESPACE

#endif
