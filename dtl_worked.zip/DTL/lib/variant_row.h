/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// (C) 2000, Fernando Luis Cacciola Carballal.
// (C) 2000, Modifications & Extensions, Corwin Joy & Michael Gradman
// Major modifications are addition of a typeId + casts from the variant
// to desired target types.  These casts are perhaps not completely type-safe
// but are a major convenience to end users.  As before, one can always examine
// the original and not cast if so desired.
// For our purposes, we also limited the set of types supported in order to get
// these cast operations.
//
// This material is provided "as is", with absolutely no warranty expressed
// or implied. Any use is at your own risk.
//
// Permission to use or copy this software for any purpose is hereby granted
// without fee, provided the above notices are retained on all copies.
// Permission to modify the code and to distribute modified code is granted,
// provided the above notices are retained, and a notice that the code was
// modified is included with the above copyright notice.
//
// Because Michael Gradman & Corwin Joy have modified this extensively from
// the original version, please contact us if you have any questions

#ifndef VARIANT_H
#define VARIANT_H

#include "bind_basics.h"
#include <bitset>

BEGIN_DTL_NAMESPACE

class variant_row ;
class variant_field;
class variant_t;

// needed for variant_t(const variant_field &vf) constructor
variant_t variant_val(const variant_field &vf);


// Note: Some compilers fail to explicitely instantiate member template functions:
// They won't compile: int n = my_variant.get<int>()
// One solution is to add an extra dummy argument to help name lookup.
//
// To work around this, some methods will have this
// extra argument. This extra argument is not used so it is declared as a const* so
// you can pass (T const*)NULL.
//


#ifdef _MSC_VER
  #pragma warning(disable: 4800) // 'int' : forcing value to bool 'true' or 'false' (performance warning)
#endif

#ifdef __GNUC__
  #define _GCC_CAST_BUG
#endif

// Class variant_t
// Encapsulates a value of arbitrary type.
// It can be constructed with values of any type without
// explicit casting. Its value can be retrieved by
// converting it to a copy of apropriate type.
// If an attempt is made to convert it to a type other than
// the type used with the constructor, invalid_argument is
// thrown.
// variant_t objects can be efficiently and safely copied
// without loosing the value and type.
//
// Original Mar 2000, Fernando Luis Cacciola Carballal.
//                      to avoid overload resolution problems.
//  
class variant_t
{
protected:

    // This base class provides polymorphism to Impl<>, due
    // to the virtual destructor.
    // It implements the reference counting over Impl<>.
    struct ImplBase
    {
      ImplBase() : refs ( 0 ) {}
      virtual ~ImplBase() {}
      void AddRef () { refs ++ ; }
      void Release() { refs -- ;
                       if ( refs == 0 )
                         delete this ;
                     }
      size_t refs ;
    } ;

    // An instance of Impl<T> is just a straight copy of a
    // value of type T, but re-typed as a polymorphic type.
    // As long as the copy constructor for T is properly
    // implemented, the value will be properly copied.
    template<typename T>
    struct Impl : ImplBase
    {
       Impl ( T const& v ) : data ( v ) {}
      ~Impl () {}
      T data ;
    } ;

    template<typename T>
    static Impl<T>* CastFromBase ( ImplBase* v , T const* =NULL )
    {
      // This upcast will fail if T is other than the T used
      // with the constructor of variant_t.
      Impl<T>* p = dynamic_cast<Impl<T>*> ( v ) ;
      if ( p == NULL )
        throw VariantException("variant_t::CastFromBase()",
           typeid(T).name()+string(" is not a valid type"));
      return p ;
    }

    ImplBase* data ;

	char typeId;

	// Generic cast operator for numeric types
	template<typename T> T numeric_cast(T dummy) const {
		switch (typeId) {
		case C_SHORT:  {short *dmy=NULL; return T(CastFromBase(data, dmy)->data);}
		case C_USHORT: {unsigned short *dmy=NULL; return T(CastFromBase(data, dmy)->data);}
		case C_INT: {int *dmy=NULL; return T(CastFromBase(data, dmy)->data);}
		case C_UINT: {unsigned int *dmy=NULL; return T(CastFromBase(data, dmy)->data);}
		case C_LONG: {long *dmy=NULL; return T(CastFromBase(data, dmy)->data);}
		case C_ULONG: {unsigned long *dmy=NULL; return T(CastFromBase(data, dmy)->data);}
		case C_DOUBLE: {double *dmy=NULL; return T(CastFromBase(data, dmy)->data);}
		case C_FLOAT: {float *dmy=NULL; return T(CastFromBase(data, dmy)->data);}
		case C_CHAR_STAR: {char * *dmy=NULL; return T(atof(CastFromBase(data, dmy)->data));}
		case C_STRING: {string *dmy=NULL; return T(atof(CastFromBase(data, dmy)->data.c_str()));}
		
		// eventually may add class capabilities to timestamp to pull out jdate here
		// case C_TIMESTAMP: 

		default:
			throw VariantException("variant_t::numeric_cast()",
			   typeid(T).name()+string(" cannot be cast to a numeric type"));
		}

	}

	// Map the class to our typeid enumeration
	template<class T> char find_typeid(const T &t) {
		// use RTTI to get the type of the object
		static const type_info &RTTI_self = typeid(variant_t);
		static string nameOfSelf = RTTI_self.name();
	    const type_info &RTTI = typeid(t);
	    string nameOfType = RTTI.name();
		string::size_type del = 6, pos;

		// remove any "const" descriptors from the type name
		while ((pos = nameOfType.find("const ", 0)) != string::npos) {
			nameOfType.erase(pos, del);
		}

		if (nameOfType == nameOfSelf)
			return 0;

	    // make sure the type is in the ETI map!  If not, 
		// a default TypeTranslation object will be built, with the
		// TypeComplexity as invalid
		// if we check the TypeComplexity and it is TYPE_INVALID , we've got an exception!
		TypeTranslation &tt = SQL_types_to_C[nameOfType];

		if (tt.complexity == TypeTranslation::TYPE_INVALID)
		{
		  throw VariantException("variant_t::find_typeid()",
			 typeid(T).name()+string(" is not a valid type"));
		}

		return tt.typeId;
	}

	template<typename T> void private_construct(const T &other)
    { 
		data = new Impl<T>(other);
		data->AddRef() ; 
		typeId = find_typeid(other);
	}

  	void private_construct(const variant_t &other) {
		if (other.data != NULL )
			other.data->AddRef();
		data = other.data;
		typeId = other.typeId;
	}

public :

   variant_t() : data ( NULL ) , typeId(0) {}

  // This member template constructor allows you to
  // instance a variant_t object with a value of any type.
  template<typename T> explicit variant_t (const T & v)
  {private_construct(v);}

  variant_t (const variant_t & v)
  {private_construct(v);}

  variant_t (const variant_field &vf)
  {
	private_construct(variant_val(vf));
  }

  variant_t(void *p, const TypeTranslation &f) {
		typeId = f.typeId;
		switch (typeId) {
		case C_SHORT:  data = new Impl<short>(*((short *)p));break;
		case C_USHORT: data = new Impl<unsigned short>(*((unsigned short *)p));break;
		case C_INT: data = new Impl<int>(*((int *)p));break;
		case C_UINT: data = new Impl<unsigned int>(*((unsigned int *)p));break;
		case C_LONG: data = new Impl<long>(*((long *)p));break;
		case C_ULONG: data = new Impl<unsigned long>(*((unsigned long *)p));break;
		case C_DOUBLE: data = new Impl<double>(*((double *)p));break;
		case C_FLOAT: data = new Impl<float>(*((float *)p));break;
		case C_CHAR_STAR: data = new Impl<char *>(*((char **)p));break;
		case C_STRING: data = new Impl<string>(*((string *)p));break;
		case C_TIMESTAMP: data = new Impl<struct tagTIMESTAMP_STRUCT>(*((struct tagTIMESTAMP_STRUCT  *)p));break;
		
		default:
			throw VariantException("variant_t::variant_t()",
			  string("Invalid field type passed to variant_t(void *p, TypeTranslation &f)"));
			data = NULL;
			//throw TYPE_NOT_SUPPORTED;
		}
		data->AddRef();
	}

  ~variant_t()
     { if ( data != NULL )
         data->Release() ;
     }

  template<typename T> const variant_t & operator=(const T &other) {
		if (((void *)this) != ((void *)&other)) {
			if (data != NULL)
				data->Release();
			private_construct(other);
		}
		return *this;
	}

  // exception-safe swap()
  void swap(variant_t &other)
  {
	  std::swap(data, other.data);
	  std::swap(typeId, other.typeId);
  }

  // exception-safe assignment
  variant_t &operator=(const variant_t &other)
  {
	  if (this != &other)
	  {
		variant_t temp(other);
		swap(temp);
	  }

	  return *this;
  }

// This generic conversion operator let you retrieve
// the value held.
// We disabled this because we wanted to created specialized versions
// that could also supply conversions when needed.
// To avoid template specialization conflicts, it
// returns an instance of type T, which will be a COPY
// of the value contained.
// template<typename T> operator T () const
//   { return CastFromBase<T>( data )->data ; }
//
//   template<typename T> operator T () const
//    {T *dmy; return CastFromBase(data, dmy)->data ; }

// cast of thousands
// couldn't get template of the form template<T> operator T() to work w/o ambiguity.

#ifndef  _GCC_CAST_BUG
  operator short int() const {
		return numeric_cast(short int());
	}
	operator unsigned short int() const {
		return numeric_cast(unsigned short int());
	}
	operator long int() const {
		return numeric_cast(long int());
	}
	operator unsigned long int() const {
		return numeric_cast(unsigned long int());
	}
	operator unsigned int () const {
		return numeric_cast(unsigned int());
	}
#else
     // gnu C++ 2.95 does not like the casts above
     // for some reason does not recognize e.g. short int as a
     // single typename.  Hacky workaround to fix
	template<typename TT> struct integral_type {
	   TT si;
	   integral_type() : si(0) {};
	   template<typename UU> integral_type(UU t)  {
		   si = static_cast<TT>(t);
	   }
	};

	operator short int() const {
		integral_type<short int> s, out;
		out =   numeric_cast(s);
		return out.si;
	}

	operator unsigned short int() const {
		integral_type<unsigned short int> s, out;
		out =   numeric_cast(s);
		return out.si;
	}

	operator long int() const {
		integral_type<long int> s, out;
		out =   numeric_cast(s);
		return out.si;
	}

	operator unsigned long int() const {
		integral_type<unsigned long int> s, out;
		out =   numeric_cast(s);
		return out.si;
	}

	operator unsigned int() const {
		integral_type<unsigned int> s, out;
		out =   numeric_cast(s);
		return out.si;
	}
	
#endif

	operator int () const {
		return numeric_cast(int());
	}
	
	operator float () const {
		return numeric_cast(float());
	}
	operator double () const {
		return numeric_cast(double());
	}

	// operator for strings
	string get_string() const {
		ostrstream tostr;

		switch (typeId) {
		case C_SHORT: {short *dmy=NULL; tostr << CastFromBase(data, dmy)->data; break;}
		case C_USHORT: {unsigned short *dmy=NULL; tostr << CastFromBase(data, dmy)->data; break;}
		case C_INT: {int *dmy=NULL; tostr << CastFromBase(data, dmy)->data; break;}
		case C_UINT: {unsigned int *dmy=NULL; tostr << CastFromBase(data, dmy)->data; break;}
		case C_LONG: {long *dmy=NULL; tostr << CastFromBase(data, dmy)->data; break;}
		case C_ULONG: {unsigned long *dmy=NULL; tostr << CastFromBase(data, dmy)->data; break;}
		case C_DOUBLE: {double *dmy=NULL; tostr << CastFromBase(data, dmy)->data; break;}
		case C_FLOAT: {float *dmy=NULL; tostr << CastFromBase(data, dmy)->data; break;}
		case C_CHAR_STAR: {char * *dmy=NULL; tostr << CastFromBase(data, dmy)->data; break;}
		case C_STRING: {string *dmy=NULL; tostr << CastFromBase(data, dmy)->data; break;}
		
		// eventually add date library capabilities to convert string to time
		case C_TIMESTAMP: {TIMESTAMP_STRUCT *dmy = NULL; tostr << CastFromBase(data, dmy)->data; break; }

		default:
			throw VariantException("variant_t::operator string()",
			  string("this variant type cannot be cast to a string type"));
			
		}

		tostr << ends;
		return tostr.str();
	}


	operator string () const {
	 	  return get_string();
	};


	operator char * () const {
		string s;
		s = get_string();
		char *c = new char[s.size()+1];
		if (c != NULL)
			strcpy(c, s.c_str());
		return c;
	};

	operator char() const {
		switch (typeId) {
		case C_SHORT:  {short *dmy=NULL; return char(CastFromBase(data, dmy)->data);}
		case C_USHORT: {unsigned short *dmy=NULL; return char(CastFromBase(data, dmy)->data);}
		case C_INT: {int *dmy=NULL; return char(CastFromBase(data, dmy)->data);}
		case C_UINT: {unsigned int *dmy=NULL; return char(CastFromBase(data, dmy)->data);}
		case C_LONG: {long *dmy=NULL; return char(CastFromBase(data, dmy)->data);}
		case C_ULONG: {unsigned long *dmy=NULL; return char(CastFromBase(data, dmy)->data);}
		case C_DOUBLE: {double *dmy=NULL; return char(CastFromBase(data, dmy)->data);}
		case C_FLOAT: {float *dmy=NULL; return char(CastFromBase(data, dmy)->data);}
		case C_CHAR_STAR: {char * *dmy=NULL; return char(*(CastFromBase(data, dmy)->data));}
		case C_STRING: {string *dmy=NULL; return char(*(CastFromBase(data, dmy)->data.c_str()));}
		
		// eventually may add class capabilities to timestamp to pull out jdate here
		// case C_TIMESTAMP: 
		
		default:
			throw VariantException("variant_t::operator char()",
			  string("this variant type cannot be cast to a char type"));
	
			return char();
		}

	}

	operator struct tagTIMESTAMP_STRUCT () const {
		struct tagTIMESTAMP_STRUCT *dmy=NULL; return CastFromBase(data, dmy)->data;
	}


  // With expressions of the form: int a = my_variant ,
  // the compiler needs to take the template argument T
  // from the type of the left side of the assigment.
  // Most compilers won't do that, so you might need this
  // non-operator form, as in:
  // int a = my_variant.get<int>();
  // This forms returns a REFERENCE and not a COPY, which
  // will be significant in some cases.
  template<typename T> const T & get( T const* dmy =NULL ) const
    { return CastFromBase( data , dmy )->data ; }

  // This method can be used to test if this variant_t
  // holds a value of type T. It takes no arguments,
  // so it can only be used with a explicit template
  // instancing:
  //   variant_t var(3) ; if ( var.is_type<int>() ) ...
  template<typename T> bool is_type( T const* =NULL ) const
     { return typeid(*data)==typeid(Impl<T>); }

  // This method can be used to test if this variant_t
  // holds a value of type T.
  // It takes one argument, so it can be used with
  // a test variable of the desired type:
  //   int n=3; variant_t var(n) ;
  //   if ( var.is_type_as(n) ) ...
  template<typename T> bool is_type_as(T const& v) const
    { return typeid(*data)==typeid(Impl<T>); }

  template<typename T> bool is_type_as(T const* v) const
    { return typeid(*data)==typeid(Impl<T>); }

  // This method returns type enumeration value
  char type() const {
	  return typeId;
  }

	// Map the class to our typeid enumeration
	TypeTranslation type_translation() {
		ETI_Map::iterator i = SQL_types_to_C.begin();
		for(; i != SQL_types_to_C.end(); i++)
			if (i->second.typeId == typeId)
				break;
		if (i != SQL_types_to_C.end())
		{
		  throw VariantException("variant_t::type()",
			 string("Internal error.  Invalid type encountered in typeId member."));
		}

		return i->second;
	}
  
} ;


//
// non-member auxiliary functions.
// Needed for compilers that fail with: my_variant.get<int>().
//

// usage: int n = variant_cast<int>(my_variant);
template<typename T>
T variant_cast  (const variant_t& v)
{
     return v.get((T const*)(NULL));
}

// usage: bool b = variant_is_type_as(my_variant,my_type_variable);
//
// NOTE: For some reason MSVC fails to properly instantiate this functions unless
// the 'T const&' argument is added.
template<typename T>
bool variant_is_type_as (const variant_t& v, T const& t)
{
  return v.is_type_as(t);
}
template<typename T>
bool variant_is_type_as (const variant_t& v, T const* t)
{
  return v.is_type_as(t);
}

// powerful stream operator for variant_t's!!!!
inline ostream &operator<<(ostream &o, const variant_t &v)
{
  o << v.get_string();
  return o;
}

// this module defines basic variant types for dynamic row binding
// Initial: 11/16/2000 - CJ
class variant_row_fields {
public:
	vector<TypeTranslation> types;
	vector<string> names;
	vector<size_t> offsets;
	size_t row_size;

	variant_row_fields() : types(), names(), offsets(), row_size(0) { }

	// Construct form fields & names, but compute offsets from scratch
	variant_row_fields(vector<TypeTranslation> &f,	vector<string> &n) : types(f), names(n){
		vector<TypeTranslation>::iterator i = types.begin();
		row_size = 0;
		for (; i != types.end(); i++) {
			offsets.push_back(row_size);
			row_size += i->size;
		}
	}

	// exception-safe swap()
	void swap(variant_row_fields &other)
	{
		std::swap(row_size, other.row_size);
		types.swap(other.types);
		names.swap(other.names);
		offsets.swap(other.offsets);
	}

	// exception-safe assignment
	variant_row_fields &operator=(const variant_row_fields &other)
	{
		if (this != &other)
		{
			variant_row_fields temp(other);
			swap(temp);
		}

		return *this;

	}

	// accessors
	vector<TypeTranslation> GetTypes() const   { return types;		  }
	vector<string>			GetNames() const   { return names;		  }
	size_t		 			size() const { return names.size(); }

    // comparison operators
	friend bool operator==(const variant_row_fields &vf1,
						   const variant_row_fields &vf2)
	{
	   return vf1.types == vf2.types && vf1.names == vf2.names &&
			  vf1.offsets == vf2.offsets && vf1.row_size == vf2.row_size;
	}

	friend bool operator!=(const variant_row_fields &vf1,
						   const variant_row_fields &vf2)
    {
	   return !(vf1 == vf2);
	}
};


class variant_field {
friend variant_row;
	variant_t m_val;
	variant_row *p_row;
	int m_col;
	bool m_IsNull;
public:
	
	variant_field() : m_val(), p_row(NULL), m_col(0), m_IsNull(false)  {}
	variant_field(const variant_field &other) : p_row(other.p_row), 
		m_col(other.m_col), m_IsNull(other.m_IsNull), m_val(other.m_val){}
	variant_field(const variant_t &v, variant_row *row, int field, const bool b = false) :
		p_row(row), m_col(field), m_IsNull(b), m_val(v) {	}

	// exception-safe swap()
	void swap(variant_field &other)
	{
		m_val.swap(other.m_val);
		std::swap(p_row, other.p_row);
		std::swap(m_col, other.m_col);
		std::swap(m_IsNull, other.m_IsNull);
	}

	// exception-safe assignment
	variant_field &operator=(const variant_field &other)
	{
		if (this != &other)
		{
			variant_field temp(other);
			swap(temp);
		}

		return *this;
	}

	// Special assignment operator - cascade changes back to parent row
	template<typename T> const variant_field & operator=(const T &other) {
		if (((void *)this) != ((void *)&other)) {
			m_val = other;
			p_row->replace(*this);
		}
		return *this;
	}


    // cast of thousands again!!!!
	// couldn't get template of the form template<T> operator T() to work w/o ambiguity.
	operator short () const {
		return m_val.operator short();
	}
	operator unsigned short () const {
		return (unsigned short) m_val;
	}
	operator long () const {
		return (long) m_val;
	}
	operator unsigned long () const {
		return (unsigned long) m_val;
	}
	operator unsigned int () const {
		return (unsigned int) m_val;
	}
	operator int () const {
		return (int) m_val;
	}
	operator float () const {
		return (float) m_val;
	}
	operator double () const {
		return (double) m_val;
	}

	operator string() const {
		return m_val.get_string();
	}

	operator char() const
	{
		return (char) m_val;

	}

	operator char*() const
	{
		return (char *) m_val;
	}

	operator struct tagTIMESTAMP_STRUCT() const
	{
		return (struct tagTIMESTAMP_STRUCT) m_val;
	}

	operator variant_t() const
	{
		return m_val;
	}

	// end of cast of thousands

	bool IsNull() const {return m_IsNull;}

	friend variant_t variant_val(const variant_field &vf)
	{
		return vf.m_val;
	}

  // needed to resolve ambiguity for casts
  string get_string() const
  {
    return m_val.get_string();
  }
	// returns an enumeration listing the type of the variant data
	char type() const {
		return m_val.type();
	}

	// This method can be used to test if this variant_t
    // holds a value of type T. It takes no arguments,
    // so it can only be used with a explicit template
    // instancing:
    //   variant_t var(3) ; if ( var.is_type<int>() ) ...
    template<typename T> bool is_type( T const*t =NULL ) const {
		return m_val.is_type(t);
	}
};


// stream operator for variant_field's
inline ostream &operator<<(ostream &o, const variant_field &vf)
{
   if (!vf.IsNull())
		o << (variant_t) vf;
   else
	    o << string("<NULL>");
   return o;
}

class DynamicRowBCA;

// Class to hold a row of data as a variant set of fields
#define MAX_VARIANT_ROW_FIELDS 512

class variant_row {

friend variant_field;
friend DynamicRowBCA;

private: 

	bitset<MAX_VARIANT_ROW_FIELDS> b_IsNull;
	CountedPtr<variant_row_fields> p_row_fields;
	char *p_data;

	void init(void) {
		p_data = (char *)malloc(p_row_fields->row_size);
		if (p_data != NULL) {
			memset(p_data, 0, p_row_fields->row_size);
			init_fields();	
		}
	}

	void init_field(void *v, int typeId) {
		// construct individual fields that are not primitives
		switch (typeId) {
			case C_STRING:
				new(v) string("");
			break;
		}

	}

	void copy_construct_field(void *dest, const void *src, int typeId) {
		// copy construct individual fields that are not primitives
		// N.B.!! objects to construct here should not make use of their
		// absolute address as part of construction, otherwise variant_row
		// assignment operator will not work
		switch (typeId) {
			case C_STRING:
				string *pstring = (string *)(src); 
				new(dest) string(*pstring);
			break;
		}
		
	}

	void destroy_field(void *v, int typeId) {
		// destruct individual fields that are not primitives
		try {
			switch (typeId) {
				case C_STRING:
					((string *)v)->~string();
					break;
			}
		}
		catch(...) {}
	}

	void init_fields(void) {
		// construct individual fields that are not primitives
		if (p_data == NULL)
			return;
		vector<TypeTranslation>::iterator i, b;
		b = p_row_fields->types.begin();
		for (i = b; i != p_row_fields->types.end(); i++) {
			init_field(p_data + p_row_fields->offsets[i-b], i->typeId);
		}
	}

	void destroy_fields(void) {
		// construct individual fields that are not primitives
		if (p_data == NULL)
			return;
		vector<TypeTranslation>::iterator i, b;
		b = p_row_fields->types.begin();
		for (i = b; i != p_row_fields->types.end(); i++) {
			destroy_field(p_data + p_row_fields->offsets[i-b], i->typeId);
		}
	}


	void destroy(void) {
		if (p_data) {
			if (p_row_fields)
				destroy_fields();
			free(p_data);
			p_data = NULL;
		}		
	}


	void copy_construct_fields(const variant_row &other) {
		// copy construct individual fields that are not primitives
		if (p_data == NULL || other.p_data == NULL)
			return;
		vector<TypeTranslation>::const_iterator i, b;
		b = other.p_row_fields->types.begin();
		for (i = b; i != other.p_row_fields->types.end(); i++) {
				copy_construct_field(p_data + other.p_row_fields->offsets[i-b], other.p_data + other.p_row_fields->offsets[i-b], 
				i->typeId);
		}
	}

	// replace field value
	void replace(const variant_field &field) {
		void *p = p_data + p_row_fields->offsets[field.m_col];
    char typeId = p_row_fields->types[field.m_col].typeId;
		switch (typeId) {
	  // again g++ does not like these casts
		case C_SHORT: *((short *)p) = (short)field.m_val; break;
		case C_USHORT: *((unsigned short *)p) = (unsigned short)field.m_val; break;
		case C_UINT: *((unsigned int *)p) = (unsigned int)field.m_val; break;
		case C_ULONG: *((unsigned long *)p) = (unsigned long)field.m_val; break;
		case C_LONG: *((long *)p) = (long)field.m_val; break;
		case C_INT: *((int *)p) = (int)field.m_val; break;
		case C_DOUBLE: *((double *)p) = (double)field.m_val; break;
		case C_FLOAT: *((float *)p) = (float)field.m_val; break;
		case C_TIMESTAMP: *((struct tagTIMESTAMP_STRUCT *)p) = (struct tagTIMESTAMP_STRUCT)field.m_val; break;
		case C_CHAR_STAR: *((char * *)p) = (char *)field.m_val; break;

	  // need to use char* for the case below to work around g++ error
		case C_STRING: *((string *)p) = field.m_val.get_string(); break;
		default:
			 throw VariantException("variant_row::replace()",
			   string("Invalid variant data assigned to row."));
		}
	}

	vector<TypeTranslation>::const_iterator find_field(const string &f) const {
		vector<string>::const_iterator i;
		vector<TypeTranslation>::const_iterator j;
		j = p_row_fields->types.begin();
		for(i = p_row_fields->names.begin(); i !=  p_row_fields->names.end(); i++, j++)
			if (*i == f)
				return j;
		return j; // return end() if not found
	}

public:

	variant_row() : p_row_fields(NULL), p_data(NULL), b_IsNull(true) {	}

	variant_row(vector<TypeTranslation> &types, vector<string> &names) :
	  p_row_fields(new variant_row_fields(types, names)) {
		init();
	}

	variant_row(const variant_row &other) : b_IsNull(other.b_IsNull) {
		if (other.p_row_fields) {
			p_data = (char *)malloc(other.p_row_fields->row_size * sizeof(char));
			if (p_data != NULL) {
				memcpy(p_data, other.p_data, other.p_row_fields->row_size);
				copy_construct_fields(other);
			}
			p_row_fields = other.p_row_fields;
		} else {
			p_row_fields = NULL;
			p_data = NULL;
		}
	}

	char *data_ptr() const{
		return p_data;
	}

	// exception-safe swap()
	void swap(variant_row &other)
	{
		p_row_fields.swap(other.p_row_fields);
		std::swap(p_data, other.p_data);
		std::swap(b_IsNull, other.b_IsNull);
	}

	// Slightly complicated assignment operator for two reasons
	// 1. We wanted it to be exception safe
	// 2. If the variant_rows have the same variant_row_fields we need to copy the contents
	// and not change the address so that DynamicDBView can still function
	// with variant_row parameters
	//
    const variant_row & operator=(const variant_row &other) {
       if (this != &other) {	 
		  if (other.p_data != NULL && other.p_row_fields) {
				char *new_data = (char *)malloc(other.p_row_fields->row_size * sizeof(char));
				if (new_data == NULL) 
					throw VariantException("variant_row::operator =", string("Out of memory for assigning row."));
				char *p_data_backup = p_data;
				p_data = new_data;
				try {
					 memcpy(p_data, other.p_data, other.p_row_fields->row_size);
					 copy_construct_fields(other);
				}
				catch(...) {
					p_data = p_data_backup; // rollback changes
					free(new_data);
					throw;
				}
				p_data = p_data_backup;
			    // this logic is needed to properly ensure that if the
			    // variant_row_fields are identical, then we leave the old pointers intact
			    // code is more complex as we must properly handle NULL pointers
                bool bCopyData = false;

			    if (p_row_fields == other.p_row_fields)
				   bCopyData = true;
			    else // pointers are different but contents may be the same
				  if (p_row_fields  && other.p_row_fields)
						if (*p_row_fields == *other.p_row_fields)
						     bCopyData = true;
				
				if (bCopyData && p_data != NULL) {
					destroy_fields();
					memcpy(p_data, new_data, other.p_row_fields->row_size);
					free(new_data);
				} else {
					destroy();
					p_data = new_data;
				}
		  }
		  p_row_fields = other.p_row_fields;
          b_IsNull = other.b_IsNull;
	   }
       return *this;
	}

 
	// return row field by name
	variant_field operator[](const string &f) {
		vector<TypeTranslation>::const_iterator i = find_field(f);
		if (p_data == NULL) {
			throw VariantException("variant_row::operator[]()",
			string("Invalid field name requested from NULL variant_field class."));
		}
   
		if (i != p_row_fields->types.end()) {
			ptrdiff_t diff = 0;
			size_t mem_offset = 0;
			void *p = NULL;
			const TypeTranslation *pt = NULL;

			diff = i - p_row_fields->types.begin();

			mem_offset =  p_row_fields->offsets[diff];

			p = p_data + mem_offset;

			pt = &(*i);
			bool IsNull = b_IsNull[diff];
			variant_t v(p, *pt);
			return variant_field(v, this, diff, IsNull);
			
		}
		// throw UNKNOWN field name!
		throw VariantException("variant_row::operator[]()",
			string("Invalid field name requested from row class."));
		return variant_field(variant_t(0), NULL, 0, false);

	}

	// return row field by number
	variant_field operator[](int i) {
		// STL should throw here if field # out of bounds
		if (p_data == NULL) {
			throw VariantException("variant_row::operator[]()",
			string("Invalid field name requested from NULL variant_field class."));
		}
		void *p = p_data + p_row_fields->offsets[i];
		bool IsNull = b_IsNull[i];
		return variant_field(variant_t(p, p_row_fields->types[i]), this, i, IsNull);
	}

	// return # of columns in row
	size_t size() const
	{
		return p_row_fields->size();
	}

	// return column names for the row
	vector<string> GetNames() const

	{
		return p_row_fields->GetNames();
	}

	// return type information for the columns in the row
	vector<TypeTranslation> GetTypes() const
	{
		return p_row_fields->GetTypes();
	}

	// used for debugging to print out contents of variant row as a string
	string Stringify() const 
	{
	   variant_row *this_ptr = const_cast<variant_row *>(this);

	   ostrstream result;

	   for (size_t i = 0; i < size(); i++)
	   {
		  result << (*this_ptr)[i] << ' ';
	   }
	   result << ends;

	   return result.str();

	}

	friend ostream &operator<<(ostream &o, const variant_row &vr)
	{
      o << vr.Stringify();
	  return o;
	}
	// mark the field with the given name as holding a NULL value
	void SetAsNull(const string &f) {
		vector<TypeTranslation>::const_iterator i = find_field(f);
		size_t n = i - p_row_fields->types.begin();
		b_IsNull.set(n);
	}

	friend char *data_ptr(const variant_row *vr)
	{
		return vr->data_ptr();
	}

	~variant_row()
	{
		destroy();
	}
};

template<class T> char *data_ptr(const T *t) {return (char *)t;}

END_DTL_NAMESPACE

#endif
