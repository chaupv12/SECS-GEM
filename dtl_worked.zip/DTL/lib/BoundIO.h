/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// class which abstracts the binding of columns and parameters
// Initial: ca. 9/5/2000 - MG
// Revised: 10/6/2000 - MG - added support for relative offsets
// Revised: 11/12/2000 - CJ - wrote faster GenericCmp function
// Edited: 12/19/2000 - MG - added namespaces

#ifndef _BOUNDIO_H
#define _BOUNDIO_H

#include "DB_Base.h"
#include "bind_basics.h"
#include "variant_row.h"

BEGIN_DTL_NAMESPACE

// extern const ETI_Map SQL_types_to_C;
class BoundIOs;

#if 0

class variant_row;
class variant_t;
#endif

char *data_ptr(variant_row &vr);


// class which abstracts the binding of columns and parameters
class BoundIO
{
  public:
	// either just use BoundCols to get the table names or bind the addresses as well
    enum BoundColMode { BIND_ADDRESSES, BIND_AS_INDICES };

    // what does the BoundIO structure map data to?
    enum BoundType { UNKNOWN, COLUMN, PARAM };

    // bind as columns or parameters?
    enum ColumnsOrParams { BIND_AS_COL, BIND_AS_PARAM };

  private:
	void *addr;				// absolute address of data
	ptrdiff_t offset;		// relative offset of this field from base address of its DataObj
							// or ParamObj where applicable

	SDWORD sqlType;
	SDWORD cType;
	string name;
	int    typeId;
	bool   IsPrimitive;
	SDWORD size;
	SDWORD bufferLength;
	CountedPtr<SDWORD> bytesFetched;

	bool IsVariantRow;		// is this a BoundIO built off a variant?
	BoundIOs *pBoundIOs;	// refers to BoundIOs that this object belongs to

	BoundColMode mode;	    // applies only to columns
						    // tablenames only or bind both names and addresses?
	
	BoundType bindingType;  // column or param???
	

	MemPtr strbuf;		   // needed for use with STL strings
						   // points to a buffer allocated
						   // for char * version of the string
						   // NULL for all other types


	static const size_t STRBUFLEN;

	static const int DATE_PRECISION;

	// workaround for compiler member specialization issue instead of
	// being able to specialize BoundIO::CopyMember(), we cheat
	// we wrote a specialization for variant_row and do nothing otherwise
	// the function below should never get called!
	template <class T> void CopyVariantRowMember(T &key, const variant_t & df) {
		NULL;
	}

	// form of CopyMember() for variant
	void CopyVariantRowMember(variant_row &vr, const variant_t &m)
	{
		vr[name] = m;
	}

  public:
	BoundIO() : addr(NULL), offset(0), name(""), sqlType(0), cType(0), typeId(0), size(0), 
		bufferLength(0), bytesFetched(), mode(BIND_ADDRESSES),
		bindingType(UNKNOWN), strbuf(),
		pBoundIOs(NULL), IsVariantRow(false) , IsPrimitive(false) { }

	BoundIO(const string &nm, BoundColMode bcMode, BoundType bt, BoundIOs &parentCollection) :
		addr(NULL), offset(0), name(nm), mode(bcMode), sqlType(0), cType(0), typeId(0),
			size(0), bufferLength(0), bytesFetched(), bindingType(bt),
			strbuf(), pBoundIOs(&parentCollection),
			IsVariantRow(false), IsPrimitive(false){ }

	BoundIO(BoundIOs &parentCollection, const string &nm, TypeTranslation &tt, void *field, void *base_addr, size_t base_size) :
		addr(NULL), offset(0), name(nm), mode(BIND_ADDRESSES), sqlType(0), cType(0), typeId(0),
			size(0), bufferLength(0), bytesFetched(), bindingType(COLUMN),
			strbuf(), pBoundIOs(&parentCollection),
			IsVariantRow(false), IsPrimitive(false)
		{
			
			InitFromField(tt, field, base_addr, base_size);
		}

	BoundIO(const BoundIO &boundIO) : addr(boundIO.addr), offset(boundIO.offset), name(boundIO.name),
		mode(boundIO.mode), sqlType(boundIO.sqlType), cType(boundIO.cType), typeId(boundIO.typeId), size(boundIO.size),
		bufferLength(boundIO.bufferLength), bytesFetched(boundIO.bytesFetched),
		bindingType(boundIO.bindingType), 
		pBoundIOs(boundIO.pBoundIOs), strbuf(boundIO.strbuf), IsVariantRow(boundIO.IsVariantRow),
		IsPrimitive(boundIO.IsPrimitive)
	{}

	// nothrow swap
	void swap(BoundIO &other) {
		std::swap(addr, other.addr);
		std::swap(sqlType, other.sqlType);
		std::swap(cType, other.cType);
		name.swap(other.name);
		std::swap(size, other.size);
		std::swap(bufferLength, other.bufferLength);
		std::swap(bytesFetched, other.bytesFetched);
		std::swap(bindingType, other.bindingType);
		std::swap(mode, other.mode);
		std::swap(offset, other.offset);
		std::swap(pBoundIOs, other.pBoundIOs);
		std::swap(IsVariantRow, other.IsVariantRow);
		strbuf.swap(other.strbuf);
		std::swap(typeId, other.typeId);
		std::swap(IsPrimitive, other.IsPrimitive);
	}

	// exception safe assignment
	BoundIO &operator=(const BoundIO &boundIO)
	{
	   
	   if (this != &boundIO)
	   {
		   BoundIO temp(boundIO);
		   swap(temp);
	   }

	   return *this;
	}
	

	BoundColMode GetBoundColMode() const { return mode; }

	BoundType GetBindingType() const { return bindingType; }

	bool IsParam()  const { return bindingType == PARAM;   }
	bool IsColumn() const { return bindingType == COLUMN;  }
	
	bool IsKnown() const { return bindingType != UNKNOWN; }

	// returns whether the column fetched is null
	bool IsNull() const { return *bytesFetched == SQL_NULL_DATA; }

	// does this BoundIO represent a string?
	bool IsString() const { return sqlType == SQL_VARCHAR &&
							 cType == SQL_C_CHAR; }

	template<class DataObj> int Compare(DataObj *key1, DataObj *key2) const
	{
		// offset into the objects should be valid
		// as we checked the offset back in BoundIOs::operator==()
		// so no check needs to be done here
					
		// get pointer to the actual member in each DataObj
		// now using our BoundIO offset
	//	void *pMember1 = (void *) (((char *) key1) + offset);
	//	void *pMember2 = (void *) (((char *) key2) + offset);
		void *pMember1 = (void *) (data_ptr(key1) + offset);
		void *pMember2 = (void *) (data_ptr(key2) + offset);

		// now we must cast to the appropriate type based on the
		// type name of the BoundIO and then perform the comparison
	    return GenericCmp(pMember1, pMember2, typeId);
	}


	// needed for proper STL string handling
	// MoveRead() and MoveWrite()
	// the functions that propagate the data back to the STL string
	// upon reading or writing respectively from/to the database
	void MoveRead()
	{
		// add support for other C types below
		// such as "blobs", etc.
		// as in a case statement ... test against CTypeAsStr()
		if (typeId == C_STRING)
		{
			string tmp; // make a temp string for exception safety
			            // only copy once we know throwing ops are successful

			// type is string, cast is OK
			string *perm_str_ptr = (string *) addr;

			// make sure string is not a SQL null
			// or actually a NULL pointer

			if (!IsNull())
			{
				// copy strbuf over into the permanent string we are bound to
			    // *perm_str_ptr = strbuf.get();
				tmp = strbuf.get();
			}
			else
			{
				// simply put empty string here - up to SelValidate to decide what to do
				// *perm_str_ptr = string("");
				tmp = string("");
			}

			*perm_str_ptr = tmp; // now we can commit the results to memory
								 // exception-safety maintained
		} else
		if (typeId == C_JTIME_C)
		{
			
			// make sure date is not a SQL null
			
			if (!IsNull())
			{
				// copy timestamp structure;
				jtime_c tmp ( *((timestamp_t *)strbuf.get()));
				jtime_c *perm_ptr = (jtime_c *) addr;
				*perm_ptr = tmp;
			}
			//else
				// simply put empty date here - up to SelValidate to decide what to do
		} 
	}

	void MoveWrite(bool bSelect = false)
	{
		if (IsColumn() && bSelect)
			return;
		
		// add support for other C types below
		// such as "blobs", etc.
		// as in a case statement ... test against CTypeAsStr()
		if (typeId == C_STRING)
		{
			// type is string cast is OK
			string *perm_str_ptr = (string *) addr;

			// need to take care here not to tamper with address of actual strbuf
			// all or nothing preserved as only the strbuf.reset() can throw
			// atomicity and consistency guaranteed
			if (strbuf.get() == NULL)
			{
               strbuf.reset(STRBUFLEN);
			}

			// copy string we're bound to into strbuf
			// 
			size_t len_to_copy = (perm_str_ptr->length() <= STRBUFLEN - 1 ?
				 perm_str_ptr->length() : STRBUFLEN - 1);
			strncpy(strbuf.get(), perm_str_ptr->c_str(), len_to_copy);
			
			// add null terminator
			char *dest = strbuf.get();
			dest[len_to_copy] = '\0';
		}

		else
		if (typeId == C_JTIME_C)
		{
			if (strbuf.get() == NULL)
			{
               strbuf.reset(sizeof(timestamp_t));
			}

			timestamp_t *dest;
			jtime_c *src;
			dest = (timestamp_t *) strbuf.get();
			src = (jtime_c *) addr;
			*dest = (timestamp_t)(*src);
		} 

	}

	// comparison operator for BoundIO objects ...
	// needed by BoundIOs::operator[]()
    friend bool operator==(const BoundIO &bound1, const BoundIO &bound2)
	{
	   return (bound1.addr == bound2.addr &&
			   bound1.bindingType == bound2.bindingType &&
			   bound1.cType == bound2.cType &&
			   bound1.sqlType == bound2.sqlType &&
			   bound1.name == bound2.name &&
			   bound1.typeId == bound2.typeId);
	}

	// get proper address for use by actual BindCol() and BindParam()
	void *GetRawPtr() const;

	// get size of raw buffer
	SDWORD GetRawSize() const;

	// get precision of value
	SDWORD GetPrecision() const;

	// assuming buffer length and raw size are the same
	SDWORD GetBufferLength() const
	{
		return GetRawSize();
	}

	// get C Type
	SDWORD GetCType() const { return cType; }

	// get SQL Type
	SDWORD GetSQLType() const { return sqlType; }

	// get type ID
	int GetTypeID() const { return typeId; }

	// get pointer to bytesFetched
	SDWORD *GetBytesFetchedPtr() const
	{ 
	  return const_cast<SDWORD *>(bytesFetched.get());
	}

	// returns name of the bound IO object (column name or parameter #)
	string GetName() const { return name; }


	BoundIOs *GetBoundIOsPtr() const
	{
		return pBoundIOs;
	}

	void *GetAddr() const
	{
		return addr;
	}

	void SetAddr(void *address)
	{
		addr = address;
	}

	// return relative offset from bound DataObj
	ptrdiff_t GetOffset() const
	{
		return offset;
	}

	void SetAsParam(int numParam)
	{
		// no special care needed for exception-safety
		// if assignment of name or before throws, atomicity and
		// consistency still hold
		ostrstream numstr;
		numstr << numParam << ends;

		name = numstr.str();
		bindingType = PARAM;
	}

	virtual ~BoundIO()
	{}
    

    // binding operator ... maps the memory structure (object member) to a database column
    // or SQL parameter
    // will use RTTI to determine the information to fill the BoundIO with
    // and use a lookup map to determine the appropriate SQL and C types for the appropriate // run-time type
    // may need a specialization for strings

    // must check bc.GetBoundColMode()  first ... BIND_ADDRESSES -  bind just the
    // names, do not bind addresses
    // BIND_ADDRESSES - bind both names and addresses
	// give binding operator access to the innards of this class
	template<class memberType> void operator==(memberType &memberToBind)
	{
		// common tasks for BIND_ADDRESSES and BIND_AS_INDICES

	    // use RTTI to get the type of the object
	    const type_info &RTTI = typeid(memberToBind);
	    const string nameOfType = RTTI.name();

		TypeTranslation &tt = SQL_types_to_C[nameOfType];
		
		void *base_addr;
		size_t base_size;
		
		// get proper addresses for init
		switch (bindingType)
		{
			case COLUMN: base_addr = pBoundIOs->GetBaseAddr();
					     base_size = pBoundIOs->GetBaseObjSize();
						 break;
			case PARAM:	 base_addr = pBoundIOs->GetParamBaseAddr();
						 base_size = pBoundIOs->GetParamBaseSize();
						 break;
			default:	 base_addr = pBoundIOs->GetBaseAddr();
					     base_size = pBoundIOs->GetBaseObjSize();
						 break;
		}

		// exception safe binding
		BoundIO temp(*this);
		temp.InitFromField(tt, &memberToBind, base_addr, base_size);
		swap(temp);
	}

	
	// Construct binding definition based on type & address
	void InitFromField(TypeTranslation &tt, void *field, void *base_addr, size_t base_size)  {

		BoundIO tmp(*this); // need temporary for exception safety

		// make sure the type is in the ETI map!  If not, 
		// a default TypeTranslation object will be built, with the
		// TypeComplexity as invalid
		// if we check the TypeComplexity and it is TYPE_INVALID , we've got an exception!
		if (tt.complexity == TypeTranslation::TYPE_INVALID)
		{
		  string errmsg = "Type ";
		  errmsg += tt.typeNm;
		  errmsg += " not found in ETI Map!";
		  throw ETIException("BoundIO::InitFromField()", errmsg);
		}

	    // now use our ETI table to get the SQL and C types necessary to populate
	    // boundIO
        tmp.sqlType = tt.sqlType;
	    tmp.cType = tt.cType;
		tmp.typeId = tt.typeId;
		tmp.IsPrimitive = tt.IsPrimitive();

	    // fill in the other members of boundIO
	    tmp.size = tt.size;
	    tmp.addr = field;  

		if (tmp.typeId == C_STRING)
		{
		  if (tmp.strbuf.get() == NULL)
		  {
			  tmp.strbuf.reset(STRBUFLEN);
			  char *dest = tmp.strbuf.get();
			  dest[0] = '\0';
		  }
		}

		if (tmp.typeId == C_JTIME_C)
		{
		  if (tmp.strbuf.get() == NULL)
		  {
			  tmp.strbuf.reset(sizeof(timestamp_t));
		  }
		}

	    // indicator must be SQL_NTS for strings and 0 otherwise
	    // except for strings, all SQL_C types have fixed lengths
	    if (tmp.IsString())
		{
		  tmp.bytesFetched = new SDWORD(SQL_NTS);
		} 
	    else
		{
		  tmp.bytesFetched = new SDWORD(0);
		}

		// need to compute offset if we're binding indices
		// can provide this functionality though if we called BindAsBase() previously
		
		if (base_addr)
		{
			// check for possible basic error conditions, throw if either occurs
			if (!tmp.pBoundIOs)
				throw DBException("BoundIO::InitFromField()",
					 "This BoundIO is not bound to its parent!", NULL, NULL);

			size_t mem_offset = (char *) field - (char *) base_addr;

			// make sure bound data is actually part of the object
			// it supposedly belongs to
			// if the address doesn't land within the bounds of the object,
			// throw an exception
			if (mem_offset >= base_size)
				throw DBException("BoundIO::InitFromField()", "Trying to bind index field outside of "
						"base object bounds!", NULL, NULL);

			// everything should be OK otherwise
			tmp.offset = mem_offset;
		}

		swap(tmp); // tmp, process, and swap() guarantee atomicity and consistency
		           // in the face of exceptions
	}

	template<class DataObj, class DataField>
			  void CopyMember(DataObj &key, const DataField &df)
	{  
		  if (IsVariantRow)
		  {
			  CopyVariantRowMember(key, variant_t(df));
			  return;
		  }

		  string dataObjType = typeid(DataObj).name();
		  string baseType = pBoundIOs->GetBaseObjType();

		  // check types of DataObj and of BoundIO's container base object
		  if (dataObjType != baseType)
			  throw DBException("BoundIO::CopyMember()",
			  string("Type mismatch for base object!  ") +
			  "Expected type " + baseType + "!  Instead got " + dataObjType + "!",
			  NULL, NULL);

		  // if type names don't match, we've mismatched fields for sure
		  // throw an exception in this case

		  // other than this check, we must trust the programmer!
		  string dfTypeNm = typeid(DataField).name();
		  TypeTranslation &tt = SQL_types_to_C[dfTypeNm];
		
		  if (tt.typeId != typeId)
			  throw DBException("BoundIO::CopyMember()",
				"Type mismatch in member!  Type of target value: " + dfTypeNm + 
				"does not match bound column type!",
				NULL, NULL);

		  // this cast should be safe
		  // (watch out for offset problems???  We should be OK as we're using the same
		  // data types that were used to compute the offset)
		  DataField *rawAddr = (DataField *) ((char *) data_ptr(&key) + offset); 

#if 0
		  // using operator=() should be fine here except for char *'s
		  // use strncpy() if we have a char *
		  // (must pass in a character array for this to work properly ...
		  // no dynamic allocation or actual string pointers please!)
		  if (dfTypeNm == typeid(char *).name())
		  {
			 // use shorter size for # of chars to copy
			 size_t len = (strlen(df) <= sizeof(*rawAddr) - 1 ? strlen(df) : sizeof(rawAddr) - 1);
			 strncpy(*rawAddr, df, len + 1);	
		  }
		  else
		  {
			 *rawAddr = df;
		  }
#endif

#if 1
		  *rawAddr = df;
#endif
	
	}

	void SetAsVariantRow()
	{
		IsVariantRow = true;
	}

	friend class BoundIOs;
};



// a mapping of columns and parameters to memory structures
// (usually for a specific view)
class BoundIOs : public map<string, BoundIO>
{
  private:
	BoundIO::BoundColMode mode;
	void *base_addr;			// base address of the DataObj we're bound to
								// needed so we can calculate offsets of the members
								// only needed in the case of indexes
								// but might be able to be used elsewhere

	string base_type;			// base object's type (DataObj)
	size_t base_size;			// size of the DataObj we're bound to
								// think of it as sizeof(*base_addr)

	void *param_base_addr;		// base address of the ParamObj we're bound to
								// needed so we can calculate offsets of the
								// members
	string param_base_type;		// ParamObj's type
	size_t param_base_size;		// size of the ParamObj we're bound to

  public:

	BoundIOs(BoundIO::BoundColMode bcMode = BoundIO::BIND_ADDRESSES) :
		map<string, BoundIO>(), mode(bcMode), base_addr(NULL), base_type(""),
		base_size(0), param_base_addr(NULL), param_base_type(""),
		param_base_size(0)  { }


	// Should rebind bases for proper behavior after call to copy constructor!
	BoundIOs(const BoundIOs &boundIOs) : map<string, BoundIO>(boundIOs),
		mode(boundIOs.mode), base_addr(boundIOs.base_addr), base_type(boundIOs.base_type),
		base_size(boundIOs.base_size), param_base_addr(boundIOs.param_base_addr),
		param_base_type(boundIOs.param_base_type), param_base_size(boundIOs.param_base_size)
	{
		// update parentCollection pointers
		for (BoundIOs::iterator b_it = begin(); b_it != end(); b_it++)
		{
			BoundIO &boundIO = (*b_it).second;
			boundIO.pBoundIOs = this;
		}
	}

	// no-throw swap
	void swap(BoundIOs &other) {
		std::swap(mode, other.mode);
		base_type.swap(other.base_type);
		std::swap(base_size, other.base_size);
		std::swap(param_base_addr, other.param_base_addr);
		param_base_type.swap(other.param_base_type);
		std::swap(param_base_size, other.param_base_size);
		map<string, BoundIO>::swap(other);
		// update parentCollection pointers for this
		BoundIOs::iterator b_it;
		for (b_it = begin(); b_it != end(); b_it++)
		{
			BoundIO &boundIO = (*b_it).second;
			boundIO.pBoundIOs = this;
		}
		// update parentCollection pointers for other
		for (b_it = other.begin(); b_it != other.end(); b_it++)
		{
			BoundIO &boundIO = (*b_it).second;
			boundIO.pBoundIOs = &other;
		}
	}

	BoundIOs &operator=(const BoundIOs &boundIOs)
	{
		if (this != &boundIOs)
		{
			BoundIOs temp(boundIOs);
			BoundIOs::swap(temp);
		}
		
		return *this;
	}

	// bind base object so we can compute offsets
    // currently only implemented for indices
	template<class DataObj> void BindAsBase(DataObj &rowbuf)
	{
        // attempting to assign base_type first guarantees exception safety
		base_type = typeid(rowbuf).name();
		base_addr = &rowbuf;
		base_size = sizeof(rowbuf);
	}

	void BindAsBase(void *addr, size_t size, string name) {

		// attempting to assign base_type first guarantees exception safety
		base_type = name;
		base_addr = addr;
		base_size = size;
	}

	// returns address of bound DataObj
	void *GetBaseAddr()
	{
		return base_addr;
	}

	// returns size of bound DataObj
	size_t GetBaseObjSize()
	{
		return base_size;
	}

	// returns stringified type of bound DataObj
	string GetBaseObjType()
	{
		return base_type;
	}

	// bind base ParamObj so we can compute offsets
	template<class ParamObj> void BindParamBase(ParamObj &parambuf)
	{
        // attempting to assign to param_base_type first
		// guarantees exception safety
		param_base_type = typeid(parambuf).name();
		param_base_addr = &parambuf;
		param_base_size = sizeof(parambuf);
	}

	void BindParamBase(void *addr, size_t size, string name) {
		// attempting to assign to param_base_type first
		// guarantees exception safety
		param_base_type = name;
		param_base_addr = addr;
		param_base_size = size;
	}

	// returns address of bound ParamObj
	void *GetParamBaseAddr()
	{
		return param_base_addr;
	}

	// returns size of bound ParamObj
	size_t GetParamBaseSize()
	{
		return param_base_size;
	}

	// returns stringified type of bound ParamObj
	string GetParamBaseType()
	{
		return param_base_type;
	}

	// you must call this function to bind the base address of the DataObj
	// just prior to calling the 
    // return the column with the given name
    BoundIO &operator[](const string &colName)
	{
	  // if element found ... simply return reference to existing object
	  
	  // if element not found ... create object the way we want it, insert it into
	  // map and then return reference to where the object was inserted
	  if (find(colName) == end())
	  {
		 BoundIO::BoundType bindType;

		 // flag binding type for indices when appropriate
		 // else we're binding a column for sure

		 bindType = BoundIO::COLUMN;

		 BoundIO boundIO(colName, mode, bindType, *this);

		 // this atomic operation should not throw
		 // if it does, we're still exception safe
		 // as no other mutators are called

		 insert(pair<const string, BoundIO>(colName, boundIO)); // need for STLPORT
	  }

      return map<string, BoundIO>::operator[](colName);
	}

	// return the parameter with the given index
	// (uses similar logic to BoundIO::operator[](string)
	BoundIO &operator[](unsigned int paramNum)
	{
		ostrstream numstr;
		numstr << paramNum << ends;

		if (find(numstr.str()) == end())
		{
			BoundIO boundIO(numstr.str(), mode, BoundIO::PARAM, *this);

			// this atomic operation should not throw
		    // if it does, we're still exception safe
		    // as no other mutators are called		
			insert(pair<const string, BoundIO>(numstr.str(), boundIO)); // need for STLPORT
		}

		return map<string, BoundIO>::operator[](numstr.str());
	}
	
	// accessors for BoundColMode ... BIND_ADDRESSES or 
	// BIND_ADDRESSES
	BoundIO::BoundColMode GetBoundColMode() { return mode; }
	
	// return the names of the columns bound to
	set<string> GetColumnNames()
	{
		set<string> colNames;
		for (BoundIOs::iterator bc_it = begin(); bc_it != end(); bc_it++)
		{
			pair<const string, BoundIO> pr = *bc_it;
			if (pr.second.IsColumn())
				colNames.insert(pr.first);
		}

		return colNames;			
	}

	// return the # of parameters bound
	int NumParams()
	{
		int count = 0;

		for (BoundIOs::iterator b_it = begin(); b_it != end();
				b_it++)
		{
			if ((*b_it).second.IsParam())
				count++;
		}
		return count;

	}

	// return the # of columns bound
	int NumColumns()
	{
		int count = 0;

		for (BoundIOs::iterator b_it = begin(); b_it != end();
				b_it++)
		{
			if ((*b_it).second.IsColumn())
				count++;
		}

		return count;
	}

	// propagate all bound STL strings to their strbufs
	// We make this non exception-safe, but that should be O.K. since BoundIOs merely
	// hold temporary buffers anyway. Also, making a temporary copy for exception
	// safety here will kill us performance wise.
	void PropagateToSQL(bool bSelect = false)
	{
		bool bFail = false;
		
		for (BoundIOs::iterator b_it = begin(); b_it != end(); b_it++) { 
			try {
				(*b_it).second.MoveWrite(bSelect); // individual calls exception-safe
			} catch(...) {
				bFail = true;
			}
		}
		if (bFail) 
			throw DBException("BoundIOs::PropagateToSQL()", 
			   "Error copying object data in BoundIO column", NULL, NULL);
	}

	// propagate results back to the bound STL strings ... done on a SELECT
	// We make this non exception-safe, but that should be O.K. since BoundIOs merely
	// hold temporary buffers anyway. Also, making a temporary copy for exception
	// safety here will kill us performance wise.
	void PropagateFromResults()
	{
		bool bFail = false;
		
		for (BoundIOs::iterator b_it = begin(); b_it != end(); b_it++) {
			try {
				(*b_it).second.MoveRead(); // individual calls exception-safe
			} catch(...) {
				bFail = true;
			}
		}
		
		if (bFail) 
			throw DBException("BoundIOs::PropagateFromResults()", 
			   "Error copying object data in BoundIO column", NULL, NULL);
	}

	// compute (and store) absolute addresses using base address
	// of the object represented in the BoundIOs
	// bind only if only the appropriate binding type
	void ComputeAbsFromRel(BoundIO::ColumnsOrParams bindMode)
	{
		// no throw guarantee ... accessors and POD ops. only
		for (BoundIOs::iterator b_it = begin(); b_it != end(); b_it++)
		{
			BoundIO &boundIO = (*b_it).second;
			
			if ((boundIO.IsColumn() && bindMode == BoundIO::BIND_AS_COL) ||
				(boundIO.IsParam() && bindMode == BoundIO::BIND_AS_PARAM))
			{
			  void *base_addr_to_use;

			  switch (bindMode)
			  {
			    case BoundIO::BIND_AS_COL: base_addr_to_use = base_addr; break;
				case BoundIO::BIND_AS_PARAM: base_addr_to_use = param_base_addr; break;
				default: base_addr_to_use = base_addr; break;
			  }

			  char *fieldAddr = (char *) base_addr_to_use + boundIO.GetOffset();
			  
			  boundIO.SetAddr(fieldAddr);
			}
		}

	}

	// returns a BoundIOs object which is the set of BoundIO objects that represent
	// the fields that differ from dataObj1 to dataObj2
	template<class DataObj>
		BoundIOs ChangedFields(const DataObj &dataObj1, const DataObj &dataObj2)
	{
	   // accessor ... exception safe
	   BoundIOs changed;
	   
	   for (iterator it = begin(); it != end(); it++)
	   {
		 BoundIO &boundIO = (*it).second;
		 
		 if (boundIO.Compare(&dataObj1, &dataObj2) != 0)
			changed.insert(pair<const string, BoundIO>((*it).first, boundIO));
	   }
	  
	   return changed;
	}


};

END_DTL_NAMESPACE

#endif


