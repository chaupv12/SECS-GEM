/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// provides indexing (keys) for views
// Initial: 10/5/2000 - MG
// Edited: 11/20/2000 - MG - using View parameter in IndexedDBView to
//							 replace explicit DBView<> decls.
// Edited: 12/19/2000 - MG - added namespaces

#include "DBIndex.h"
#include "starit.h"

#ifndef _INDEXEDDBVIEW_H
#define _INDEXEDDBVIEW_H

BEGIN_DTL_NAMESPACE

template<class DataObj, class BCA = DefaultBCA<DataObj> > class DynamicBCA
{
  private:
	  BoundIOs dynbios; // bound IO objects stored in memory 
	  BoundIO::ColumnsOrParams bindMode; // what mode does this functor work in
	  BCA bca;
  public:

	  DynamicBCA(const BoundIOs &boundIOs, const BCA &b = BCA()) : 
		dynbios(boundIOs), bindMode(BoundIO::BIND_AS_COL), bca(b) { }

	  // used to bind as parameters
	  DynamicBCA(const BoundIOs &boundIOs, const BCA &b, vector<string> orderOfParams) : dynbios(boundIOs),
		  bindMode(BoundIO::BIND_AS_PARAM), bca(b)
	  {
			  // first remove all existing parameters from BoundIOs map
			  // they will be useless and confuse the view wherever they're needed
			  for (BoundIOs::iterator it = dynbios.begin(); it != dynbios.end(); it++)
			  {
				  BoundIO &boundIO = (*it).second;

				  if (boundIO.IsParam())
				  {
					  BoundIOs::iterator tmp_it = it;
				      it++;
					  dynbios.erase(tmp_it);
				  }

			  }

			  // now we should only have column BoundIOs left
			  // all of which need to be converted to parameters
			  for (size_t i = 0; i < orderOfParams.size(); i++)
			  {
				 // proper ordering of column names for parameters (for postfix clause in updates)
				 // preserved in orderOfParams
				 string colName = orderOfParams[i];

				 // find parameter with given name
				 BoundIOs::iterator it2 = dynbios.find(colName);

				 if (it2 == dynbios.end())
				    throw DBException("DynamicBCA::DynamicBCA", "Column \"" + colName +
						"\" not found in BoundIOs!", NULL, NULL);

				 // copy by value here as we'll need to remove and insert
				 // this BoundIO from the BoundIOs map
			     BoundIO boundIO = (*it2).second;
	
				 // convert boundIO over to a parameter
				 // complete with number and everything!
				 if (boundIO.IsColumn())
				 {
					ostrstream numstr;
					numstr << i << ends;
					
					boundIO.SetAsParam(i);

					// erase old BoundIO from list
					BoundIOs::iterator tmp_it = it2;
					it2++;
					dynbios.erase(tmp_it);

					// now insert, the fresh new BoundIO
					dynbios.insert(pair<const string, BoundIO>(numstr.str(), boundIO));
				 }


			  }
	  }

	  // exception-safe swap()
	  void swap(DynamicBCA<DataObj, BCA> &other)
	  {
		  bca.swap(other.bca);
		  std::swap(bindMode, other.bindMode);
		  dynbios.swap(other.dynbios);
	  }

	  // exception-safe assignment
	  DynamicBCA<DataObj, BCA> &operator=(const DynamicBCA<DataObj, BCA> &other)
	  {
		 if (this != &other)
		 {
			 DynamicBCA<DataObj, BCA> temp(other);
			 swap(temp);
		 }

		 return *this;
	  }

	  // bca applied here

	  void operator()(BoundIOs &boundIOs, DataObj &rowbuf)
	  {
		  if (true)
		  {	  
			 // you might think this is unnecessary,
			 // but we need it for the variant row case
			 // to initialize the rowbuf types
			 // DO NOT REMOVE!!!!
			 BoundIOs isuck;
			 bca(isuck, rowbuf);  // bind to a dummy BoundIOs to not screw up our params
		  }

		  for (BoundIOs::iterator it = dynbios.begin(); it != dynbios.end(); it++)
			{
				BoundIO &boundIO = (*it).second;
				string name = (*it).first;

				pair<BoundIOs::iterator, bool> pr = boundIOs.insert(pair<const string, BoundIO>(name, boundIO));

				if (!pr.second)
					throw DBException("DynamicBCA:operator()()", "In attempting to tack on "
					+ string("to BoundIOs, BoundIO \"") + name + " exists!", NULL, NULL);
			}

			switch (bindMode)
			{
			   case BoundIO::BIND_AS_COL: boundIOs.BindAsBase(*data_ptr(&rowbuf)); break;
			   case BoundIO::BIND_AS_PARAM: boundIOs.BindParamBase(*data_ptr(&rowbuf)); break;
			   default: boundIOs.BindAsBase(*data_ptr(&rowbuf)); break;
			}
			boundIOs.ComputeAbsFromRel(bindMode);
										  // compute absolute addresses using base address
										  // of the object represented in the BoundIOs
										  // has to be smart enough to bind only if appropriate
										  // columns only if BIND_AS_COL set
										  // params only if BIND_AS_PARAM set
	  }

};

// function to set the underlying ParamObj
// generic SetParams callback that expects a signature of
// void SetParams(ParamObj &params)
template<class ParamObj> class SetParamsWrap : public unary_function<ParamObj &, void>
{
     private:
	    variant_cc_t v; // polymorphically stores the function object
		SetParamsWrap() : v() { } // Don't allow default constructor -- too dangerous
     public:
	    enum SetParamsEnum
		{
          SET_PARAMS
		};


	    // constructor takes a raw setparams function object
	    // and then registers the UserSetParams::operator() that serves as its func
        template<class UserSetParams> SetParamsWrap(const UserSetParams &setpars) :
	    v(setpars) 
		{ 
		   	if (false) {
				// Let the compiler do compile time type checking.
				// This is purely to get a good compile time warning
				// if the required signature does not match.
				// Signature of UserClass::operator() must be:
				// void SetParams(ParamObj &params);
	
				ParamObj p;
				UserSetParams *pmethod = const_cast<UserSetParams *>(&setpars);
				pmethod->operator()(p);  // compile-time type check: see above
			}
			v.AddCBFunctor1(SET_PARAMS, &UserSetParams::operator());
		}

	    // copy constructor
	    SetParamsWrap(const SetParamsWrap &setpars) : v(setpars.v)  { }

	    // exception-safe swap
	    void swap(SetParamsWrap &sp)
		{
           v.swap(sp.v);
		}

	    // assignment operator
	    SetParamsWrap &operator=(const SetParamsWrap &setpars)
		{
		   if (this != &setpars)
		   {
		      SetParamsWrap tmp(setpars);
		      swap(tmp);
		   }

		   return *this;
		}

	    // act as the setparams functor ... in reality forward the call
	    // to the actual set params functor itself

		// signature of functor must be:
		// void SetParams(ParamObj &params);
		void operator()(ParamObj &params)
		{

		  variant_invoke1<ParamObj &>(v, SET_PARAMS, params);
		}

	    // conversion operator needed so we can reextract the actual setparams func
	    // held by v
	    template<typename UserSetParams> const UserSetParams &
		   get(const UserSetParams *dummy) const
		{
		   return v.get(dummy);
		}
};

template<class ParamObj> class DefaultSetParams : 
	public unary_function<ParamObj &, void>
{
  public:
	  void operator()(ParamObj &paramObj)
	  { }
};

template<typename View> class IndexedDBView
{
  public:
	  typedef typename View::DataObject DataObj;
	  typedef typename View::ParamObject ParamObj;
	  typedef BCAWrap<DataObj> BCA;
	  typedef BPAWrap<ParamObj> BPA;
  private:
	  // function to set the underlying ParamObj
	  // typedef void (*SetParamsFn) (ParamObj &params);
	  typedef SetParamsWrap<ParamObj> SetParamsFn;

 	  // points to a DataObj *
	  typedef DBIndex<View>::iterator indexed_data_iterator;

	  // points to a DataObj
	  typedef list<DataObj>::iterator data_iterator;
	  typedef pair<indexed_data_iterator, indexed_data_iterator> indexed_data_pair;
	  
	  // index map type
	  typedef map<string, DBIndex<View> > index_map;

  public:
	  // star iterator adapter for indexed_data_iterator
	  typedef star_bidirectional_iterator<DBIndex<View>::iterator,
		  DataObj> indexed_iterator;
	  typedef pair<indexed_iterator, indexed_iterator> indexed_pair;
 
	  // standard STL typedefs!
	  typedef DataObj value_type;
	  typedef value_type* pointer;
	  typedef const value_type* const_pointer;
	  typedef value_type& reference;
	  typedef const value_type& const_reference;

	  // note that as DBIndex::iterator is a constant bidirectional iterator, so is
	  // IndexedDBView::iterator
	  typedef indexed_iterator iterator;
	  typedef indexed_iterator const_iterator;

#if defined(_MSC_VER) // && !defined(__SGI_STL_PORT)
    // Microsoft non-standard in how it defines reverse_iterator
	  typedef std::reverse_iterator<iterator, DataObj> reverse_iterator;
	  typedef std::reverse_iterator<const_iterator, DataObj> const_reverse_iterator;
#else
 	  typedef std::reverse_iterator<iterator> reverse_iterator;
	  typedef std::reverse_iterator<const_iterator> const_reverse_iterator;
#endif
	  typedef ptrdiff_t difference_type;
	  typedef size_t size_type;

  protected:
	  indexed_pair sp(indexed_data_pair dp) const {
		    indexed_iterator i(dp.first);
			indexed_iterator j(dp.second);
			indexed_pair s(i, j);
			return s;
	  }

	  indexed_pair sp(indexed_iterator it) const
	  {
			return indexed_pair(it, it);
	  }

	  View *pDBview;  // points to underlying view that the
			 		  // indexed view refers to

	  BCA bca;

	  // these members are mutable as several methods needed to make this class STL
	  // compatible must be declared const and have to modify these members
	  mutable list<DataObj> data;		  // actual data objects owned here
	  mutable map<string, DBIndex<View> > indexes;
										  // the indices are named and refer
										  // to the data objects stored in the list
	  mutable bool bFetched;	// flag indicating whether the data has been fetched from the DB

	  SetParamsFn SetParams; // function to set the underlying ParamObj

	  vector<string> orderOfKeys; // reflects on the order of the strings passed in at
								  // construction
								  // first key is the one we wish to apply first,
								  // 2nd key we wish to apply 2nd, etc.

	  vector<DBIndex<View>::Uniqueness> isUniqueKeys; // needed for copy constructor and assignment
									   // operator to properly build the object
									   // and preserve uniqueness from source Index
      vector<string> FieldNameCommaLists; // needed for copy constructor and
										  // assignment operator to
										  // properly build the object
										  // essentially is a vector of
										  // comma delimited field lists

	  BoundMode boundToDB;				  // are we BOUND to the DB or UNBOUND
										  // changes propagate through to DB if bound
	  KeyMode useWhichFields;			  // do we USE_PK_ONLY or USE_ALL_FIELDS
										  // for writing changes to DB

	  // used by copy constructor and assignment operator to build the indexes
	  // and populate them with DataObj *'s
	  void BuildIndexes()
	  {
			 // note that if the copy has fetched the data already, we don't need
			 // to fetch() again (if changes are made, we don't need to query the database
			 // for them as the data will be properly maintained in the IndexedDBView
			 // and we never change the underlying query or its parameters)
			 // thus, consistency of the IndexedDBView with the DB is not a necessary
			 // condition?)

			 // safe, but useless to copy a default constructed IndexedDBView 
		     if (pDBview == NULL)
				return;

			 // temporary map of indexes used to provide exception-safety
			 // atomicity and consistency guarantees
			 map<string, DBIndex<View> > tmp;


			 vector<string>::iterator it = orderOfKeys.begin();
			 vector<string>::iterator fname_it = FieldNameCommaLists.begin();
			 vector<DBIndex<View>::Uniqueness>::iterator un_it = isUniqueKeys.begin();

			 // we must rebuild the indexes map because the DataObj's are copied
			 // in the copy constructor for data and thus have different addresses
			 while (it != orderOfKeys.end())
			 {
				string IndexName = *it;
			    string FieldNames = *fname_it;
				DBIndex<View>::Uniqueness isUnique = *un_it;

				DBIndex<View> idx(FieldNames, *pDBview, isUnique);
				
				// create this index
			    tmp.insert(pair<const string, DBIndex<View> >(IndexName, idx));

				// for each DataObj in the list, insert a pointer it in the index's
				// data list, using the proper address of the newly made copy
				if (bFetched)
				{
					for (data_iterator data_it = data.begin(); data_it != data.end(); data_it++)
					{
						// get address of the list element as it's the pointer we need
						DataObj *pData = &(*data_it);

						// indexes[IndexName].insert(*pData);

						index_map::iterator map_it = tmp.find(IndexName);

						// IndexName should always be in the list
						if (map_it != tmp.end())
						{
							(*map_it).second.insert(*pData);
						}
					}
				}

				// march through matching vectors
				it++;
				fname_it++;
				un_it++;

			 }

			 indexes.swap(tmp);
	  }

  public:
	  // IndexNamesAndFields takes the form
	  // "IndexName1; IndexField1, IndexField2; IndexName2; IndexField3, IndexField4, IndexField5"};
	  // used to construct the map of indexes.
	  // first index in constructor list is used as primary index in default
	  // equal_range() method.
	  // The keyword UNIQUE may be place in front of any index name to indicate that
	  // that set of fields represents a unique constraint on the rows
	  // SetParams() function is used to set any of the condition parameters that are to be applied as
	  // part of the fetch.
	  // so, e. g.
	  // DBView view("DB_EXAMPLE", BCA);
	  // IndexedDBView indexedView(view, "Unique StringIndex; STRING_VALUE; AnotherIndex; INT_VALUE, EXAMPLE_LONG");
	  IndexedDBView(const View &view, const string IndexNamesAndFields,
		  BoundMode bm = UNBOUND, KeyMode km = USE_ALL_FIELDS, 
		  SetParamsFn SetPar = DefaultSetParams<ParamObj>()) : 
			pDBview(NULL), data(), indexes(), bFetched(false), SetParams(SetPar),
			orderOfKeys(), FieldNameCommaLists(), boundToDB(bm), useWhichFields(km),
			bca(view.GetBCA())
		{ 
			// make *copy* of view here
			pDBview = new View(view);

			// construct the map of indices based on the IndexNamesAndFields string

			char *c_str = new char[IndexNamesAndFields.length() + 1];

			strncpy(c_str, IndexNamesAndFields.c_str(), IndexNamesAndFields.length() + 1);

			// we first need to parse out this string for semicolons
			// to give us strings we can work with for IndexName;FieldList pairs
			vector<string> semiColonsParsedStrings;
			
			char *semiColonToken = strtok(c_str, ";");

			while (semiColonToken != NULL)
			{
				// for each token, trim whitespace and then record it
				EatLeadingWhitespace(semiColonToken);

				// don't allow empty tokens after whitespace eaten
				// DBIndex constructor will have to perform a similar check for
				// field names once they get parsed
				if (strlen(semiColonToken) == 0)
				{
					delete[] c_str;
					throw DBException("IndexedDBView::IndexedDBView()",
						"Invalid IndexNamesAndFields string \"" + 
						IndexNamesAndFields + "\"!  Empty IndexName or FieldList detected!",
						NULL, NULL);
				}
				semiColonsParsedStrings.push_back(semiColonToken);

				semiColonToken = strtok(NULL, ";");
			}
			
			delete[] semiColonToken;
			delete[] c_str;

			// now we've got to make sense out of the name/list pairs
			vector<string>::iterator tok_it = semiColonsParsedStrings.begin();

			// loop to pair up and validate strings
			while (tok_it != semiColonsParsedStrings.end())
			{
				string IndexName(*tok_it);
				DBIndex<View>::Uniqueness isUnique = DBIndex<View>::NONUNIQUE_INDEX;

				// first up should be an IndexName
				// commas mean we have an invalid name as user
				// erroneously entered a field list
				if (numOfOccurrences(',', IndexName) != 0)
					throw DBException("IndexedDBView::IndexedDBView()",
						"Invalid IndexNamesAndFields string \"" +
						IndexNamesAndFields + "\"!  Expected IndexName, instead found "
						"FieldList!", NULL, NULL);

				// check for "unique" keyword ... case insensitive
				MemPtr strTokMe(IndexName.length() + 1);
			
				strcpy(strTokMe.get(), IndexName.c_str());

				// get string up to first space
				char *nameToken = strtok(strTokMe.get(), " ");

				if (stricmp(nameToken, "Unique") == 0)
				{
					// index is unique ... so we expect an index name to follow
					// strtoking on ';' guarantees to grab the rest of the string
					// we're parsing for the index name
					nameToken = strtok(NULL, ";");

					// can't use unique as index name as it's a keyword
					if (stricmp(nameToken, "Unique") == 0)
					{

						throw DBException("IndexedDBView::IndexedDBView()",
						   "Invalid IndexNamesAndFields string \"" +
						   IndexNamesAndFields + "\"!  Can't use keyword \"Unique\" as " +
						   "an index name!", NULL, NULL);
					}
					// must specify name of unique index
					else if (nameToken == NULL)
					{
		
						throw DBException("IndexedDBView::IndexedDBView()",
							"Invalid IndexNamesAndFields string \"" +
						    IndexNamesAndFields + "\"!  Expected name of unique index!",
							NULL, NULL);
					}

					isUnique = DBIndex<View>::UNIQUE_INDEX;

					// IndexName is simply the part of the string after "Unique"
					IndexName = nameToken;

				}
				else
				{
					// index is nonunique ... IndexName is the name of the index
					isUnique = DBIndex<View>::NONUNIQUE_INDEX;
				}

				tok_it++;

				// grab FieldNames list ... if no strings are left in the vector,
				// then we have an IndexName that doesn't have any fields associated with it
				if (tok_it == semiColonsParsedStrings.end())
					throw DBException("IndexedDBView::IndexedDBView()",
						"Invalid IndexNamesAndFields string \"" +
						IndexNamesAndFields + "\"!  Expected FieldList, instead found "
						" premature end of list!", NULL, NULL);
				
				const string FieldNames(*tok_it);

				// the DBIndex constructor will be responsible for making sure
				// that the fields in the field list are valid columns in the view
				// we must first make sure that the map already doesn't contain an index
				// with the given name
				// DBIndex constructor will throw an exception if there's 
				// a problem with the FieldNames

				DBIndex<View> idx(FieldNames, *pDBview, isUnique);

				pair<map<string, DBIndex<View> >::iterator, bool>
						ins_pair(indexes.insert(pair<const string, DBIndex<View> >(IndexName, idx)));

				// if insertion failed, that means the user tried to specify a duplicate
				// key name
				if (!(ins_pair.second))
				{
					throw DBException("IndexedDBView::IndexedDBView()",
						"Invalid IndexNamesAndFields string \"" +
						IndexNamesAndFields + "\"!  Attempted to redefine IndexName \"" +
						IndexName + "\"!", NULL, NULL);
				}

				// record in key names list
				orderOfKeys.push_back(IndexName);

				// also record FieldNames comma delimited list and uniqueness ... need for
				// copy constructor and assignment operator to work properly
				FieldNameCommaLists.push_back(FieldNames);
				isUniqueKeys.push_back(isUnique);

				tok_it++;
			}

			// now have all information needed to build template rowbuf
			// BuildTemplateRowbuf();

		}

	   // requirements for Assignable!

	   // default constructor

	   // as any IndexedDBView must be associated with a DBView, you *must*
	   // assign another IndexedDBView to a default constructed object
	   IndexedDBView() : pDBview(NULL), data(), indexes(), bFetched(false),
		  SetParams(DefaultSetParams<ParamObj>()), orderOfKeys(), FieldNameCommaLists(), isUniqueKeys(),
		  boundToDB(UNBOUND), useWhichFields(USE_ALL_FIELDS), 
		  bca(DefaultBCA<DataObj>())
	   { }
	   
	   // copy constructor
	   IndexedDBView(const IndexedDBView<View> &idxview) :
	      pDBview(NULL), data(idxview.data), indexes(), bFetched(idxview.bFetched),
		  SetParams(idxview.SetParams), orderOfKeys(idxview.orderOfKeys),
		  FieldNameCommaLists(idxview.FieldNameCommaLists),
		  isUniqueKeys(idxview.isUniqueKeys),
		  boundToDB(idxview.boundToDB), useWhichFields(idxview.useWhichFields),
		  bca(DefaultBCA<DataObj>())
		  {
			// need *copy* of view
			if (idxview.pDBview != NULL)
			{
				pDBview = new View(*(idxview.pDBview));
				bca = pDBview->GetBCA();
			}

			BuildIndexes();			
		  }

	   // exception-safe swap()
	   void swap(IndexedDBView<View> &other)
	   {
		   std::swap(pDBview, other.pDBview);
		   bca.swap(other.bca);
		   data.swap(other.data);
		   indexes.swap(other.indexes);
		   std::swap(bFetched, other.bFetched);
		   std::swap(SetParams, other.SetParams);
		   FieldNameCommaLists.swap(other.FieldNameCommaLists);
		   std::swap(isUniqueKeys, other.isUniqueKeys);
		   std::swap(boundToDB, other.boundToDB);
		   std::swap(useWhichFields, other.useWhichFields);
		   // std::swap(rowbuf, other.rowbuf);
		   std::swap(orderOfKeys, other.orderOfKeys);
	   }

	   // exception-safe assignment
	   IndexedDBView<View> &
		   operator=(const IndexedDBView<View> &other)
	   {
		  if (this != &other)
		  {
			 IndexedDBView<View> temp(other);
			 swap(temp);
		  }

		  return *this;

	   }

	   virtual ~IndexedDBView()
	   {
		  delete pDBview;
		  pDBview = NULL;
	   }

	
		 // *** ALL ITERATORS BELOW MUST CALL fetch() FIRST ***
	
	   // WARNING!!!!  You must give the compiler enough of a hint in order for it
	   // to pass the proper types for DataFields for find() and equal_range()
	   // for example, if you are searching based on a DataField that's a string,
	   // either pass in a string variable or a string constant:
	   // examples:  string str;
	   //			 find(str);
	   //			 find(string("Foo"));
	   //			 // NOT find("Foo");
	   // you also need to use similar conversions for numerics
	   // This caveat is because the compiler isn't performing
	   // implicit conversions between types due to the use of templates

	   // *** equal_range() functions ***

	   // the versions of equal_range() below will work for most keys
	   // as they are composed usually of no more than one or two fields
	   // for keys that are composed of more than 2 fields, you must use one of the above
	   // versions that take a DataObj representing the key

	   // return an iterator to objects that have the given value
	   // based on a key composed of a single field
	   // (that of the first key field listed in the orderOfFields for the DBIndex)
	   // (INDEXNM = df)
	
	
	   // same as the single DataField version, but based on two key fields
	   // (a two-field key)
	   // (INDEXNM.DF1 = df1 AND INDEXNM.DF2 = df2)
	   template<class DataField1, class DataField2>
		   indexed_pair
		   equal_range_AK(const string &IndexNm, const DataField1 &df1, const DataField2 &df2) const
	   {
		  IndexedDBView<View> *this_ptr = const_cast<IndexedDBView<View> *>(this);
		  
		  this_ptr->fetch();
		  
		  // return sp(indexes[IndexNm].equal_range(df1, df2));

		  index_map::iterator map_it = this_ptr->indexes.find(IndexNm);

		  // should always be the case that IndexNm exists
		  if (map_it != this_ptr->indexes.end())
		  {
			return sp((*map_it).second.equal_range(df1, df2));
		  }
		  else // if index not found, return PK's end() iterator to stick to conventions
		  {
			return sp(this_ptr->end());
		  }		  
	   }

     // templated versions of equal_range that use the first key that was passed in
	   // to the constructor to this indexed view
	   // (use key composed of single field)
	   // (FIRSTKEY = df)
	   template<class DataField> indexed_pair
		   equal_range(const DataField &df1) const
	   {
		  return equal_range_AK(orderOfKeys[0], df1);	
	   }
	
	   // (uses key composed of two fields)
	   // (FIRSTKEY.DF1 = df1 AND FIRSTKEY.DF2 = df2)
	   template<class DataField1, class DataField2>
		   indexed_pair
		   equal_range(const DataField1 &df1, const DataField2 &df2) const
	   {
		   return equal_range_AK(orderOfKeys[0] , df1, df2);
	   }

	   // *** find() functions ***

	   // the versions find() below will work for most keys
	   // as they are composed usually of no more than one or two fields
	   // for keys that are composed of more than 2 fields, you must use one of the above
	   // versions that take a DataObj representing the key

	   // return an iterator to object that has the given value
	   // based on a key composed of a single field
	   // (that of the first key field listed in the orderOfFields for the DBIndex)
	   // (INDEXNM = df)
	
	   // same as the single DataField version, but based on two key fields
	   // (a two-field key)
	   // (INDEXNM.DF1 = df1 AND INDEXNM.DF2 = df2)
	   template<class DataField1, class DataField2>
		   indexed_iterator
		   find_AK(const string &IndexNm, const DataField1 &df1, const DataField2 &df2) const
	   {
		  IndexedDBView<View> *this_ptr = const_cast<IndexedDBView<View> *>(this);
		  
		  this_ptr->fetch();

		  // return indexes[IndexNm].find(df1, df2);

		  index_map::iterator map_it = this_ptr->indexes.find(IndexNm);

		  // should always be the case that IndexNm exists
		  if (map_it != this_ptr->indexes.end())
		  {
			  return indexed_iterator((*map_it).second.find(df1, df2));
		  }
		  else // if index not found, return PK's end() iterator to stick to conventions
		  {
			  return this_ptr->end();
		  }
	   }
	
	   // templated versions of find that use the first key that was passed in
	   // to the constructor to this indexed view
	   // (use key composed of single field)
	   // (FIRSTKEY = df)
	   template<class DataField> indexed_iterator
		   find(const DataField &df1) const
	   {
			  return find_AK(orderOfKeys[0], df1);	

	   }

	   // (uses key composed of two fields)
	   // (FIRSTKEY.DF1 = df1 AND FIRSTKEY.DF2 = df2)
	   template<class DataField1, class DataField2>
		   indexed_iterator
		   find(const DataField1 &df1, const DataField2 &df2) const
	   {
		   return find_AK(orderOfKeys[0], df1, df2);
		 }	


//-- equal_range_AK ---------------------

     template<class DataField> indexed_pair
		   equal_range_AK(const string &IndexNm, const DataField &df) const
	   {
		  IndexedDBView<View> *this_ptr = const_cast<IndexedDBView<View> *>(this);
		
		  this_ptr->fetch();
		
		  // return sp(indexes[IndexNm].equal_range(df));

		  index_map::iterator map_it = this_ptr->indexes.find(IndexNm);

		  // should always be the case that IndexNm exists
		  if (map_it != this_ptr->indexes.end())
		  {
			return sp((*map_it).second.equal_range(df));
		  }
		  else // if index not found, return PK's end() iterator to stick to conventions
		  {
			return sp(this_ptr->end());
		  }
	   }
		
	   // return iterator to the DataObj * that has key IndexNm = key
	   // equal_range() needs to return a pair of iterators, one to march through the
	   // found elements and the other to return the iterator marking the end of the
	   // list for this particular index
	   indexed_pair
			equal_range_AK(const string &IndexNm, const DataObj &key) const
	   {
		    IndexedDBView<View> *this_ptr = const_cast<IndexedDBView<View> *>(this);
		
		    this_ptr->fetch();
			
			// return sp(indexes[IndexNm].equal_range(key));

		    index_map::iterator map_it = this_ptr->indexes.find(IndexNm);

		    // should always be the case that IndexNm exists
		    if (map_it != this_ptr->indexes.end())
			{
			  return sp((*map_it).second.equal_range(key));
			}
			else // if index not found, return PK's end() iterator to stick to conventions
			{
			  return sp(this_ptr->end());
			}
	   }


//-- find_AK ---------------------
	   template<class DataField> indexed_iterator
		   find_AK(const string &IndexNm, const DataField &df) const
	   {
		  IndexedDBView<View> *this_ptr = const_cast<IndexedDBView<View> *>(this);
		
		  this_ptr->fetch();

		  // return indexes[IndexNm].find(df);

		  index_map::iterator map_it = this_ptr->indexes.find(IndexNm);

		  // should always be the case that IndexNm exists
		  if (map_it != this_ptr->indexes.end())
		  {
			  return indexed_iterator((*map_it).second.find(df));
		  }
		  else // if index not found, return PK's end() iterator to stick to conventions
		  {
			  return this_ptr->end();
		  }
	   }
		
	   // return iterator to the DataObj * that has key IndexNm = key
	   // find() returns an iterator to an object meeting the filter criteria
	   indexed_iterator
			find_AK(const string &IndexNm, const DataObj &key) const
	   {
		  IndexedDBView<View> *this_ptr = const_cast<IndexedDBView<View> *>(this);
		
		  this_ptr->fetch();

		  // return indexes[IndexNm].find(key);

		  index_map::iterator map_it = this_ptr->indexes.find(IndexNm);

		  // should always be the case that IndexNm exists
		  if (map_it != this_ptr->indexes.end())
		  {
			  return indexed_iterator((*map_it).second.find(key));
		  }
		  else // if index not found, return PK's end() iterator to stick to conventions
		  {
			  return this_ptr->end();
		  }
	   }


	   // *** insert() and erase() methods ***

	   // complete with BOUND/UNBOUND, USE_PK_FIELDS_ONLY/USE_ALL_FIELDS semantics
	   // each of the base insert() and erase() methods does the following:
	   // 1. Sees if the operation is valid locally to the IndexedDBView structure itself
	   // 2. If in BOUND mode, tries to apply the operation to the DB
	   // 3. If #2 successful or in UNBOUND mode, applies the operation to the
	   //	 IndexedDBView structure.
	   
	   // *** base insert() method ***
	   // attempts to insert dataObj into the IndexedDBView
	   // returns a pair:
	   // pair::first: iterator to the newly inserted object if successful
	   // if object already in the view locally, returns an iterator
	   // to the already existing element in the view
	   // pair::second: whether the insertion was successful or not

	   // to provide atomicity, actually written to do local_insert() first,
	   // then DB insert
	   pair<iterator, bool> insert(const DataObj &dataObj)
	   {
		   fetch();

		   pair<iterator, bool> find_pr = CheckUniqueness(dataObj);

		   // if element found, insertion failed
		   // just return the pair back up to caller
		   if (!find_pr.second)
			  return find_pr;

		   // first do local_insert() ... if fails, we don't touch the object state at all
		   pair<iterator, bool> ins_pr = local_insert(dataObj);

		   iterator it = ins_pr.first;

		   // if in BOUND mode, try to insert into DB
		   // insertion will throw if the remote insertion fails
		   // (for example, if uniqueness constraints are violated on the DB)
		   try
		   {
			   if (boundToDB == BOUND)
			   {
			      DBView<DataObj, ParamObj> view(MakeDelimitedList(pDBview->GetTableNames()), pDBview->GetBCA(), "",
				     EmptyBPA<ParamObj>(), pDBview->GetSelVal(), pDBview->GetInsVal(),
					 pDBview->GetConnection());

				  view.set_io_handler(pDBview->get_io_handler());

				  DBView<DataObj, ParamObj>::insert_iterator ins_it = view;
			      *ins_it = dataObj;
			      ins_it++;

				  // if iterator encountered a problem, that means insertion failed, so throw
				  if (ins_it.bad() || ins_it.fail())
					  throw DBException("IndexedDBView::insert()", "Insertion into DB failed!",
							NULL, NULL);
			   }
		   }

		   catch (...)
		   {
			   // must rollback local state, then rethrow the exception!
			   local_erase(it);
			   throw;
		   }

		   // if successful so far, insert into the IndexedDBView structure
		   // uniqueness constraints should be guaranteed here
		   return ins_pr;
	   }

	   // *** base erase() method ***
	   // attempts to remove the DataObj pointed to by the iterator passed in
	   // 1.  If in BOUND mode, tries to delete the object from the DB
	   // 2.  Remove the element from each of the indexes.
	   // 3.  Erase the element from the owned list<DataObj> ... data
	   // Note: This method assumes the iterator passed in is a valid
	   // iterator pointing into the container

	   // atomicity guaranteed: database erase succeeds or fails; steps 2 and 3
	   // are nothrow due to STL erase() guarantees
	   void erase(iterator it)
	   {
		   fetch();

		   // if in BOUND mode, try to delete object from DB
		   if (boundToDB == BOUND)
		   {
			   BoundIOs tmpbios;

			   // get a copy of the proper BoundIOs
			   switch (useWhichFields)
			   {
			     case USE_PK_FIELDS_ONLY: // get BoundIOs representing PK only
				       tmpbios = ExtractPK();
					   break;
				 case USE_ALL_FIELDS: // get all BoundIOs
					   index_map::iterator map_it = indexes.find(orderOfKeys[0]);
					 
					   // shouldn't happen
					   if (map_it == indexes.end())
					   {
						  throw DBException("IndexedDBView::erase()",
							  "View must have a PK declared!", NULL, NULL);
					   }

					   DataObj rowbuf;
					   tmpbios.BindAsBase(rowbuf);
					   bca(tmpbios, rowbuf);
					   
					   break;
			   }

			   // note: as the below view does not have a postfix clause,
			   // extra records might get deleted then what the user might expect
			   DBView<DataObj, ParamObj> view(MakeDelimitedList(pDBview->GetTableNames()),
				   DynamicBCA<DataObj, BCA>(tmpbios, bca), "",
				   EmptyBPA<ParamObj>(), pDBview->GetSelVal(), pDBview->GetInsVal(),
				   pDBview->GetConnection());

			   view.set_io_handler(pDBview->get_io_handler());

			   DBView<DataObj, ParamObj>::delete_iterator del_it = view;
			   *del_it = *it;
   			   del_it++;

			   // if iterator encountered a problem, that means deletion failed, so throw
			   if (del_it.bad() || del_it.fail())
					  throw DBException("IndexedDBView::erase()", "Delete from DB failed!",
							NULL, NULL);
		   }
		  
		  // steps 2 and 3 taken care of by local_erase()
		  local_erase(it);
	   }

       // *** base replace() method ***
	   // attempts to replace the object pointed to by the iterator it with
	   // a new set of data as specified by dataObj into the IndexedDBView
	   // returns a pair:
	   // pair::first: iterator to the newly replaced object if successful
	   // if object already in the view locally, returns an iterator
	   // to the already existing element in the view
	   // pair::second: whether the insertion was successful or not
	
       // to gain atomicity we will do the following:
	   // 1. Mark elements for deletion in the index lists
	   //    that match it based on comparing &(*it)
	   // 2. CheckUniqueness() - find() on new item (dataObj), if anything comes back
	   //    other than old item or not found, fails uniqueness check
	   // 3. local_insert(dataObj) in try/catch
	   // 4. DB Update in try/catch ... rollback local_insert() if failed
	   // 5. local_erase() on all marked elements from step 1
	   pair<iterator, bool> replace(iterator it, const DataObj &dataObj)
	   {
		  fetch();

		  // *** Preliminary check for a primary key ***
		  index_map::iterator map_it = indexes.find(orderOfKeys[0]);
					 
		  // shouldn't happen
		  if (map_it == indexes.end())
		  {
			  throw DBException("IndexedDBView::erase()",
					  "View must have a PK declared!", NULL, NULL);
		  }

		  // *** mark elements in index lists for deletion ***
		  // each index list should contain &(*it) exactly once
		  // if not, we know our data structure is corrupted and we should throw
          // throwing is OK here as we're still atomic
		  // DataObj *addr = &(*it); // get address of DataObj referred to by it

		  list<iterator> condemned;// iterators to elements in index lists to erase
								   // the delete markers are stored in order of the indexes
								   // as we iterate over them
								   // *** You are hereby condemned to die at the hands ***
								   // *** of the Coding Gods, you mere pointers!!!!!   ***

		  // mark the element in each index list
		  for (map_it = indexes.begin(); map_it != indexes.end(); map_it++)
		  {
			 DBIndex<View> &index = (*map_it).second;

			 DBIndex<View>::iterator idx_it = index.find_by_addr(*it);
			 
			 // if element not found, throw as we've detected that the indexed view
			 // is in a corrupted state ... still atomic here as no changes made to
			 // container or the objects it owns
			 if (idx_it == index.end())
				 throw DBException("IndexedDBView::replace()",
				     "Indexed view is corrupted due to bad index list!", NULL, NULL);

			 // record the iterator in the list of the damned
			 condemned.push_back(iterator(idx_it));
		  }

		  // *** Check uniqueness of new dataObj ***

		  // if anything comes back other than the old item or not found on any unique index,
		  // uniqueness check violated!
		  

		  // Check replace before performing to make sure it does not
		  // violate uniqueness
		  pair<iterator, bool> find_pr = CheckUniqueness(dataObj, it);

		  // if element found, check to see if dataObj != it
		  // if so, replace will violate uniqueness
		  // in this case return the pair back up to caller
		  if (!find_pr.second)
			  return find_pr;

		  // *** local_insert() of dataObj ***
		  
		  // atomicity maintained as local_insert() itself is atomic and
		  // this is our first mutating operation attempted on the indexed view
		  // no need for try/catch here as all the semantics for atomicity 
		  // are in local_insert()
		  // do NOT use the built in checks for uniqueness in local_insert()
		  // bool value returned as ins_pr.second should always be true
		  pair<iterator, bool> ins_pr = local_insert(dataObj, false);

		  // shouldn't happen that ins_pr is false, but in that event,
		  // return failure of replace()
		  if (!ins_pr.second)
			  return ins_pr;

		  // *** DB Update in try/catch block ***
		  // on failure we must rollback the local_insert() in order to maintain atomicity

		  // if in BOUND mode, try to insert into DB
		  // insertion will throw if the remote insertion fails
		  // (for example, if uniqueness constraints are violated on the DB)
		  if (boundToDB == BOUND)
		  {
			// try the update in the DB
			try
			{
			   // TODO: two tricky things need to be done to make replace work efficiently
			   // 1.  BCA should be just the list of changed columns between *it and dataObj
			   //  so that only the minimum set of changes are send to the database.
			   //  The changed columns should be found by doing comparisons using BoundIOs.
			   //
			   // 2.  A where clause needs to be setup along with a BCA functor to specify
			   //  which rows in the database are to be replaced.  If the mode is
			   //  KEYFIELDS_ONLY --> WHERE db_field1 = key_field1 AND db_field2 = key_field2 AND...
			   //  ALLFILEDS      --> WHERE db_field1 = field1 AND ...(use all fields here)
			
			   BoundIOs bpabios;  // used for BPA

			   // get a copy of the proper BoundIOs
			   switch (useWhichFields)
			   {
			     case USE_PK_FIELDS_ONLY: // get BoundIOs representing PK only
				       bpabios = ExtractPK();
					   break;
				 case USE_ALL_FIELDS: // get all BoundIOs
					   DataObj rowbuf;
					   bpabios.BindAsBase(rowbuf);
					   bca(bpabios, rowbuf);
					   
					   break;
			   }

			   // we can update any field whether or not it is in the index
			   BoundIOs bcabios;

			   DataObj rowbuf;
			   bcabios.BindAsBase(rowbuf);
			   bca(bcabios, rowbuf);

			   // bcabios.ComputeAbsFromRel(BoundIO::BIND_AS_COL);

			   bcabios = bcabios.ChangedFields(*it, dataObj);

			   pair<string, vector<string> > pr = PostfixForUpdate(bpabios);

			   string postfix = pr.first;
			   vector<string> orderOfColumns = pr.second;

			   DBView<DataObj, DataObj> view(MakeDelimitedList(pDBview->GetTableNames()),
				   DynamicBCA<DataObj, BCA>(bcabios, bca), postfix,
				   DynamicBCA<DataObj, BCA>(bpabios, bca, orderOfColumns), pDBview->GetSelVal(), pDBview->GetInsVal(),
				   pDBview->GetConnection());

			   // in order to set the IOHandler we have to convert the indexed view's
			   // IOHandler<DataObj, ParamObj> to IOHandler<DataObj, DataObj>
			   // monomorphize() does that for us

			   view.set_io_handler(monomorphize(pDBview->get_io_handler()));

			   DBView<DataObj, DataObj>::update_iterator up_it = view;

			   *up_it = dataObj;
			   
			   up_it.Params(*it);  // search parameters are the object to replace

#if 0
			   // debugging ... only use with types that support operator<<()
			   // using to debug DynamicIndexedViewExample()
			   cout << "In replace() ... updating: " << endl;
			   cout << *it << endl;
			   cout << "with: " << endl;
			   cout << dataObj << endl;
#endif
			   up_it++;

			   // if iterator encountered a problem, that means insertion failed, so throw
			   if (up_it.bad() || up_it.fail())
					  throw DBException("IndexedDBView::replace()", "Update in DB failed!",
							NULL, NULL);
			}
			catch (...)
			{
			   // if update fails in DB, we must rollback the local_insert() with
			   // the appropriate call to local_erase()?  Then rethrow

		       // ins_pr.first is an iterator to the elements we inserted into the
			   // indexed view ... so atomicity is maintained by erasing those elements
			   local_erase(ins_pr.first);	   
			   throw;
			}

		  }

		  list<iterator>::iterator condemned_it;

		  // *** now must erase all marked (damned) elements ***

		  // guaranteed to succeed as erase() is nothrow ... atomicity holds
		  // remember each iterator to a condemned element is properly matched
		  // with its index because we built the list of the damned in the same order
		  for (map_it = indexes.begin(), condemned_it = condemned.begin(); 
		           map_it != indexes.end(); map_it++, condemned_it++)
		  {
			  DBIndex<View> &index = (*map_it).second;
			  index.erase(**condemned_it);  // God has spoken, condemned pointer!
		  }

		  // return the pair from the local_insert() as the result
		  return ins_pr;

	   }

	   // *** composite insert(), erase(), replace() methods ***
	   
	   // insert with hint just ignores the hint
	   iterator insert(iterator pos, const DataObj &dataObj)
	   {
		  return insert(dataObj).first;
	   }

	   // range insert ... each insert guaranteed to be atomic, but not the whole range
	   template<class InputIterator> void insert(InputIterator first, InputIterator last)
	   {
		  while (first != last)
			 insert(*first++);
	   }

	   // erase all elements in a given range
	   void erase(iterator first, iterator last)
	   {

		  while (first != last)
			 erase(first++);
	   }

	   // erase all elements with the given value
	   void erase(const DataObj &dataObj)
	   {
		  pair<iterator, iterator> pr = equal_range(dataObj);
		  erase(pr.first, pr.second);
	   }

	   // applies to PK as the container itself is indexed on DataObj's
	   // based on the PK... returned iterator points to first DataObj in the list

	   const_iterator begin() const
	   {
			const_cast<IndexedDBView *>(this)->fetch();
			// return indexes[orderOfKeys[0]].begin();
			
			index_map::iterator map_it = indexes.find(orderOfKeys[0]);

		    // should always be the case that IndexNm exists
		    if (map_it != indexes.end())
			{
			  return const_iterator((*map_it).second.begin());
			}
			else // PK should exist, so throw if it doesn't
			{
			  throw DBException("IndexedDBView::begin()", "PK doesn't exist for this view!",
				  NULL, NULL);
			}
	   }

	   const_iterator end() const
	   {
			const_cast<IndexedDBView *>(this)->fetch();
			// return indexes[orderOfKeys[0]].end();

			index_map::iterator map_it = indexes.find(orderOfKeys[0]);

		    // should always be the case that IndexNm exists
		    if (map_it != indexes.end())
			{
			  return const_iterator((*map_it).second.end());
			}
			else // PK should exist, so throw if it doesn't
			{
			  throw DBException("IndexedDBView::end()", "PK doesn't exist for this view!",
				  NULL, NULL);
			}

	   }

	   iterator begin()
	   {
			fetch();
			// return indexes[orderOfKeys[0]].begin();

			index_map::iterator map_it = indexes.find(orderOfKeys[0]);

		    // should always be the case that IndexNm exists
		    if (map_it != indexes.end())
			{
			  return iterator((*map_it).second.begin());
			}
			else // PK should exist, so throw if it doesn't
			{
			  throw DBException("IndexedDBView::begin()", "PK doesn't exist for this view!",
				  NULL, NULL);
			}
	   }

	   iterator end()
	   {
			fetch();
			// return indexes[orderOfKeys[0]].end();
			
			index_map::iterator map_it = indexes.find(orderOfKeys[0]);

		    // should always be the case that IndexNm exists
		    if (map_it != indexes.end())
			{
			  return iterator((*map_it).second.end());
			}
			else // PK should exist, so throw if it doesn't
			{
			  throw DBException("IndexedDBView::end()", "PK doesn't exist for this view!",
				  NULL, NULL);
			}
	   }

	   // reverse iterators
	   reverse_iterator rbegin() { return reverse_iterator(end());   }
	   reverse_iterator rend()   { return reverse_iterator(begin()); }
	
	   const_reverse_iterator rbegin() const
	   {
			return const_reverse_iterator(end());
	   }

	   const_reverse_iterator rend() const
	   {
			return const_reverse_iterator(begin());
	   }

	   bool empty() const
	   {
			const_cast<IndexedDBView *>(this)->fetch();
			// return indexes[orderOfKeys[0]].empty();

			index_map::iterator map_it = indexes.find(orderOfKeys[0]);

		    // should always be the case that IndexNm exists
		    if (map_it != indexes.end())
			{
			  return (*map_it).second.empty();
			}
			else // PK should exist, so throw if it doesn't
			{
			  throw DBException("IndexedDBView::empty()", "PK doesn't exist for this view!",
				  NULL, NULL);
			}
	   }

	   size_type size() const
	   {
	    	const_cast<IndexedDBView *>(this)->fetch();
			// return indexes[orderOfKeys[0]].size();

			index_map::iterator map_it = indexes.find(orderOfKeys[0]);

		    // should always be the case that IndexNm exists
		    if (map_it != indexes.end())
			{
			  return (*map_it).second.size();
			}
			else // PK should exist, so throw if it doesn't
			{
			  throw DBException("IndexedDBView::size()", "PK doesn't exist for this view!",
				  NULL, NULL);
			}
	   }

	   size_type max_size() const
	   {
			const_cast<IndexedDBView *>(this)->fetch();
			// return indexes[orderOfKeys[0]].max_size();

			index_map::iterator map_it = indexes.find(orderOfKeys[0]);

		    // should always be the case that IndexNm exists
		    if (map_it != indexes.end())
			{
			  return (*map_it).second.max_size();
			}
			else // PK should exist, so throw if it doesn't
			{
			  throw DBException("IndexedDBView::max_size()", "PK doesn't exist for this view!",
				  NULL, NULL);
			}
	   }

	   // returns the number of elements whose key is dataObj based on the Primary Key
	   size_t count(const DataObj &dataObj) const
	   {
			return count_AK(orderOfKeys[0], dataObj);
	   }

	   // same, but for an alternate key
	   size_t count_AK(const string &IndexNm, const DataObj &dataObj) const
	   {
			pair<iterator, iterator> toCount = equal_range_AK(IndexNm, dataObj);

			size_t result = 0;

			for (iterator it = toCount.first; it != toCount.second; it++)
				result++;

			return result;

	   }

	   // erase all elements - probably don't want to support erase of
	   // individual elems as this will be too hairy & slow
	   void clear()
	   {
	        data.clear();
			indexes.clear();
			bFetched = false;
	   }

	   // lexicographical compare .. based on PK
	   // indexed views can't be const due to the potential need to fetch()
	   friend bool operator==(const IndexedDBView<View> &indexview1,
			const IndexedDBView<View> &indexview2)
	   {
		    IndexedDBView<View> &idxview1 =
				const_cast<IndexedDBView<View> &>(indexview1);
		    IndexedDBView<View> &idxview2 =
				const_cast<IndexedDBView<View> &>(indexview2);

		    idxview1.fetch();
		    idxview2.fetch();

			// return idxview1.indexes[orderOfKeys] == idxview2.indexes[orderOfKeys[0]];
		    index_map::iterator map_it1 = idxview1.indexes.find(idxview1.orderOfKeys[0]);
			index_map::iterator map_it2 = idxview2.indexes.find(idxview2.orderOfKeys[0]);

		    // make sure PK's exist for both views
		    if (map_it1 == idxview1.indexes.end())
			{
			  throw DBException("IndexedDBView::operator==()",
				  "PK doesn't exist for first view!", NULL, NULL);
			}
			else if (map_it2 == idxview2.indexes.end())			{
			  throw DBException("IndexedDBView::operator==()",
				  "PK doesn't exist for second view!",
				  NULL, NULL);
			}
		    return (*map_it1).second == (*map_it2).second;
	   }

	   // though not part of the standard, operator!=() is added for convenience
	   friend bool operator!=(const IndexedDBView<View> &indexview1,
			const IndexedDBView<View> &indexview2)
	   {
		    IndexedDBView<View> &idxview1 =
				const_cast<IndexedDBView<View> &>(indexview1);
		    IndexedDBView<View> &idxview2 =
				const_cast<IndexedDBView<View> &>(indexview2);
			
			idxview1.fetch();
		    idxview2.fetch();

			// return idxview1.indexes[orderOfKeys] == idxview2.indexes[orderOfKeys[0]];
		    index_map::iterator map_it1 = idxview1.indexes.find(idxview1.orderOfKeys[0]);
			index_map::iterator map_it2 = idxview2.indexes.find(idxview2.orderOfKeys[0]);

		    // make sure PK's exist for both views
		    if (map_it1 == idxview1.indexes.end())
			{
			  throw DBException("IndexedDBView::operator==()",
				  "PK doesn't exist for first view!", NULL, NULL);
			}
			else if (map_it2 == idxview2.indexes.end())			{
			  throw DBException("IndexedDBView::operator==()",
				  "PK doesn't exist for second view!",
				  NULL, NULL);
			}
		    return (*map_it1).second != (*map_it2).second;
	   }

	   friend bool operator<(const IndexedDBView<View> &indexview1,
			const IndexedDBView<View> &indexview2)
	   {
		   IndexedDBView<View> &idxview1 =
				const_cast<IndexedDBView<View> &>(indexview1);
		   IndexedDBView<View> &idxview2 =
				const_cast<IndexedDBView<View> &>(indexview2);

		   idxview1.fetch();
		   idxview2.fetch();

		   // return idxview1.indexes[orderOfKeys[0]] < idxview2.indexes[orderOfKeys[0]];

		   index_map::iterator map_it1 = idxview1.indexes.find(idxview1.orderOfKeys[0]);
		   index_map::iterator map_it2 = idxview2.indexes.find(idxview2.orderOfKeys[0]);

		   // make sure PK's exist for both views
		   if (map_it1 == idxview1.indexes.end())
		   {
			  throw DBException("IndexedDBView::operator<()",
				  "PK doesn't exist for first view!", NULL, NULL);
		   }
		   else if (map_it2 == idxview2.indexes.end())			{
			  throw DBException("IndexedDBView::operator<()",
				  "PK doesn't exist for second view!",
				  NULL, NULL);
		   }
		   return (*map_it1).second < (*map_it2).second;
	   }

	   friend bool operator>(const IndexedDBView<View> &indexview1,
			const IndexedDBView<View> &indexview2)
	   {
		   IndexedDBView<View> &idxview1 =
				const_cast<IndexedDBView<View> &>(indexview1);
		   IndexedDBView<View> &idxview2 =
				const_cast<IndexedDBView<View> &>(indexview2);

		   idxview1.fetch();
		   idxview2.fetch();

		   // return idxview1.indexes[orderOfKeys[0]] > idxview2.indexes[orderOfKeys[0]];
			
		   index_map::iterator map_it1 = idxview1.indexes.find(idxview1.orderOfKeys[0]);
		   index_map::iterator map_it2 = idxview2.indexes.find(idxview2.orderOfKeys[0]);

     	   // make sure PK's exist for both views
		   if (map_it1 == idxview1.indexes.end())
		   {
			  throw DBException("IndexedDBView::operator>()",
				  "PK doesn't exist for first view!", NULL, NULL);
		   }
		   else if (map_it2 == idxview2.indexes.end())			{
			  throw DBException("IndexedDBView::operator>()",
				  "PK doesn't exist for second view!",
				  NULL, NULL);
		   }
		   return (*map_it1).second > (*map_it2).second;
	   }

	   friend bool operator<=(const IndexedDBView<View> &indexview1,
			const IndexedDBView<View> &indexview2)
	   {
		   IndexedDBView<View> &idxview1 =
				const_cast<IndexedDBView<View> &>(indexview1);
		   IndexedDBView<View> &idxview2 =
				const_cast<IndexedDBView<View> &>(indexview2);

		   idxview1.fetch();
		   idxview2.fetch();

		   // return idxview1.indexes[orderOfKeys[0]] <= idxview2.indexes[orderOfKeys[0]];
			
		   index_map::iterator map_it1 = idxview1.indexes.find(idxview1.orderOfKeys[0]);
		   index_map::iterator map_it2 = idxview2.indexes.find(idxview2.orderOfKeys[0]);

		   // make sure PK's exist for both views
		   if (map_it1 == idxview1.indexes.end())
		   {
			  throw DBException("IndexedDBView::operator<=()",
				  "PK doesn't exist for first view!", NULL, NULL);
		   }
		   else if (map_it2 == idxview2.indexes.end())			{
			  throw DBException("IndexedDBView::operator<=()",
				  "PK doesn't exist for second view!",
				  NULL, NULL);
		   }
		   return (*map_it1).second <= (*map_it2).second;
	   }

	   friend bool operator>=(const IndexedDBView<View> &indexview1,
			const IndexedDBView<View> &indexview2)
	   {
		   IndexedDBView<View> &idxview1 =
				const_cast<IndexedDBView<View> &>(indexview1);
		   IndexedDBView<View> &idxview2 =
				const_cast<IndexedDBView<View> &>(indexview2);

		   idxview1.fetch();
		   idxview2.fetch();

		   // return idxview1.indexes[orderOfKeys[0]] >= idxview2.indexes[orderOfKeys[0]];
		
		   index_map::iterator map_it1 = idxview1.indexes.find(idxview1.orderOfKeys[0]);
		   index_map::iterator map_it2 = idxview2.indexes.find(idxview2.orderOfKeys[0]);

		   // make sure PK's exist for both views
		   if (map_it1 == idxview1.indexes.end())
		   {
			  throw DBException("IndexedDBView::operator>=()",
				  "PK doesn't exist for first view!", NULL, NULL);
		   }
		   else if (map_it2 == idxview2.indexes.end())			{
			  throw DBException("IndexedDBView::operator>=()",
				  "PK doesn't exist for second view!",
				  NULL, NULL);
		   }
		   return (*map_it1).second >= (*map_it2).second;
	   }

#ifdef DATAOBJ_PRINTABLE
	   // debugging operator<<() .., DataObj must have an operator<<()
	   friend ostream &operator<<(ostream &o, const IndexedDBView<View> &view)
	   {
		    index_map::const_iterator map_it;
			
			for (map_it = view.indexes.begin(); map_it != view.indexes.end(); map_it++)
			{
			   o << "indexes[" << (*map_it).first << "] = " << endl;
			   o << (*map_it).second << endl;
			}

			return o;
	   }
#endif

	// gets the IOHandler of the underlying view
	template<class UserHandler> const UserHandler &
		get_io_handler(const UserHandler *dummy) const
	{
		return pDBview->get_io_handler(dummy);
	}

	// returns raw IOHandler object
	IOHandler<DataObj, ParamObj> &get_io_handler() const
	{
		return pDBview->get_io_handler();
	}

   private:
	   // as its name implies, fetch the data associated with this view from the database
	   // if we haven't done so already
	   void fetch()
	   {
		  // because of database connection issues, fetch() cannot be part of constructor
		  // all functions that return an iterator must call fetch() first to initialize
		  // the list

		  if (bFetched)
			  return;

		  if (pDBview == NULL)
			  throw DBException("IndexedDBView::fetch()",
				"Must assign to a default constructed IndexedDBView before first use!",
				NULL, NULL);

		  // indexes destroyed by clear() ... need to rebuild indexes map
		  if (indexes.empty())
		  {
			 BuildIndexes();
		  }

		  typename View::select_iterator read_it = pDBview->begin();

		  SetParams(read_it.Params());

		  // don't throw until we catch all uniqueness constraint violations
		  size_t totalViolations = 0;

		  // must set flag here to avoid infinite recursion
		  bFetched = true;

		  // force instantiation of EqualCompare to work around compiler
		  // problem with instantiating needed comparison operator
		  for ( ; read_it != pDBview->end(); read_it++)
		  {
			pair<iterator, bool> ins_pr = local_insert(*read_it);

			// uniqueness constraints violated on existing data in DB
			if (!ins_pr.second)
			{
				totalViolations++;
			}
		  }
		
		  // uniqueness constraints violated!  Construct exception string
		  // and throw
		  if (totalViolations > 0)
		  {
				ostrstream errstr;

				errstr << totalViolations << " uniqueness constraint violations on existing data in DB!" << ends;

				bFetched = false;

				throw DBException("IndexedDBView::fetch()", errstr.str(), NULL, NULL);
		  }

		  bFetched = true;
	   }

	   // insert object locally ... (uniqueness checks?)
	   pair<iterator, bool> local_insert(const DataObj &dataObj, 
		   bool bCheckUniqueness = true)
	   {
		     // uncomment the following 3 lines of code if we wish
		     // to enforce uniqueness constraints in local_insert()

		     if (bCheckUniqueness)
			 {
				 pair<iterator, bool> find_pr = CheckUniqueness(dataObj);
		         
				 if (!find_pr.second)
		     	   return find_pr;
			 }

		     // insert object into list that owns DataObj's
			 // data.push_back(dataObj);
			 list<DataObj>::iterator ins_it = data.insert(data.end(), dataObj);

			 // DataObj *pData = &(data.back()); // must get address of element in list;

			 // add pointer to DataObj to each of the key lists 
			 // remember that each DBIndex contains pointers to all addresses
			 // of elements in the list
			 // (just in a different order based on the key)
			 index_map::iterator idx_it = indexes.begin();
			 
			 try
			 {
				 for ( ; idx_it != indexes.end(); idx_it++)
				 {
				    DBIndex<View> &index = (*idx_it).second;
				    // index.insert(*pData);

					index.insert(*ins_it);
				 }
			 }
			 catch (...)
			 {
				index_map::reverse_iterator rev_it = 
					index_map::reverse_iterator(idx_it);

				// rollback local state on an exception, then rethrow
				for ( ; rev_it != indexes.rend(); rev_it++)
				{
					DBIndex<View> &index = (*rev_it).second;
				    index.erase(*ins_it);
				}

				// remove object from master list
				data.erase(ins_it);
				throw;
			 }

			 // return iterator to newly inserted element and indicate success
			 // must find the proper element based on the address of the inserted dataObj
			 pair<iterator, iterator> ret_pr = equal_range(dataObj);

			 iterator ret_it = ret_pr.first;

			 for ( ; ret_it != ret_pr.second; ret_it++)
			 {
				if (&(*ins_it) == &(*ret_it))
					break;
			 }
			 
			 return pair<iterator, bool>(ret_it, true);
	   }

	   // remove the DataObj pointed to by the iterator from the IndexedDBView
	   // must remove from all index lists and then from the owned list
	   void local_erase(iterator it)
	   {
		    // grab address of the DataObj in the owned data list
			DataObj *pData = &(*it);

			// now remove all pointers to the DataObj from the index lists
			for (index_map::iterator map_it = indexes.begin(); map_it != indexes.end();
				map_it++)
			{
				DBIndex<View> &index = (*map_it).second;
				index.erase(*pData);
			}

			// remove item from owned data list
			for (data_iterator data_it = data.begin(); data_it != data.end();
				data_it++)
			{
				// remove the DataObj if the iterator is pointing to the same DataObj
			    // referred to by the iterator passed in
				if (pData == &(*data_it))
				{
					data.erase(data_it);
					break;
				}
			}

	   }

	   // extract the BoundIO's representing the columns that make up the primary key
	   BoundIOs ExtractPK() const
	   {

		   IndexedDBView<View> *this_ptr = const_cast<IndexedDBView<View> *>(this);

		   index_map::iterator map_it = this_ptr->indexes.find(orderOfKeys[0]);

		   if (map_it == this_ptr->indexes.end())
		   {
				throw DBException("IndexedDBView::ExtractPK()", "PK does not exist for this view",
					NULL, NULL);
		   }

		   DBIndex<View> &idx = (*map_it).second;

		   return idx.ExtractKey();
	   }

	   // returns iterator to existing element and false if not unique to index,
	   // end() and true otherwise
	   pair<iterator, bool> CheckUniqueness(const DataObj &dataObj) const
	   {
		   IndexedDBView<View> *this_ptr = const_cast<IndexedDBView<View> *>(this);

		   // check unique indices for match using find()
		   // if found it, return make_pair(iterator to found element, false)
		   for (index_map::iterator map_it = this_ptr->indexes.begin(); 
		          map_it != this_ptr->indexes.end(); map_it++)
		   {
			    DBIndex<View> &idx = (*map_it).second;

				pair<DBIndex<View>::iterator, bool> unique_pr = idx.CheckUniqueness(dataObj);


				// if uniqueness check failed, return the pair to caller
				if (!unique_pr.second)
					return pair<iterator, bool>(iterator(unique_pr.first), unique_pr.second);
			
				// element is unique for this index
		   }

		   // no other element found, return iterator to end of view and
		   // true indicating uniqueness

		   return pair<iterator, bool>(this_ptr->end(), true);
	   }

	   // returns iterator to existing element and false if not unique to index,
	   // end() and true otherwise
	   // the element pointed to by the iterator passed in is disregarded in the
	   // test for uniqueness performed by this method

	   // will rewrite to get proper behavior
	   pair<iterator, bool> CheckUniqueness(const DataObj &dataObj, iterator it)
	   {
		   IndexedDBView<View> *this_ptr = const_cast<IndexedDBView<View> *>(this);

		   // check unique indices for match using find()
		   // if found it, return make_pair(iterator to found element, false)
		   for (index_map::iterator map_it = this_ptr->indexes.begin();
		              map_it != this_ptr->indexes.end(); map_it++)
		   {
			    DBIndex<View> &idx = (*map_it).second;

				pair<DBIndex<View>::iterator, bool> pr = idx.CheckUniqueness(dataObj);

				pair<iterator, bool>unique_pr(iterator(pr.first), pr.second);

				// if uniqueness check failed, return the pair to caller
				if (!unique_pr.second && unique_pr.first != it)
					return unique_pr;

				// element is unique for this index
		   }

		   // no other element found, return iterator to end of view and
		   // true indicating uniqueness

		   return pair<iterator, bool>(this_ptr->end(), true);
	   }
};

END_DTL_NAMESPACE
		
#endif
