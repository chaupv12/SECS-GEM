/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
// simple reference count pointer class
// taken and modified from "The C++ Standard Library: A Tutorial and Reference"
// by Nicolai M. Josuttis
// (c) 1999 - p.222-223
// Edited: 12/19/2000 - MG - added namespaces

#ifndef COUNTED_PTR_H
#define COUNTED_PTR_H

#include "std_inc.h"

BEGIN_DTL_NAMESPACE

// class for counted reference semantics
// deletes the object to which it refers when the last CountedPtr
// that refers to it is destroyed

template<class T> class CountedPtr
{
private:
	T *ptr;		 // pointer to the value
	long *count; // shared number of owners

public:
	// initialize pointer with existing pointer
	// requires that the pointer p is a return value of new
	CountedPtr(T *p = NULL) : ptr(p), count(new long(1)) { }

	// templated form to maybe provide proper derived to base conversions, etc.
	template<class U> CountedPtr(const CountedPtr<U> &p) : ptr(const_cast<U *>(p.get())), 
		count(const_cast<long *>(p.GetRefCountPtr()))
	{
		++*count;
	}

	// copy pointer (one more owner)
	CountedPtr(const CountedPtr<T> &p) : ptr(p.ptr), count(p.count) 
	{
		++*count;
	}

	// destructor (delete value if this was the last owner)
	~CountedPtr() 
	{
		dispose();
	}

	// initialize pointer with existing pointer
	// requires that the pointer p is a return value of new
	CountedPtr<T> &operator=(T *p) {
		dispose();
		ptr = p;
		count = new long(1);

		return *this;
	}

	void swap(CountedPtr<T> &other)  // never throws
	{std::swap(ptr,other.ptr); std::swap(count,other.count); }


	// exception safe assignment 
	CountedPtr<T> &operator=(const CountedPtr<T> &p) 
	{
		if (this != &p)
		{
			CountedPtr<T> temp(p);
			swap(temp);
		}

		return *this;
	}

	// access the value to which the pointer refers
	const T &operator*() const 
	{
		return *ptr;
	}
	
	T &operator*()
	{
	    return *ptr;
	}

	const T *operator->() const 
	{
		return &**this;
	}

	T *operator->()
	{
		return &**this;
	}

	// access the underlying pointer
	const T *get() const
	{
		return ptr;
	}

	T *get()
	{
		return ptr;
	}

	// more operators to give the feel of real pointers
	friend bool operator==(const CountedPtr<T> &ptr1, const CountedPtr<T> &ptr2)
	{
		return ptr1.ptr == ptr2.ptr;
	}

	friend bool operator!=(const CountedPtr<T> &ptr1, const CountedPtr<T> &ptr2)
	{
		return !(ptr1 == ptr2);
	}

	bool operator!() const
	{
		return (ptr == NULL);
	}

	operator bool() const
	{
		return (ptr != NULL);
	}

	long GetRefCount() const
	{
		if (ptr == NULL)
			return 0;

		return *count;
	}

	const long *GetRefCountPtr() const
    {
		return count;
	}
private:
	void dispose()
	{
		if (--*count == 0)
		{
			delete count;
			count = NULL;

			if (ptr != NULL) 
				delete ptr;
			ptr = NULL;
		}
	}
};

// specializations needed for POD's as they don't have operator->()
template<> class CountedPtr<SDWORD>
{
private:
	SDWORD *ptr; // pointer to the value
	long *count; // shared number of owners

public:
	// initialize pointer with existing pointer
	// requires that the pointer p is a return value of new
	CountedPtr(SDWORD *p = NULL) : ptr(p), count(new long(1)) { }

	// templated form to maybe provide proper derived to base conversions, etc.
	template<class U> CountedPtr(const CountedPtr<U> &p) : ptr(const_cast<U *>(p.get())), 
		count(const_cast<long *>(p.GetRefCountPtr()))
	{
		++*count;
	}

	// copy pointer (one more owner)
	CountedPtr(const CountedPtr<SDWORD> &p) : ptr(p.ptr), count(p.count) 
	{
		++*count;
	}

	// destructor (delete value if this was the last owner)
	~CountedPtr() 
	{
		dispose();
	}

	// initialize pointer with existing pointer
	// requires that the pointer p is a return value of new
	CountedPtr<SDWORD> &operator=(SDWORD *p) {
		dispose();
		ptr = p;
		count = new long(1);

		return *this;
	}

	void swap(CountedPtr<SDWORD> &other)  // never throws
	{std::swap(ptr,other.ptr); std::swap(count,other.count); }


	// exception safe assignment 
	CountedPtr<SDWORD> &operator=(const CountedPtr<SDWORD> &p) 
	{
		if (this != &p)
		{
			CountedPtr<SDWORD> temp(p);
			swap(temp);
		}

		return *this;
	}

	// access the value to which the pointer refers
	const SDWORD &operator*() const 
	{
		return *ptr;
	}
	
	SDWORD &operator*()
	{
	    return *ptr;
	}

	// ** no operator->() for POD's

	// access the underlying pointer
	const SDWORD *get() const
	{
		return ptr;
	}

	SDWORD *get()
	{
		return ptr;
	}

	// more operators to give the feel of real pointers
	friend bool operator==(const CountedPtr<SDWORD> &ptr1, const CountedPtr<SDWORD> &ptr2)
	{
		return ptr1.ptr == ptr2.ptr;
	}

	friend bool operator!=(const CountedPtr<SDWORD> &ptr1, const CountedPtr<SDWORD> &ptr2)
	{
		return !(ptr1 == ptr2);
	}

	bool operator!() const
	{
		return (ptr == NULL);
	}

	operator bool() const
	{
		return (ptr != NULL);
	}

	long GetRefCount() const
	{
		if (ptr == NULL)
			return 0;

		return *count;
	}

	const long *GetRefCountPtr() const
    {
		return count;
	}
private:
	void dispose()
	{
		if (--*count == 0)
		{
			delete count;
			count = NULL;

			if (ptr != NULL) 
				delete ptr;
			ptr = NULL;
		}
	}
};

class MemPtr
{
private:
	char *ptr;		 // pointer to the value
	long *count;     // shared number of owners
    size_t bufsize;  // bytes allocated
public:

#ifdef DTL_MEM_DEBUG
	static set<char *> memChecker; // memory checker added for debugging
								   // of MemPtr's
								   // valid addresses are stored here
								   // so if someone tries to poke into an
								   // unknown address, we'll print out an error
#endif
	
	// initialize pointer with desired size

	// using operator new as we're only allocating, not constructing
	explicit MemPtr(size_t sz) : 
	    ptr((char *) ::operator new(sz)), count(new long(1)), bufsize(sz) 
	{ 
#ifdef DTL_MEM_DEBUG
			memChecker.insert(ptr); // register address with memory checker	
#endif
	}

	MemPtr() : ptr(NULL), count(NULL), bufsize(0)
	{

	}

	// return underlying ptr.
	char *get()
	{
#ifdef DTL_MEM_DEBUG
	   CheckPtr();
#endif
       return ptr;
	}

	const char *get() const
	{
#ifdef DTL_MEM_DEBUG
	   CheckPtr();
#endif
	   return ptr;
	}

	// return bytes allocated
	size_t size() const
	{
#ifdef DTL_MEM_DEBUG
		CheckPtr();
#endif
       return bufsize;
	}

	// copy pointer (one more owner)
	MemPtr(const MemPtr &p) : ptr(p.ptr), count(p.count) , bufsize(p.bufsize)
	{
		if (count != NULL)
		    ++*count;
	}

	void reset(size_t sz)
	{
	   dispose();
	   ptr = (char *) ::operator new(sz); // allocate new space
	   count = new long(1);
	   bufsize = sz;
#ifdef DTL_MEM_DEBUG
	   memset(ptr, 0, sz);
	   memChecker.insert(ptr);
#endif
	}

	// destructor (delete value if this was the last owner)
	~MemPtr() 
	{
		dispose();
	}

	void swap(MemPtr &other)  // never throws
	{
		std::swap(ptr, other.ptr); 
		std::swap(count, other.count); 
		std::swap(bufsize, other.bufsize);
	}


	// exception safe assignment 
	MemPtr &operator=(const MemPtr &p) 
	{
		if (this != &p)
		{
			MemPtr temp(p);
			swap(temp);
		}

		return *this;
	}


private:
	void dispose()
	{
		if (count != NULL && --*count == 0)
		{
#ifdef DTL_MEM_DEBUG
			memChecker.erase(ptr);
#endif
			delete count;
			count = NULL;

			if (ptr != NULL) 
				::operator delete(ptr); // don't invoke destructor, just deallocate

			ptr = NULL;
			bufsize = 0;
		}
	}

#ifdef DTL_MEM_DEBUG
	void CheckPtr() const
	{
	   // pointer is invalid if not NULL and not found in set of valid
	   // pointers in the memory checker
       if (ptr != NULL && memChecker.find(ptr) == memChecker.end())
	   {
		   void *addr = ptr;
           cout << "Invalid access of ptr: " << addr << endl;
	   }
	   else if (ptr == NULL)
	   {
		   cout << "Attempting to access NULL ptr" << endl;
	   }

	}
#endif
};


END_DTL_NAMESPACE

#endif
