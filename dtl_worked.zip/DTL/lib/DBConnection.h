/* Copyright � 2000 
Michael Gradman and Corwin Joy 

Permission to use, copy, modify, distribute and sell this software and 
its documentation for any purpose is hereby granted without fee, provided 
that the above copyright notice appears in all copies and that both that 
copyright notice and this permission notice appear in supporting documentation. 
Corwin Joy and Michael Gradman make no representations about the suitability 
of this software for any purpose. 
It is provided "as is" without express or implied warranty.
*/ 
#ifndef _DBCONNECTION_H
#define _DBCONNECTION_H

#include "DB_Base.h"
#include "validate.h"

// Revised: 11/12/2000 - CJ - cleaned up Connect() function
// Revised: 12/19/2000 - MG - added namespace support

BEGIN_DTL_NAMESPACE

class DBEnvironment {
private:
	HENV henv;

public:
	DBEnvironment() : henv(SQL_NULL_HENV) {};
	~DBEnvironment() {
		RETCODE rc;
		// free environment handle
		rc = SQLFreeHandle(SQL_HANDLE_ENV, henv);

#if 0
		if (!RC_SUCCESS(rc))
		{

			// error may have occurred when trying to free connection
			// so append to error string
			errmsg += "Unable to free environment handle!";

			// set state variables back to an unallocated state
			// in order to maintain consistency

			henv = NULL;

			throw DBException("DBEnvironment::Release()", errmsg, NULL, NULL);
			break;
		}
#endif
	}

	inline void init() {
		if (henv != SQL_NULL_HENV)
			return;

		// Before we allocate our first environment handle, try to turn on connection pooling
		// Note we are not checking error codes here, we just try to turn it on,
		// and if the driver does not support pooling there is nothing we can do.

		// pool across the environment handle
		SQLSetEnvAttr(SQL_NULL_HENV,	SQL_ATTR_CONNECTION_POOLING, (SQLPOINTER)SQL_CP_ONE_PER_DRIVER,	
			SQL_IS_INTEGER);
		

		RETCODE rc;
		rc = SQLAllocEnv(&henv);
		if (!RC_SUCCESS(rc))
		{
		   henv = SQL_NULL_HENV;
		   throw DBException("DBEnvironment::init()",
							 "Unable to allocate SQL environment handle!",
							 NULL, NULL);
		}

		// set the ODBC behavior version. Not sure why this is required, but
		// connection pooling does not seem to work without it
		SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER) SQL_OV_ODBC3, 
			SQL_IS_INTEGER);

		//set the matching condition for using an existing connection in the pool
		//use relaxed matching, i.e. most liberal rules for matching existing connection
		SQLSetEnvAttr(henv, SQL_ATTR_CP_MATCH, (SQLPOINTER) SQL_CP_RELAXED_MATCH, 
			SQL_IS_INTEGER);


	
	}

	inline HENV GetHENV() {return henv;}
};

class DBConnection : public ValidatedObject
{
public:
	// state of connection
    enum ConnState { CONN_UNALLOCATED, CONN_ALLOCATED, CONNECTED };
private:
	static DBEnvironment dbe;  // environment associated with this connection
	HDBC hdbc;  // this connection 
	bool auto_commit; // whether to autocommit or not

	// prohibit copy construction and assignment
	DBConnection &operator=(const DBConnection &conn);

	DBConnection(const DBConnection &conn);
   
	// state of the connection
	ConnState state;

	// DSN we used to connect
	string usedDSN;

	static DBConnection defaultConn;

	// not responsible for allocating hdbc and dbe.henv,
	// that is done by the public version of Connect()
	// (modified from ZNA Pricer code for Connect())
    void Connect (unsigned char *szConnStrIn)
	{
      RETCODE rc;    			/* Return code for ODBC functions */
      unsigned char szConnStrOut[1024];  // Microsoft ODBC requires at least 1024
										 // bytes here, otherwise will overwrite
										 // memory
      SWORD cbConnStrOut;
      UWORD fDriverCompletion;
      bool bUseConnectStr;

	  // needed statics
	  static HWND g_AppHwnd = NULL;

	  validate();

	  if (state == CONNECTED)
		  return;

   
   // To prompt for connection, use SQL_DRIVER_COMPLETE
#define NO_PROMPT
#ifdef NO_PROMPT
   fDriverCompletion = SQL_DRIVER_NOPROMPT;
#else
   fDriverCompletion = SQL_DRIVER_COMPLETE;
#endif

   // Prompt for connection
	bUseConnectStr = false;
	if (szConnStrIn != NULL)
		if (strlen((char *)szConnStrIn) > 0)
			bUseConnectStr = true;

	if (bUseConnectStr)
   		rc  = SQLDriverConnect(hdbc, g_AppHwnd, szConnStrIn, 
			strlen((char *)szConnStrIn)*sizeof(char), szConnStrOut, sizeof(szConnStrOut), 
			&cbConnStrOut, fDriverCompletion);
	else
		rc  = SQLDriverConnect(hdbc, g_AppHwnd, szConnStrIn, 
			0, szConnStrOut, sizeof(szConnStrOut), 
			&cbConnStrOut, fDriverCompletion);

    if (!RC_SUCCESS(rc))
	   throw DBException("DBConnection::Connect(unsigned char *DSN)",
			string("Unable to connect to database using DSN string \"") + 
					 (char *) szConnStrIn + "\"!", this, NULL);

    // Turn off autocommit so that info is committed as one transaction
    // DBConnection class commits on destruction or if auto_commit is set
    // N.B.!! If we do not do this takes 3 TIMES as long to run write to DB.
    // For sample data set takes 7.6 Seconds w/o autocommit v.s. 22.4 seconds with autocommit.
	SQLSetConnectOption(hdbc, SQL_AUTOCOMMIT, SQL_AUTOCOMMIT_OFF);

	auto_commit = false;

	// update state variables
	// exception safety maintained as state variables not updated until 
	// connection succeeds end
	// only the string assignment can throw afterwards (so it's done first)
    usedDSN = (char *) szConnStrIn;
    state = CONNECTED;
}


public:
	// connect to DB using the passed in DSN
	// and set the dbe.henv and hdbc members
	// throws exception if unable to connect!
    DBConnection(const string &DSN = "")
		: ValidatedObject(), state(CONN_UNALLOCATED), usedDSN(DSN), hdbc(SQL_NULL_HDBC), auto_commit(false)
	{ }

	// exception-safe swap()
	void swap(DBConnection &other)
	{
		ValidatedObject::swap(other);
		std::swap(hdbc, other.hdbc);
		std::swap(state, other.state);
		usedDSN.swap(other.usedDSN);
		std::swap(auto_commit, other.auto_commit);
	}

	// Connect to the DB using the passed in DSN if not already connected
	// any existing constructs which reference this connection
	// become invalid if the DSN is different than the DBConnection was using
	// prior to the call to Connect()

	// connect using usedDSN as connection string if no arguments passed in
	void Connect()
	{
		Connect(usedDSN); // exception-safe as only operation done
	}

	// cleanup issues here if exception is thrown!!!!
	void Connect(const string &DSN)
	{
		validate();
		
		if (DSN == usedDSN && state == CONNECTED )
			return;

        DBConnection tmp(DSN); // needed for exception safety

		
		RETCODE rc;

		dbe.init();		
			
		// allocate connection
		rc = SQLAllocConnect(dbe.GetHENV(), &tmp.hdbc);

		if (!RC_SUCCESS(rc))
		{
			tmp.invalidate();
			throw DBException("DBConnection::DBConnection()",
							  "Unable to allocate new connection handle!",
							  this, NULL);
		}

		tmp.state = CONN_ALLOCATED;

		// try to connect to DB instance
		tmp.Connect((unsigned char*) DSN.c_str());


		// connection successful ... if we reach here
		// state info properly updated by unsigned char * overload of Connect

		swap(tmp); // atomicity and consistency guaranteed through
		           // tmp, process, swap technique
	}

	// functions to commit or rollback all transactions that have occurred between last 
	// commit or rollback on this connection

	// turn autocommit on or off
	void SetAutoCommit(bool commit)
    {
		bool old_auto_commit = auto_commit;

		if (old_auto_commit == commit)
			return;

		auto_commit = commit;

		if (auto_commit)
		{
			CommitAll();
			SQLSetConnectOption(hdbc, SQL_AUTOCOMMIT, SQL_AUTOCOMMIT_ON);
		}
		else
		{
			SQLSetConnectOption(hdbc, SQL_AUTOCOMMIT, SQL_AUTOCOMMIT_OFF);
		}
	}

	bool GetAutoCommit()
    {
		return auto_commit;
	}

	// only one mutating operation done, so should be exception-safe
	void CommitAll()
	{
		validate();
		
		// does nothing if not connected
		if (state != CONNECTED)
			return;

		RETCODE rc = SQLTransact(dbe.GetHENV(), hdbc, SQL_COMMIT);


		// Select statements cannot commit.
		if (!RC_SUCCESS(rc))
		{
			invalidate();
			throw DBException("DBConnection::CommitAll()",
							  "Unable to commit transaction!",
							  this, NULL);
		}
	}

	// only one mutating operation done, so should be exception-safe
	// we require this to be no-throw for exception safe operations
	void RollbackAll()
	{
		// does nothing if not connected
		if (state != CONNECTED)
			return;

		RETCODE rc = SQLTransact(dbe.GetHENV(), hdbc, SQL_ROLLBACK);

// no-throw on error
#if 0
		if (!RC_SUCCESS(rc))
		{
			invalidate();
			throw DBException("DBConnection::RollbackAll()",
							  "Unable to rollback transaction!",
							  this, NULL);

		}
#endif
	}

	// cleanup issues here on exceptions!!!
    ~DBConnection()
    {
		try
		{
			Release();
		}
		catch (...)
		{

		}
	}

	// only able to guarantee consistency
	// ODBC resources may leak
	void Release()
	{
		string errmsg;

		// use a destroy as much as you can approach!
		// need some way to make this exception-safe

		if(CONN_UNALLOCATED == state)
		{
			return	;
		}

		// Rollback on destruction if something has invalidated the
		// connection's state
		// Otherwise, always commit
	    try
		{
		  if (!valid())
			RollbackAll();
		  else
			CommitAll();
		}
		catch (RootException &ex)
		{
			ostrstream errstream;
			errstream << ex.what() << endl;
			errstream << "Failed to CommitAll() or RollbackAll()!";
			errmsg = errstream.str();

			// set state variables back to an unallocated state
		    // in order to maintain consistency

		    state = CONN_UNALLOCATED;
		    hdbc = SQL_NULL_HDBC;
			throw DBException("DBConnection::Release()", errmsg, this, NULL);
		}

		// up to here, we're exception safe
		// even if we failed to commit or rollback,
		// we're still in a consistent and atomic state
		
		RETCODE rc = SQL_SUCCESS;
		
		// only try to deallocate connection and environment if actually
		// allocated in the first place
		// problems occur here if we throw here

		switch (state)
		{
		case CONNECTED : 
			rc	= SQLDisconnect(hdbc);
			if (!RC_SUCCESS(rc))
			{
				errmsg += "Unable to disconnect using odbc handle!";
					
				// set state variables back to an unallocated state
				// in order to maintain consistency

				state = CONN_UNALLOCATED;
				hdbc = SQL_NULL_HDBC;
				
				throw DBException("DBConnection::Release()", errmsg, this, NULL);
				break;
			}

			// fallthrough intentional as also need to free
			// connection handle

		case CONN_ALLOCATED:
				// free connection handle
				rc = SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	
				if (!RC_SUCCESS(rc))
				{
					errmsg += "Unable to free connection handle!";
					
					// set state variables back to an unallocated state
					// in order to maintain consistency

					state = CONN_UNALLOCATED;
					hdbc = SQL_NULL_HDBC;
				
					throw DBException("DBConnection;:Release()", errmsg, this, NULL);
					break;
				}
				
			// fallthrough intentional if we ever need to do anything in the UNALLOCATED case
			
		case CONN_UNALLOCATED: NULL;
		default: NULL;
		}

		// set state variables back to an unallocated state
		// in order to maintain consistency

		state = CONN_UNALLOCATED;
		hdbc = SQL_NULL_HDBC;
	
		if (!errmsg.empty())
			throw DBException("DBConnection::Release()", errmsg, NULL, NULL);
	}

	static DBConnection &GetDefaultConnection()
	{
		return defaultConn;
	}

	friend class DBStmt;

	friend class DBException;

	HDBC GetHDBC() const { return hdbc; }
	HENV GetHENV() const { return dbe.GetHENV(); }
  string GetDSN() const { return usedDSN;}


	// kludge to get around header hell
	friend HDBC GetHDBC(const DBConnection &conn);
	friend HENV GetHENV(const DBConnection &conn);


};


END_DTL_NAMESPACE

#endif
